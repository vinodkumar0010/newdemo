/*
 * App Configuration — reads from .env file
 * Vite replaces import.meta.env.VITE_xxx at build time
 */

const env = (key: string, fallback = ''): string => {
  try { return (import.meta as any).env?.[key] ?? fallback; } catch { return fallback; }
};

export const config = {
  // Supabase
  supabaseUrl:     env('VITE_SUPABASE_URL'),
  supabaseKey:     env('VITE_SUPABASE_ANON_KEY'),

  // PayUMoney
  payuMerchantKey: env('VITE_PAYU_MERCHANT_KEY'),
  payuMode:        env('VITE_PAYU_MODE', 'test') as 'test' | 'live',

  // Plan Prices (INR)
  pricePro:        Number(env('VITE_PRICE_PRO', '2399')),
  priceAgency:     Number(env('VITE_PRICE_AGENCY', '8199')),
  priceEnterprise: Number(env('VITE_PRICE_ENTERPRISE', '24799')),

  // Email
  emailFrom:       env('VITE_EMAIL_FROM', 'noreply@example.com'),

  // Google Places
  googlePlacesKey: env('VITE_GOOGLE_PLACES_KEY'),

  // App
  adminEmail:      env('VITE_ADMIN_EMAIL', 'owner@masteredge.tech'),
  appUrl:          env('VITE_APP_URL', window.location.origin),
};
