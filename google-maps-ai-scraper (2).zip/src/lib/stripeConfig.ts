/*
 * Stripe Configuration — Masteredge Technology
 *
 * Price IDs are hardcoded (public, safe for frontend).
 * Publishable Key is read from owner Settings (localStorage).
 *
 * Owner enters pk_test_xxx in Settings → works for their browser.
 * For ALL browsers: paste pk_test_xxx below in publishableKey.
 */

export const STRIPE_CONFIG = {
  // ⬇️ OWNER: Paste your Publishable Key here for all browsers to work
  // Get from: https://dashboard.stripe.com/test/apikeys
  publishableKey: '',  // e.g. 'pk_test_51Td5UH...'

  // Price IDs (already configured)
  priceIds: {
    pro:        'price_1Td5h4FJgTEtos9SF6uFNvgH',
    agency:     'price_1Td5hfFJgTEtos9S2lm1r49Q',
    enterprise: 'price_1Td5iBFJgTEtos9SiSuNNCjj',
  },

  mode: 'test' as 'test' | 'live',
};

export function getStripeKey(): string {
  if (STRIPE_CONFIG.publishableKey) return STRIPE_CONFIG.publishableKey;
  return localStorage.getItem('ms_owner_stripe_pk') || '';
}

export function getStripePriceId(plan: 'pro' | 'agency' | 'enterprise'): string {
  if (STRIPE_CONFIG.priceIds[plan]) return STRIPE_CONFIG.priceIds[plan];
  return localStorage.getItem(`ms_owner_stripe_price_${plan}`) || '';
}

export function isStripeConfigured(): boolean {
  return !!(getStripeKey() && (getStripePriceId('pro') || getStripePriceId('agency') || getStripePriceId('enterprise')));
}
