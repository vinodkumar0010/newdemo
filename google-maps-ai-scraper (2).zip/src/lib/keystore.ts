/*
 * Key Store — saves all API keys / config to localStorage
 * Every key the user enters in Settings is stored here.
 * Other modules read from here at runtime.
 */

const PREFIX = 'ms_key_';

const KEYS = {
  googlePlaces:    'google_places',
  payuMerchantKey: 'payu_merchant_key',
  payuMerchantSalt:'payu_merchant_salt',
  payuMode:        'payu_mode',
  resendApiKey:    'resend_api_key',
  emailFrom:       'email_from',
  supabaseUrl:     'supabase_url',
  supabaseKey:     'supabase_key',
  openaiKey:       'openai_key',
  sheetsId:        'sheets_id',
} as const;

export type KeyName = keyof typeof KEYS;

export function getKey(name: KeyName): string {
  return localStorage.getItem(PREFIX + KEYS[name]) || '';
}

export function setKey(name: KeyName, value: string) {
  if (value) localStorage.setItem(PREFIX + KEYS[name], value);
  else localStorage.removeItem(PREFIX + KEYS[name]);
}

export function hasKey(name: KeyName): boolean {
  return !!localStorage.getItem(PREFIX + KEYS[name]);
}

export function getAllKeys(): Record<KeyName, string> {
  const result: any = {};
  for (const [k] of Object.entries(KEYS)) {
    result[k] = getKey(k as KeyName);
  }
  return result;
}

export function clearAllKeys() {
  for (const v of Object.values(KEYS)) {
    localStorage.removeItem(PREFIX + v);
  }
}
