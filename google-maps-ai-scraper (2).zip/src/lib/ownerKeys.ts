/*
 * Owner Keys — Stripe + Google OAuth keys saved by the owner/admin
 * Entered once in Settings and used by payment + auth systems.
 */
const P = 'ms_owner_';

export function getOwnerKey(k: string): string {
  return localStorage.getItem(P + k) || '';
}
export function setOwnerKey(k: string, v: string) {
  if (v) localStorage.setItem(P + k, v);
  else localStorage.removeItem(P + k);
}
export function hasOwnerKey(k: string): boolean {
  return !!localStorage.getItem(P + k);
}

// Stripe
export const getStripePublishableKey = () => getOwnerKey('stripe_pk');
export const getStripeMode = () => getOwnerKey('stripe_mode') || 'test';

// Stripe Price IDs
export const getStripePricePro = () => getOwnerKey('stripe_price_pro');
export const getStripePriceAgency = () => getOwnerKey('stripe_price_agency');
export const getStripePriceEnterprise = () => getOwnerKey('stripe_price_enterprise');

// Google OAuth
export const getGoogleClientId = () => getOwnerKey('google_client_id');
export const getGoogleClientSecret = () => getOwnerKey('google_client_secret');

// Resend (email sending)
export const getResendApiKey = () => getOwnerKey('resend_api_key');
export const getResendFromEmail = () => getOwnerKey('resend_from') || 'noreply@example.com';
