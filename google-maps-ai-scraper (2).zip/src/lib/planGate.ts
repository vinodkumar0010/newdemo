/*
 * Plan Feature Gate — controls which features each plan can access
 */

import { NavSection } from '../types';

export type PlanId = 'free' | 'pro' | 'agency' | 'enterprise';

export interface PlanLimits {
  dailyLeads: number;           // max leads per day
  sections: NavSection[];       // which sidebar tabs are accessible
  features: string[];           // feature keys for fine-grained checks
}

export const PLAN_CONFIG: Record<PlanId, PlanLimits> = {
  free: {
    dailyLeads: 100,  // 100 leads per day for free users
    sections: ['dashboard', 'scraper', 'leads', 'analytics', 'pricing', 'help', 'settings'],
    features: ['csv_export', 'basic_scraper', 'limited_email'],
  },
  pro: {
    dailyLeads: 999999,
    sections: ['dashboard', 'scraper', 'leads', 'ai-analysis', 'crm', 'analytics', 'pricing', 'help', 'settings'],
    features: ['csv_export', 'excel_export', 'basic_scraper', 'unlimited_scraping', 'ai_email_finder', 'ai_lead_scoring', 'sheets_sync', 'website_analysis', 'ai_opportunity', 'smart_filters', 'limited_email'],
  },
  agency: {
    dailyLeads: 999999,
    sections: ['dashboard', 'scraper', 'leads', 'ai-analysis', 'outreach', 'crm', 'analytics', 'team', 'pricing', 'help', 'settings'],
    features: ['csv_export', 'excel_export', 'basic_scraper', 'unlimited_scraping', 'ai_email_finder', 'ai_lead_scoring', 'sheets_sync', 'website_analysis', 'ai_opportunity', 'smart_filters', 'limited_email', 'team_workspace', 'ai_outreach', 'voice_export', 'white_label', 'api_access', 'pdf_reports'],
  },
  enterprise: {
    dailyLeads: 999999,
    sections: ['dashboard', 'scraper', 'leads', 'ai-analysis', 'outreach', 'crm', 'analytics', 'team', 'pricing', 'help', 'settings'],
    features: ['csv_export', 'excel_export', 'basic_scraper', 'unlimited_scraping', 'ai_email_finder', 'ai_lead_scoring', 'sheets_sync', 'website_analysis', 'ai_opportunity', 'smart_filters', 'limited_email', 'team_workspace', 'ai_outreach', 'voice_export', 'white_label', 'api_access', 'pdf_reports', 'unlimited_users', 'custom_branding', 'dedicated_infra', 'sla', 'custom_ai', 'onboarding'],
  },
};

export function canAccessSection(plan: PlanId, section: NavSection): boolean {
  return PLAN_CONFIG[plan].sections.includes(section);
}

export function canUseFeature(plan: PlanId, feature: string): boolean {
  return PLAN_CONFIG[plan].features.includes(feature);
}

export function getLeadLimit(plan: PlanId): number {
  return PLAN_CONFIG[plan].dailyLeads;
}

// Label for the lock overlay
export function getRequiredPlan(section: NavSection): PlanId {
  if (PLAN_CONFIG.free.sections.includes(section)) return 'free';
  if (PLAN_CONFIG.pro.sections.includes(section)) return 'pro';
  if (PLAN_CONFIG.agency.sections.includes(section)) return 'agency';
  return 'enterprise';
}
