/*
 * Supabase Client
 *
 * SETUP:
 * 1. npm install @supabase/supabase-js
 * 2. Fill VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env
 * 3. Change isSupabaseConfigured to true below
 */

export const SUPABASE_URL: string = (import.meta as any).env?.VITE_SUPABASE_URL ?? '';
export const SUPABASE_KEY: string = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY ?? '';

// ⬇️ STEP: Change to true after installing @supabase/supabase-js + filling .env
export const isSupabaseConfigured = false;

export async function getSupabase(): Promise<any> {
  if (!isSupabaseConfigured) return null;
  // Dynamic import — only loads if package is installed
  try {
    const mod = await (Function('return import("@supabase/supabase-js")')());
    return mod.createClient(SUPABASE_URL, SUPABASE_KEY);
  } catch { return null; }
}
