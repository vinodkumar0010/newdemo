/*
 * Browser Notification Helper
 * Fires real desktop/mobile notifications when enabled in Settings
 */

type NotifKey = 'scrapeComplete' | 'hotLeadFound' | 'emailFound' | 'exportReady';

function getSettings(): Record<NotifKey, boolean> {
  try {
    const s = localStorage.getItem('ms_notifications');
    return s ? JSON.parse(s) : { scrapeComplete: true, hotLeadFound: true, emailFound: false, exportReady: true };
  } catch {
    return { scrapeComplete: true, hotLeadFound: true, emailFound: false, exportReady: true };
  }
}

function canNotify(): boolean {
  return 'Notification' in window && Notification.permission === 'granted';
}

export function fireNotification(key: NotifKey, title: string, body: string) {
  const settings = getSettings();
  if (!settings[key]) return;
  if (!canNotify()) return;

  try {
    new Notification(title, {
      body,
      icon: '/masteredge-logo.png',
      badge: '/masteredge-logo.png',
      tag: key, // prevents duplicate notifications
    });
  } catch {
    // Mobile Safari doesn't support Notification constructor
  }
}

// Specific notification functions
export const notifyScrapeComplete = (count: number) =>
  fireNotification('scrapeComplete', '✅ Scraping Complete!', `${count} leads found and saved.`);

export const notifyHotLead = (name: string, score: number) =>
  fireNotification('hotLeadFound', `🔥 Hot Lead Found!`, `${name} — Score: ${score}/100`);

export const notifyEmailFound = (email: string, business: string) =>
  fireNotification('emailFound', `📧 Email Discovered!`, `${email} for ${business}`);

export const notifyExportReady = (count: number, format: string) =>
  fireNotification('exportReady', `📁 Export Ready!`, `${count} leads exported as ${format}`);
