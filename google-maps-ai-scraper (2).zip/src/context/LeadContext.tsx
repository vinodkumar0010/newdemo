import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Lead } from '../types';
import { notifyScrapeComplete, notifyHotLead, notifyEmailFound } from '../lib/notify';

const LEADS_STORAGE = 'maps_scraper_leads';
const API_KEY_STORAGE = 'maps_scraper_google_api_key';

interface LeadContextType {
  leads: Lead[];
  addLeads: (newLeads: Lead[]) => void;
  updateLead: (id: string, data: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  deleteLeads: (ids: string[]) => void;
  clearLeads: () => void;
  count: number;
  apiKey: string;
  setApiKey: (key: string) => void;
  scrapeGoogle: (query: string, onProgress: (leads: Lead[], progress: number, status: string) => void, maxResults?: number) => Promise<Lead[]>;
  isScraping: boolean;
  stopScraping: () => void;
  todayScrapedCount: number;
}

/* ── Dedup key: normalize business name + phone for uniqueness ── */
function dedupKey(l: Lead): string {
  const name = (l.businessName || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const phone = (l.phone || '').replace(/[^0-9]/g, '').slice(-10);
  const addr = (l.address || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20);
  return `${name}_${phone}_${addr}`;
}

/* ── Daily scrape counter ── */
const DAILY_KEY = 'ms_daily_scrape';
function getTodayKey(): string { return new Date().toISOString().slice(0, 10); }
function getTodayCount(): number {
  try { const d = JSON.parse(localStorage.getItem(DAILY_KEY) || '{}'); return d.date === getTodayKey() ? (d.count || 0) : 0; } catch { return 0; }
}
function addTodayCount(n: number) {
  const d = JSON.parse(localStorage.getItem(DAILY_KEY) || '{}');
  const today = getTodayKey();
  const count = (d.date === today ? (d.count || 0) : 0) + n;
  localStorage.setItem(DAILY_KEY, JSON.stringify({ date: today, count }));
}

const LeadContext = createContext<LeadContextType | undefined>(undefined);

/* ─── storage helpers ─── */
function loadLeads(): Lead[] { try { const r = localStorage.getItem(LEADS_STORAGE); return r ? JSON.parse(r) : []; } catch { return []; } }
function saveLeads(leads: Lead[]) { localStorage.setItem(LEADS_STORAGE, JSON.stringify(leads)); }
function loadApiKey(): string { return localStorage.getItem(API_KEY_STORAGE) || ''; }
function saveApiKey(key: string) { localStorage.setItem(API_KEY_STORAGE, key); }

/* ─── CORS proxy to fetch any website from the browser ─── */
const PROXIES = [
  (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
  (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
  (url: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`,
];

async function fetchViaProxy(url: string): Promise<string> {
  for (const mkUrl of PROXIES) {
    try {
      const res = await fetch(mkUrl(url), { signal: AbortSignal.timeout(8000) });
      if (res.ok) { const t = await res.text(); if (t.length > 100) return t; }
    } catch { /* try next */ }
  }
  return '';
}

/* ─── extract emails from HTML text ─── */
function extractEmails(html: string): { email: string; type: string; confidence: number }[] {
  const found: { email: string; type: string; confidence: number }[] = [];
  const seen = new Set<string>();
  // robust email regex
  const re = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) {
    const e = m[0].toLowerCase();
    if (seen.has(e)) continue;
    // skip image/asset emails
    if (/\.(png|jpg|gif|svg|woff|css|js)$/i.test(e)) continue;
    if (e.includes('example.com') || e.includes('sentry.io') || e.includes('wordpress')) continue;
    seen.add(e);
    let type = 'General';
    let conf = 75;
    if (/info@|hello@|contact@|enquir/i.test(e)) { type = 'General'; conf = 95; }
    else if (/sales@|business@|partner/i.test(e)) { type = 'Sales'; conf = 90; }
    else if (/support@|help@|service/i.test(e)) { type = 'Support'; conf = 85; }
    else if (/admin@|office@|reception/i.test(e)) { type = 'Admin'; conf = 80; }
    else if (/hr@|career|recruit|job/i.test(e)) { type = 'HR'; conf = 70; }
    else { conf = 70; }
    found.push({ email: e, type, confidence: conf });
  }
  return found.sort((a, b) => b.confidence - a.confidence);
}

/* ─── extract social media links from HTML ─── */
function extractSocials(html: string): Lead['socialMedia'] {
  const s: Lead['socialMedia'] = {};
  const fbm = html.match(/https?:\/\/(?:www\.)?facebook\.com\/([a-zA-Z0-9._\-]+)/i);
  if (fbm) s.facebook = fbm[1];
  const igm = html.match(/https?:\/\/(?:www\.)?instagram\.com\/([a-zA-Z0-9._]+)/i);
  if (igm) s.instagram = igm[1];
  const lim = html.match(/https?:\/\/(?:www\.)?linkedin\.com\/(?:company|in)\/([a-zA-Z0-9._\-]+)/i);
  if (lim) s.linkedin = lim[1];
  const ytm = html.match(/https?:\/\/(?:www\.)?youtube\.com\/(?:@|channel\/|c\/|user\/)([a-zA-Z0-9._\-]+)/i);
  if (ytm) s.youtube = ytm[1];
  const twm = html.match(/https?:\/\/(?:www\.)?(?:twitter|x)\.com\/([a-zA-Z0-9._]+)/i);
  if (twm && twm[1] !== 'intent' && twm[1] !== 'share') s.twitter = twm[1];
  const wam = html.match(/https?:\/\/(?:wa\.me|api\.whatsapp\.com\/send)\/?[?]?(?:phone=)?(\+?[0-9]+)/i);
  if (wam) s.whatsapp = wam[1];
  return s;
}

/* ─── detect decision-maker names from HTML ─── */
function extractDecisionMaker(html: string): Lead['decisionMaker'] | undefined {
  // look for common patterns: "CEO", "Founder", "Director", "Owner" near a name
  const titles = ['CEO', 'Founder', 'Director', 'Owner', 'Principal', 'Managing Partner', 'Managing Director'];
  for (const title of titles) {
    // pattern: Name — Title or Title: Name
    const re1 = new RegExp(`([A-Z][a-z]+ [A-Z][a-z]+)\\s*[,\\-–|]\\s*${title}`, 'i');
    const re2 = new RegExp(`${title}\\s*[,:\\-–|]\\s*([A-Z][a-z]+ [A-Z][a-z]+)`, 'i');
    const m1 = html.match(re1);
    if (m1) return { name: m1[1], position: title };
    const m2 = html.match(re2);
    if (m2) return { name: m2[1], position: title };
  }
  return undefined;
}

/* ─── check website quality signals from HTML ─── */
function analyzeWebsite(html: string): { score: number; seoIssues: string[] } {
  const issues: string[] = [];
  let score = 50;
  const lower = html.toLowerCase();
  if (lower.includes('<meta name="description"')) score += 8; else issues.push('Missing Meta Description');
  if (lower.includes('schema.org') || lower.includes('"@type"')) score += 7; else issues.push('Missing Schema Markup');
  if (lower.includes('gtag') || lower.includes('google-analytics') || lower.includes('googletagmanager')) score += 6; else issues.push('No Google Analytics');
  if (lower.includes('fbq(') || lower.includes('facebook.com/tr')) score += 5; else issues.push('No Facebook Pixel');
  if (lower.includes('viewport')) score += 5; else issues.push('Not Mobile Friendly');
  if (lower.includes('canonical')) score += 4;
  if (lower.includes('<h1')) score += 3; else issues.push('Missing H1 Tag');
  if (lower.includes('alt="') || lower.includes("alt='")) score += 3; else issues.push('Missing Image Alt Tags');
  if (lower.includes('og:title') || lower.includes('og:image')) score += 4; else issues.push('Missing Open Graph Tags');
  if (lower.includes('twitter:card')) score += 3;
  return { score: Math.min(100, score), seoIssues: issues };
}

/* ─── ENRICHMENT: fetch website, extract emails+socials+SEO ─── */
async function enrichLead(lead: Lead): Promise<Partial<Lead>> {
  if (!lead.website) return {};
  const url = lead.website.startsWith('http') ? lead.website : `https://${lead.website}`;

  const html = await fetchViaProxy(url);
  if (!html) return {};

  const emails = extractEmails(html);
  const socials = extractSocials(html);
  const dm = extractDecisionMaker(html);
  const { score: wsScore, seoIssues } = analyzeWebsite(html);

  const bestEmail = emails[0];
  const salesEmail = emails.find(e => e.type === 'Sales');

  const enriched: Partial<Lead> = {
    socialMedia: { ...lead.socialMedia, ...socials },
    websiteScore: wsScore,
    seoIssues,
  };

  if (bestEmail) {
    enriched.email = bestEmail.email;
    enriched.emailConfidence = bestEmail.confidence;
    enriched.emailStatus = bestEmail.confidence >= 90 ? 'verified' : bestEmail.confidence >= 70 ? 'valid' : 'risky';
  }
  if (salesEmail && salesEmail.email !== bestEmail?.email) {
    enriched.salesEmail = salesEmail.email;
  }
  if (dm) enriched.decisionMaker = dm;

  // recalculate opportunities
  const opps: string[] = [];
  if (wsScore < 50) opps.push('Website Redesign');
  if (seoIssues.length > 3) opps.push('SEO Services');
  if ((lead.reviews || 0) < 30) opps.push('Google Ads');
  if (!html.toLowerCase().includes('chat') && !html.toLowerCase().includes('messenger')) opps.push('AI Chatbot');
  if (!socials.facebook && !socials.instagram) opps.push('Social Media Marketing');
  if (opps.length > 0) enriched.opportunities = opps;

  // recalculate score
  let score = 30;
  if (wsScore < 50) score += 15;
  if ((lead.rating || 0) > 0 && (lead.rating || 0) < 4) score += 15;
  if ((lead.reviews || 0) > 100) score += 10;
  if (!bestEmail) score += 10;
  if (Object.values(socials).filter(Boolean).length === 0) score += 10;
  if (seoIssues.length > 3) score += 10;
  score = Math.min(99, Math.max(15, score));
  enriched.leadScore = score;
  enriched.leadCategory = score >= 75 ? 'hot' : score >= 50 ? 'warm' : 'cold';

  if (lead.reviews && lead.rating) {
    enriched.reviewSentiment = `${lead.businessName} has ${lead.reviews} reviews (${lead.rating}★). ${
      lead.rating >= 4.5 ? 'Excellent reputation — harder to pitch but premium client.' :
      lead.rating >= 4 ? 'Good reputation. May need marketing/SEO to grow further.' :
      lead.rating >= 3 ? 'Mixed reviews — great opportunity to pitch reputation management.' :
      'Low ratings — strong opportunity for service improvement solutions.'
    }`;
  }

  return enriched;
}

/* ─── map Google Places API response to Lead ─── */
let idCounter = Date.now();
function placeToLead(place: any): Lead {
  idCounter++;
  const name: string = place.displayName?.text || place.name || 'Unknown';
  const rawAddr: string = place.formattedAddress || place.formatted_address || '';
  const parts = rawAddr.split(',').map((s: string) => s.trim());
  const city = parts.length >= 3 ? parts[parts.length - 3] : parts.length >= 2 ? parts[parts.length - 2] : parts[0] || '';
  const state = parts.length >= 2 ? parts[parts.length - 2] : '';
  const country = parts.length >= 1 ? parts[parts.length - 1] : '';
  const rating = place.rating ?? 0;
  const reviews = place.userRatingCount ?? place.user_ratings_total ?? 0;
  const rawWeb = place.websiteUri || place.website || '';
  const website = rawWeb.replace(/^https?:\/\//, '').replace(/\/$/, '') || undefined;
  const phone = place.internationalPhoneNumber || place.nationalPhoneNumber || place.formatted_phone_number || place.international_phone_number || undefined;
  const mapsUrl = place.googleMapsUri || place.url || `https://maps.google.com/?q=${encodeURIComponent(name + ' ' + rawAddr)}`;
  const lat = place.location?.latitude ?? place.geometry?.location?.lat ?? 0;
  const lng = place.location?.longitude ?? place.geometry?.location?.lng ?? 0;
  const types: string[] = place.types || [];
  const skipTypes = ['point_of_interest', 'establishment', 'store', 'food', 'health', 'political', 'locality'];
  const category = types.find((t: string) => !skipTypes.includes(t))
    ?.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()) || 'Business';

  // hours
  const hours = place.regularOpeningHours?.weekdayDescriptions?.join(', ')
    || place.opening_hours?.weekday_text?.join(', ') || undefined;

  return {
    id: `scraped-${idCounter}`,
    businessName: name, category,
    address: parts.slice(0, Math.max(1, parts.length - 2)).join(', ') || rawAddr,
    city, state, country,
    website, phone, hours,
    rating, reviews,
    googleMapsUrl: mapsUrl, lat, lng,
    leadScore: 40,
    leadCategory: 'warm',
    websiteScore: 0,
    opportunities: [],
    socialMedia: {},
    emailConfidence: 0,
    emailStatus: 'invalid',
    seoIssues: [],
    reviewSentiment: '',
    scrapedAt: new Date().toISOString(),
  };
}

/* All demo/fake data generation has been removed.
   Only real data from Google Places API is returned.
   Users MUST enter a valid Google API key in Settings to scrape. */

/* ─── PROVIDER ─── */
export function LeadCountProvider({ children }: { children: ReactNode }) {
  const [leads, setLeads] = useState<Lead[]>(loadLeads);
  const [apiKey, setApiKeyState] = useState(loadApiKey);
  const [isScraping, setIsScraping] = useState(false);
  const [abortRef] = useState<{ current: boolean }>({ current: false });

  useEffect(() => { saveLeads(leads); }, [leads]);

  const setApiKey = useCallback((key: string) => { setApiKeyState(key); saveApiKey(key); }, []);

  const addLeads = useCallback((newLeads: Lead[]) => {
    setLeads(prev => {
      // Strong dedup: match by normalized name + phone + address
      const existingKeys = new Set(prev.map(l => dedupKey(l)));
      const unique = newLeads.filter(l => {
        const key = dedupKey(l);
        if (existingKeys.has(key)) return false;
        existingKeys.add(key); // prevent duplicates within the new batch too
        return true;
      });
      addTodayCount(unique.length);
      return [...prev, ...unique];
    });
  }, []);

  const updateLead = useCallback((id: string, data: Partial<Lead>) => {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, ...data } : l));
  }, []);

  const deleteLead = useCallback((id: string) => setLeads(p => p.filter(l => l.id !== id)), []);
  const deleteLeads = useCallback((ids: string[]) => { const s = new Set(ids); setLeads(p => p.filter(l => !s.has(l.id))); }, []);
  const clearLeads = useCallback(() => setLeads([]), []);
  const stopScraping = useCallback(() => { abortRef.current = true; }, [abortRef]);

  const todayScrapedCount = getTodayCount();

  /* ─── Main scrape function ─── */
  const scrapeGoogle = useCallback(async (
    query: string,
    onProgress: (leads: Lead[], progress: number, status: string) => void,
    maxResults: number = 100,
  ): Promise<Lead[]> => {
    setIsScraping(true);
    abortRef.current = false;
    const allResults: Lead[] = [];
    const key = apiKey || loadApiKey();
    const cap = Math.min(maxResults, 100); // hard cap at 100 per scrape

    // Get existing keys for dedup during scraping
    const existingKeys = new Set(loadLeads().map(l => dedupKey(l)));
    const isDuplicate = (lead: Lead): boolean => {
      const k = dedupKey(lead);
      if (existingKeys.has(k)) return true;
      existingKeys.add(k);
      return false;
    };

    if (!key) {
      // No API key — stop immediately, no fake data
      onProgress([], 0, 'No Google API Key — add your key in Settings');
      setIsScraping(false);
      return [];
    }

    // ── Real API mode ──
    try {
      onProgress([], 5, 'Calling Google Places API…');

      let places: any[] = [];
      const fieldMask = [
        'places.displayName', 'places.formattedAddress',
        'places.internationalPhoneNumber', 'places.nationalPhoneNumber',
        'places.websiteUri', 'places.googleMapsUri',
        'places.rating', 'places.userRatingCount',
        'places.types', 'places.location', 'places.businessStatus',
        'places.regularOpeningHours',
      ].join(',');

      try {
        const res = await fetch('https://places.googleapis.com/v1/places:searchText', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': fieldMask },
          body: JSON.stringify({ textQuery: query, maxResultCount: 20 }),
        });
        if (res.ok) {
          const data = await res.json();
          places = data.places || [];
        }
      } catch { /* API call failed */ }

      if (places.length === 0) {
        onProgress([], 100, 'No results found for this search. Try a different query or location.');
        setIsScraping(false);
        return [];
      }

      // ── Step 1: Parse all places ──
      onProgress([], 10, `Found ${places.length} businesses — parsing…`);
      for (let i = 0; i < places.length; i++) {
        if (abortRef.current || allResults.length >= cap) break;
        const lead = placeToLead(places[i]);
        if (isDuplicate(lead)) continue; // skip duplicate
        allResults.push(lead);
        onProgress([...allResults], 10 + Math.round((allResults.length / Math.min(places.length, cap)) * 20), `Parsed ${allResults.length}: ${lead.businessName}`);
      }

      // ── Step 2: Enrich each lead by crawling their website ──
      onProgress([...allResults], 30, 'Enriching leads — scanning websites for emails & social media…');
      const withWebsite = allResults.filter(l => l.website);
      let enriched = 0;

      for (let i = 0; i < allResults.length; i++) {
        if (abortRef.current) break;
        const lead = allResults[i];

        if (lead.website) {
          const pct = 30 + Math.round((enriched / Math.max(1, withWebsite.length)) * 65);
          onProgress([...allResults], pct, `Scanning ${lead.website}…`);

          try {
            const data = await enrichLead(lead);
            if (Object.keys(data).length > 0) {
              Object.assign(allResults[i], data);
              onProgress([...allResults], pct, `✓ ${lead.businessName}: ${data.email ? 'Email found!' : 'Socials found'}`);
            }
          } catch { /* enrichment failed for this lead */ }
          enriched++;
        } else {
          // no website — mark as high-opportunity
          allResults[i].opportunities = ['Website Redesign', 'SEO Services', 'Google Ads'];
          allResults[i].leadScore = Math.min(99, 70 + Math.floor(Math.random() * 20));
          allResults[i].leadCategory = allResults[i].leadScore >= 75 ? 'hot' : 'warm';
          allResults[i].seoIssues = ['No Website Found', 'Missing Online Presence'];
        }

        // tiny delay between enrichments
        await new Promise(r => setTimeout(r, 300));
      }

      onProgress([...allResults], 98, 'Saving results…');
      if (!abortRef.current) {
        addLeads(allResults);
        notifyScrapeComplete(allResults.length);
        allResults.filter(l => l.leadCategory === 'hot').forEach(l => notifyHotLead(l.businessName, l.leadScore));
        allResults.filter(l => l.email).forEach(l => notifyEmailFound(l.email!, l.businessName));
      }
      onProgress([...allResults], 100, 'Complete!');

    } catch (err: any) {
      // API failure — show error, no fake data
      onProgress([], 100, `Scraping failed: ${err?.message || 'Network error'}. Check your API key and try again.`);
    }

    setIsScraping(false);
    return allResults;
  }, [apiKey, addLeads, abortRef]);

  return (
    <LeadContext.Provider value={{
      leads, addLeads, updateLead, deleteLead, deleteLeads, clearLeads,
      count: leads.length, apiKey, setApiKey, scrapeGoogle, isScraping, stopScraping, todayScrapedCount,
    }}>
      {children}
    </LeadContext.Provider>
  );
}

export function useLeadCount() {
  const ctx = useContext(LeadContext);
  if (!ctx) throw new Error('useLeadCount must be used within LeadCountProvider');
  return ctx;
}
