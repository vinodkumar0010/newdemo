import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';

export type TeamRole = 'admin' | 'scraper' | 'outreach' | 'analyst' | 'viewer';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  password: string;       // login password
  role: TeamRole;
  status: 'online' | 'away' | 'offline';
  joinedAt: string;
  leadsAssigned: number;
  color: string;
}

export interface ActivityLogItem {
  id: string;
  userId: string;
  userName: string;
  action: string;
  detail: string;
  timestamp: string;
}

export interface TeamNote {
  id: string;
  leadName: string;
  note: string;
  userId: string;
  userName: string;
  timestamp: string;
}

interface TeamContextType {
  members: TeamMember[];
  addMember: (name: string, email: string, role: TeamRole, password: string) => { success: boolean; message: string };
  removeMember: (id: string) => void;
  updateMemberRole: (id: string, role: TeamRole) => void;
  updateMemberStatus: (id: string, status: TeamMember['status']) => void;
  activityLog: ActivityLogItem[];
  addActivity: (userName: string, action: string, detail: string) => void;
  notes: TeamNote[];
  addNote: (leadName: string, note: string, userName: string) => void;
  removeNote: (id: string) => void;
  rolePermissions: Record<TeamRole, string[]>;
}

const MEMBERS_KEY = 'maps_scraper_team_members';
const ACTIVITY_KEY = 'maps_scraper_team_activity';
const NOTES_KEY = 'maps_scraper_team_notes';

const COLORS = ['bg-blue-500', 'bg-violet-500', 'bg-emerald-500', 'bg-amber-500', 'bg-pink-500', 'bg-cyan-500', 'bg-red-500', 'bg-indigo-500', 'bg-teal-500', 'bg-orange-500'];

const ROLE_PERMISSIONS: Record<TeamRole, string[]> = {
  admin:    ['Scrape', 'View Leads', 'Export', 'Sheets Sync', 'Manage Team', 'Analytics', 'Outreach', 'Settings', 'AI Analysis'],
  scraper:  ['Scrape', 'View Leads', 'Export'],
  outreach: ['View Leads', 'Generate Outreach', 'Export', 'AI Analysis'],
  analyst:  ['View Leads', 'Analytics', 'AI Analysis', 'Export'],
  viewer:   ['View Leads'],
};

function load<T>(key: string, fallback: T): T {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fallback; } catch { return fallback; }
}
function save(key: string, val: unknown) { localStorage.setItem(key, JSON.stringify(val)); }

const TeamContext = createContext<TeamContextType | undefined>(undefined);

export function TeamProvider({ children }: { children: ReactNode }) {
  const [members, setMembers] = useState<TeamMember[]>(() => load(MEMBERS_KEY, []));
  const [activityLog, setActivityLog] = useState<ActivityLogItem[]>(() => load(ACTIVITY_KEY, []));
  const [notes, setNotes] = useState<TeamNote[]>(() => load(NOTES_KEY, []));

  useEffect(() => { save(MEMBERS_KEY, members); }, [members]);
  useEffect(() => { save(ACTIVITY_KEY, activityLog); }, [activityLog]);
  useEffect(() => { save(NOTES_KEY, notes); }, [notes]);

  const addMember = useCallback((name: string, email: string, role: TeamRole, password: string): { success: boolean; message: string } => {
    if (!name.trim() || !email.trim()) return { success: false, message: 'Name and email are required' };
    if (!password || password.length < 6) return { success: false, message: 'Password must be at least 6 characters' };
    if (members.some(m => m.email.toLowerCase() === email.toLowerCase())) return { success: false, message: 'A member with this email already exists' };

    // Hash the password before storing
    const hashPw = (pw: string): string => { let h = 0; for (let i = 0; i < pw.length; i++) { h = ((h << 5) - h) + pw.charCodeAt(i); h |= 0; } return 'h$' + Math.abs(h).toString(36); };
    const hashedPw = hashPw(password);

    // Create login account in Auth storage
    const AUTH_STORAGE = 'maps_scraper_users';
    try {
      const raw = localStorage.getItem(AUTH_STORAGE);
      const authUsers = raw ? JSON.parse(raw) : [];
      const exists = authUsers.some((u: any) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!exists) {
        authUsers.push({
          id: `tm-auth-${Date.now()}`,
          name: name.trim(),
          email: email.trim().toLowerCase(),
          password: hashedPw,
          role: role === 'admin' ? 'admin' : 'user',
          plan: 'agency',
          createdAt: new Date().toISOString(),
        });
        localStorage.setItem(AUTH_STORAGE, JSON.stringify(authUsers));
      }
    } catch { /* ignore */ }

    const member: TeamMember = {
      id: `tm-${Date.now()}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password: '••••••••', // never store real password
      role,
      status: 'online',
      joinedAt: new Date().toISOString(),
      leadsAssigned: 0,
      color: COLORS[members.length % COLORS.length],
    };
    setMembers(prev => [...prev, member]);
    setActivityLog(prev => [{ id: `act-${Date.now()}`, userId: member.id, userName: 'System', action: 'Member added', detail: `${member.name} (${role}) joined the team — account created`, timestamp: new Date().toISOString() }, ...prev]);
    return { success: true, message: `${name} added as ${role}` };
  }, [members]);

  const removeMember = useCallback((id: string) => {
    const m = members.find(x => x.id === id);
    setMembers(prev => prev.filter(x => x.id !== id));
    // Also remove from Auth storage
    if (m) {
      try {
        const AUTH_STORAGE = 'maps_scraper_users';
        const raw = localStorage.getItem(AUTH_STORAGE);
        if (raw) {
          const authUsers = JSON.parse(raw).filter((u: any) => u.email.toLowerCase() !== m.email.toLowerCase());
          localStorage.setItem(AUTH_STORAGE, JSON.stringify(authUsers));
        }
      } catch { /* ignore */ }
      setActivityLog(prev => [{ id: `act-${Date.now()}`, userId: id, userName: 'System', action: 'Member removed', detail: `${m.name} removed — login account deleted`, timestamp: new Date().toISOString() }, ...prev]);
    }
  }, [members]);

  const updateMemberRole = useCallback((id: string, role: TeamRole) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, role } : m));
    const m = members.find(x => x.id === id);
    if (m) {
      // Also update Auth role
      try {
        const AUTH_STORAGE = 'maps_scraper_users';
        const raw = localStorage.getItem(AUTH_STORAGE);
        if (raw) {
          const authUsers = JSON.parse(raw);
          const idx = authUsers.findIndex((u: any) => u.email.toLowerCase() === m.email.toLowerCase());
          if (idx >= 0) { authUsers[idx].role = role === 'admin' ? 'admin' : 'user'; localStorage.setItem(AUTH_STORAGE, JSON.stringify(authUsers)); }
        }
      } catch { /* ignore */ }
      setActivityLog(prev => [{ id: `act-${Date.now()}`, userId: id, userName: 'System', action: 'Role changed', detail: `${m.name}: ${m.role} → ${role}`, timestamp: new Date().toISOString() }, ...prev]);
    }
  }, [members]);

  const updateMemberStatus = useCallback((id: string, status: TeamMember['status']) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, status } : m));
  }, []);

  const addActivity = useCallback((userName: string, action: string, detail: string) => {
    setActivityLog(prev => [{ id: `act-${Date.now()}-${Math.random()}`, userId: '', userName, action, detail, timestamp: new Date().toISOString() }, ...prev].slice(0, 50));
  }, []);

  const addNote = useCallback((leadName: string, note: string, userName: string) => {
    if (!note.trim()) return;
    setNotes(prev => [{ id: `note-${Date.now()}`, leadName, note: note.trim(), userId: '', userName, timestamp: new Date().toISOString() }, ...prev].slice(0, 100));
  }, []);

  const removeNote = useCallback((id: string) => { setNotes(prev => prev.filter(n => n.id !== id)); }, []);

  return (
    <TeamContext.Provider value={{ members, addMember, removeMember, updateMemberRole, updateMemberStatus, activityLog, addActivity, notes, addNote, removeNote, rolePermissions: ROLE_PERMISSIONS }}>
      {children}
    </TeamContext.Provider>
  );
}

export function useTeam() {
  const ctx = useContext(TeamContext);
  if (!ctx) throw new Error('useTeam must be used within TeamProvider');
  return ctx;
}
