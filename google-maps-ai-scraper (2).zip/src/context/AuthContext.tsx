import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { isSupabaseConfigured, getSupabase } from '../lib/supabase';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'user';
  avatar?: string;
  createdAt: string;
  plan: 'free' | 'pro' | 'agency' | 'enterprise';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; message: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ success: boolean; message: string }>;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  setNewPassword: (token: string, newPassword: string) => { success: boolean; message: string };
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  updatePlan: (plan: User['plan']) => void;
  isAuthenticated: boolean;
  isLoading: boolean;
  needsOwnerSetup: boolean;
  setupOwner: (name: string, email: string, password: string) => void;
}

interface StoredUser extends User { password: string; }
const STORAGE_KEY = 'maps_scraper_users';
const SESSION_KEY = 'maps_scraper_session';
const SETUP_DONE_KEY = 'maps_scraper_owner_setup_done';

function hashPw(pw: string): string {
  let h = 0;
  for (let i = 0; i < pw.length; i++) { h = ((h << 5) - h) + pw.charCodeAt(i); h |= 0; }
  return 'h$' + Math.abs(h).toString(36);
}

function getLocalUsers(): StoredUser[] {
  try { const r = localStorage.getItem(STORAGE_KEY); if (r) return JSON.parse(r); } catch {}
  return [];
}
function saveLocalUsers(u: StoredUser[]) { localStorage.setItem(STORAGE_KEY, JSON.stringify(u)); }
function toPublic(u: StoredUser): User { return { id: u.id, name: u.name, email: u.email, role: u.role, plan: u.plan, createdAt: u.createdAt, avatar: u.avatar }; }

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [needsOwnerSetup, setNeedsOwnerSetup] = useState(false);

  useEffect(() => {
    (async () => {
      const localUsers = getLocalUsers();

      /*
       * Owner Setup:
       *   URL ?setup=owner → ALWAYS shows setup (clears old data)
       *   Normal URL → Login/Signup page
       */
      const urlParams = new URLSearchParams(window.location.search);
      const wantsSetup = urlParams.get('setup') === 'owner';

      if (wantsSetup) {
        // Clear URL immediately so refreshing doesn't re-trigger setup
        window.history.replaceState({}, '', window.location.pathname);
        // Force clear everything for fresh owner setup
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem(SESSION_KEY);
        localStorage.removeItem(SETUP_DONE_KEY);
        setNeedsOwnerSetup(true);
        setIsLoading(false);
        return;
      }

      if (isSupabaseConfigured) {
        const sb = await getSupabase();
        if (sb) {
          const { data } = await sb.auth.getSession();
          if (data?.session?.user) {
            const { data: profile } = await sb.from('profiles').select('*').eq('id', data.session.user.id).single();
            if (profile) setUser({ id: profile.id, name: profile.name, email: profile.email, role: profile.role, plan: profile.plan, createdAt: profile.created_at });
          }
        }
      } else {
        try {
          const raw = localStorage.getItem(SESSION_KEY);
          if (raw) {
            const s = JSON.parse(raw) as User;
            const found = localUsers.find(u => u.id === s.id);
            if (found) setUser(toPublic(found)); else localStorage.removeItem(SESSION_KEY);
          }
        } catch { localStorage.removeItem(SESSION_KEY); }
      }
      setIsLoading(false);
    })();
  }, []);

  // ── Owner first-time setup ──
  const setupOwner = (name: string, email: string, password: string) => {
    const owner: StoredUser = {
      id: 'owner-' + Date.now(),
      name, email: email.toLowerCase(),
      password: hashPw(password),
      role: 'owner', plan: 'enterprise',
      createdAt: new Date().toISOString(),
    };
    // Save owner as the only user (fresh start)
    saveLocalUsers([owner]);
    localStorage.setItem(SETUP_DONE_KEY, 'true');
    // Remove setup param from URL so refresh doesn't re-trigger
    window.history.replaceState({}, '', window.location.pathname);
    // Auto-login
    const pub = toPublic(owner);
    setUser(pub);
    localStorage.setItem(SESSION_KEY, JSON.stringify(pub));
    setNeedsOwnerSetup(false);
  };

  // ── login ──
  const login = async (email: string, password: string): Promise<{ success: boolean; message: string }> => {
    if (isSupabaseConfigured) {
      const sb = await getSupabase();
      if (sb) {
        const { data, error } = await sb.auth.signInWithPassword({ email, password });
        if (error) return { success: false, message: error.message };
        const { data: profile } = await sb.from('profiles').select('*').eq('id', data.user.id).single();
        if (profile) { const u: User = { id: profile.id, name: profile.name, email: profile.email, role: profile.role, plan: profile.plan, createdAt: profile.created_at }; setUser(u); return { success: true, message: `Welcome back, ${u.name.split(' ')[0]}!` }; }
        return { success: false, message: 'Profile not found' };
      }
    }
    const users = getLocalUsers();
    const found = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === hashPw(password));
    if (!found) return { success: false, message: 'Invalid email or password.' };
    const pub = toPublic(found);
    setUser(pub);
    localStorage.setItem(SESSION_KEY, JSON.stringify(pub));
    return { success: true, message: `Welcome back, ${found.name.split(' ')[0]}!` };
  };

  // ── Google OAuth with real credentials ──
  const GOOGLE_CLIENT_ID = '107388845379-8q18caqp7bjqghq3fmqbth1q7iu01dg5.apps.googleusercontent.com';

  const loginWithGoogle = async (): Promise<{ success: boolean; message: string }> => {
    // Supabase path
    if (isSupabaseConfigured) {
      const sb = await getSupabase();
      if (sb) {
        const { error } = await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } });
        if (error) return { success: false, message: error.message };
        return { success: true, message: 'Redirecting to Google…' };
      }
    }

    // Real Google OAuth popup using Google Identity Services
    return new Promise((resolve) => {
      try {
        // Load Google Identity Services script if not already loaded
        const loadGIS = (): Promise<void> => {
          return new Promise((res) => {
            if ((window as any).google?.accounts?.oauth2) { res(); return; }
            const script = document.createElement('script');
            script.src = 'https://accounts.google.com/gsi/client';
            script.async = true;
            script.onload = () => res();
            script.onerror = () => res();
            document.head.appendChild(script);
          });
        };

        loadGIS().then(() => {
          const google = (window as any).google;
          if (!google?.accounts?.oauth2) {
            // Fallback if script failed to load
            resolve(fallbackGoogleLogin());
            return;
          }

          const client = google.accounts.oauth2.initTokenClient({
            client_id: GOOGLE_CLIENT_ID,
            scope: 'email profile',
            callback: async (tokenResponse: any) => {
              if (tokenResponse.error) {
                resolve({ success: false, message: 'Google sign-in was cancelled.' });
                return;
              }

              try {
                // Fetch user info from Google
                const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                  headers: { Authorization: `Bearer ${tokenResponse.access_token}` },
                });
                const profile = await res.json();

                const googleEmail = profile.email?.toLowerCase() || '';
                const googleName = profile.name || profile.given_name || 'Google User';
                const googleAvatar = profile.picture || '';

                if (!googleEmail) {
                  resolve({ success: false, message: 'Could not get email from Google.' });
                  return;
                }

                // Check if user exists, create if not
                const users = getLocalUsers();
                let found = users.find(u => u.email.toLowerCase() === googleEmail);
                if (!found) {
                  found = {
                    id: `google-${Date.now()}`,
                    name: googleName,
                    email: googleEmail,
                    password: '', // Google users don't use password
                    role: 'user',
                    plan: 'free',
                    avatar: googleAvatar,
                    createdAt: new Date().toISOString(),
                  };
                  users.push(found);
                  saveLocalUsers(users);
                } else {
                  // Update name/avatar from Google
                  found.name = googleName;
                  found.avatar = googleAvatar;
                  saveLocalUsers(users);
                }

                const pub = toPublic(found);
                setUser(pub);
                localStorage.setItem(SESSION_KEY, JSON.stringify(pub));
                resolve({ success: true, message: `Welcome, ${googleName}!` });
              } catch {
                resolve({ success: false, message: 'Failed to get Google profile.' });
              }
            },
          });

          client.requestAccessToken();
        });
      } catch {
        resolve(fallbackGoogleLogin());
      }
    });
  };

  // Fallback if Google script fails to load (offline, blocked, etc.)
  const fallbackGoogleLogin = (): { success: boolean; message: string } => {
    const demoEmail = 'google.user@gmail.com';
    const users = getLocalUsers();
    let found = users.find(u => u.email === demoEmail);
    if (!found) { found = { id: `g-${Date.now()}`, name: 'Google User', email: demoEmail, password: '', role: 'user', plan: 'free', createdAt: new Date().toISOString() }; users.push(found); saveLocalUsers(users); }
    const pub = toPublic(found);
    setTimeout(() => { setUser(pub); localStorage.setItem(SESSION_KEY, JSON.stringify(pub)); }, 200);
    return { success: true, message: `Welcome, ${found.name}! (Demo mode — Google script not available)` };
  };

  // ── signup ──
  const signup = async (name: string, email: string, password: string): Promise<{ success: boolean; message: string }> => {
    if (isSupabaseConfigured) {
      const sb = await getSupabase();
      if (sb) {
        const { data, error } = await sb.auth.signUp({ email, password });
        if (error) return { success: false, message: error.message };
        if (data.user) await sb.from('profiles').insert({ id: data.user.id, name, email, role: 'user', plan: 'free' });
        return { success: true, message: 'Account created! Check email to verify.' };
      }
    }
    const users = getLocalUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) return { success: false, message: 'Email already registered.' };
    const nu: StoredUser = { id: `u-${Date.now()}`, name, email, password: hashPw(password), role: 'user', plan: 'free', createdAt: new Date().toISOString() };
    saveLocalUsers([...users, nu]);
    const pub = toPublic(nu);
    setUser(pub);
    localStorage.setItem(SESSION_KEY, JSON.stringify(pub));
    return { success: true, message: 'Account created!' };
  };

  const logout = async () => {
    if (isSupabaseConfigured) { const sb = await getSupabase(); if (sb) await sb.auth.signOut(); }
    setUser(null); localStorage.removeItem(SESSION_KEY);
  };

  const updateProfile = (data: Partial<User>) => {
    if (!user) return;
    const merged = { ...user, ...data }; setUser(merged);
    localStorage.setItem(SESSION_KEY, JSON.stringify(merged));
    if (!isSupabaseConfigured) { const users = getLocalUsers(); const i = users.findIndex(u => u.id === user.id); if (i >= 0) { users[i] = { ...users[i], ...data }; saveLocalUsers(users); } }
  };

  const updatePlan = (plan: User['plan']) => updateProfile({ plan });

  // ── Password Reset ──
  const RESET_TOKEN_KEY = 'maps_scraper_reset_tokens';

  const resetPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    // Supabase path
    if (isSupabaseConfigured) {
      const sb = await getSupabase();
      if (sb) {
        const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + '?reset=true' });
        if (error) return { success: false, message: error.message };
        return { success: true, message: 'Password reset link sent to your email!' };
      }
    }

    // Local path — check user exists
    const users = getLocalUsers();
    const found = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!found) return { success: false, message: 'No account found with this email address.' };

    // Generate token
    const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const tokens = JSON.parse(localStorage.getItem(RESET_TOKEN_KEY) || '{}');
    tokens[token] = { email: found.email, expires: Date.now() + 3600000 }; // 1 hour
    localStorage.setItem(RESET_TOKEN_KEY, JSON.stringify(tokens));

    // Try sending via Resend API
    try {
      const { getResendApiKey, getResendFromEmail } = await import('../lib/ownerKeys');
      const resendKey = getResendApiKey();
      const fromEmail = getResendFromEmail();

      if (resendKey) {
        const resetLink = `${window.location.origin}?reset_token=${token}`;
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${resendKey}` },
          body: JSON.stringify({
            from: fromEmail,
            to: [found.email],
            subject: 'Password Reset — Maps Scraper Pro AI',
            html: `<div style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:20px">
              <h2 style="color:#1e293b">Password Reset Request</h2>
              <p>Hi ${found.name},</p>
              <p>You requested a password reset. Click the button below to set a new password:</p>
              <a href="${resetLink}" style="display:inline-block;padding:12px 24px;background:#3b82f6;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold;margin:16px 0">Reset My Password</a>
              <p style="color:#94a3b8;font-size:13px">This link expires in 1 hour. If you didn't request this, ignore this email.</p>
              <p style="color:#94a3b8;font-size:12px;margin-top:20px">— Masteredge Technology</p>
            </div>`,
          }),
        });
        return { success: true, message: 'Password reset link sent to your email! Check your inbox.' };
      }
    } catch { /* Resend not configured — fallback below */ }

    // Fallback: show the token directly (no email service configured)
    const resetUrl = `${window.location.origin}?reset_token=${token}`;
    console.log('Password reset link (email not configured):', resetUrl);
    return {
      success: true,
      message: `Reset link generated! Since email service is not configured, the owner needs to share this link with you. Token: ${token.slice(0, 8)}…`,
    };
  };

  const setNewPassword = (token: string, newPassword: string): { success: boolean; message: string } => {
    const tokens = JSON.parse(localStorage.getItem(RESET_TOKEN_KEY) || '{}');
    const entry = tokens[token];
    if (!entry) return { success: false, message: 'Invalid or expired reset link.' };
    if (Date.now() > entry.expires) {
      delete tokens[token]; localStorage.setItem(RESET_TOKEN_KEY, JSON.stringify(tokens));
      return { success: false, message: 'Reset link has expired. Request a new one.' };
    }

    const users = getLocalUsers();
    const idx = users.findIndex(u => u.email.toLowerCase() === entry.email.toLowerCase());
    if (idx < 0) return { success: false, message: 'User not found.' };

    users[idx].password = hashPw(newPassword);
    saveLocalUsers(users);
    delete tokens[token]; localStorage.setItem(RESET_TOKEN_KEY, JSON.stringify(tokens));
    return { success: true, message: 'Password updated! You can now login with your new password.' };
  };

  return (
    <AuthContext.Provider value={{ user, login, loginWithGoogle, signup, resetPassword, setNewPassword, logout, updateProfile, updatePlan, isAuthenticated: !!user, isLoading, needsOwnerSetup, setupOwner }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
