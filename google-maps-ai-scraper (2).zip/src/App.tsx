import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LeadCountProvider, useLeadCount } from './context/LeadContext';
import { TeamProvider } from './context/TeamContext';
import ErrorBoundary from './components/ErrorBoundary';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ScraperEngine from './components/ScraperEngine';
import LeadManager from './components/LeadManager';
import AIAnalysis from './components/AIAnalysis';
import AIOutreach from './components/AIOutreach';
import CRMExport from './components/CRMExport';
import Analytics from './components/Analytics';
import TeamWorkspace from './components/TeamWorkspace';
import Pricing from './components/Pricing';
import Settings from './components/Settings';
import AuthPage from './components/AuthPage';
import UpgradeWall from './components/UpgradeWall';
import OwnerSetup from './components/OwnerSetup';
import Help, { FloatingHelpButton } from './components/Help';
import { NavSection } from './types';
import { canAccessSection, PlanId } from './lib/planGate';

const sectionMeta: Record<NavSection, { title: string; subtitle: string }> = {
  dashboard:      { title: 'Dashboard',              subtitle: 'Lead generation overview & live metrics' },
  scraper:        { title: 'Scraper Engine',          subtitle: 'Configure and run Google Maps scraping sessions' },
  leads:          { title: 'Lead Manager',            subtitle: 'Browse, filter, and manage all extracted leads' },
  'ai-analysis':  { title: 'AI Analysis',             subtitle: 'Website scoring, opportunity detection & review intelligence' },
  outreach:       { title: 'AI Outreach Generator',   subtitle: 'Personalized cold emails, LinkedIn & WhatsApp messages' },
  crm:            { title: 'Google Sheets & Export',   subtitle: 'Sync leads to Google Sheets, export CSV/Excel, AI Voice Agent export' },
  analytics:      { title: 'Analytics',               subtitle: 'Charts, trends and performance reporting' },
  team:           { title: 'Team Workspace',           subtitle: 'Collaborate, share leads and manage team activity' },
  pricing:        { title: 'Pricing Plans',            subtitle: 'Upgrade your plan to unlock more features' },
  help:           { title: 'Help & Support',            subtitle: 'Contact us via email or WhatsApp • FAQs • Troubleshooting' },
  settings:       { title: 'Settings',                 subtitle: 'Configure API keys, preferences and account settings' },
};

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center mx-auto mb-4 animate-pulse"><span className="text-white text-lg font-black">ME</span></div>
        <div className="flex items-center gap-1 justify-center mb-2"><span className="text-blue-400 font-black text-lg">MASTER</span><span className="text-red-400 font-black text-lg">EDGE</span></div>
        <div className="w-6 h-6 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto mt-4"></div>
      </div>
    </div>
  );
}

function AppInner() {
  const { user, logout, isAuthenticated, isLoading, needsOwnerSetup, setupOwner } = useAuth();
  const { count: leadCount } = useLeadCount();
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (isLoading) return <LoadingScreen />;
  if (needsOwnerSetup) return <OwnerSetup onComplete={setupOwner} />;
  if (!isAuthenticated || !user) return <AuthPage />;

  const plan = (user.plan || 'free') as PlanId;
  const meta = sectionMeta[activeSection];
  const hasAccess = canAccessSection(plan, activeSection);

  // Render the correct content or upgrade wall
  const renderContent = () => {
    if (!hasAccess) return <UpgradeWall section={activeSection} onNavigate={setActiveSection} />;
    switch (activeSection) {
      case 'dashboard':   return <Dashboard onNavigate={setActiveSection} />;
      case 'scraper':     return <ScraperEngine />;
      case 'leads':       return <LeadManager />;
      case 'ai-analysis': return <AIAnalysis />;
      case 'outreach':    return <AIOutreach />;
      case 'crm':         return <CRMExport />;
      case 'analytics':   return <Analytics />;
      case 'team':        return <TeamWorkspace />;
      case 'pricing':     return <Pricing />;
      case 'help':        return <Help />;
      case 'settings':    return <Settings />;
      default:            return <Dashboard onNavigate={setActiveSection} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-950 text-white">
      <Sidebar
        activeSection={activeSection}
        onSectionChange={setActiveSection}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(prev => !prev)}
        userName={user.name}
        userRole={user.role}
        userPlan={user.plan}
        onLogout={logout}
        leadCount={leadCount}
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header title={meta.title} subtitle={meta.subtitle} user={user} onLogout={logout} onMenuToggle={() => setMobileMenuOpen(true)} />
        <main className="flex-1 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
      {/* Floating Help Button — visible on every page */}
      <FloatingHelpButton onClick={() => setActiveSection('help')} />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ToastProvider>
          <LeadCountProvider>
            <TeamProvider>
              <AppInner />
            </TeamProvider>
          </LeadCountProvider>
        </ToastProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
