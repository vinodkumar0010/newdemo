import React from 'react';
import {
  LayoutDashboard, MapPin, Users, Brain, Mail, Database,
  BarChart3, Settings, CreditCard, ChevronRight, Zap, Building2, Lock, HelpCircle, X,
} from 'lucide-react';
import { NavSection } from '../types';
import { canAccessSection, PlanId } from '../lib/planGate';
import UsageBar from './UsageBar';

interface SidebarProps {
  activeSection: NavSection;
  onSectionChange: (section: NavSection) => void;
  collapsed: boolean;
  onToggle: () => void;
  userName?: string;
  userRole?: string;
  userPlan?: string;
  onLogout?: () => void;
  leadCount?: number;
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

const navItemsDef: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string; badgeColor?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'scraper', label: 'Scraper Engine', icon: MapPin, badge: 'LIVE', badgeColor: 'bg-green-500' },
  { id: 'leads', label: 'Lead Manager', icon: Users },
  { id: 'ai-analysis', label: 'AI Analysis', icon: Brain, badge: 'AI', badgeColor: 'bg-purple-500' },
  { id: 'outreach', label: 'AI Outreach', icon: Mail },
  { id: 'crm', label: 'Sheets & Export', icon: Database },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'team', label: 'Team Workspace', icon: Building2 },
  { id: 'pricing', label: 'Pricing Plans', icon: CreditCard },
  { id: 'help', label: 'Help & Support', icon: HelpCircle },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function Sidebar({ activeSection, onSectionChange, collapsed, onToggle, userName, userRole, userPlan, onLogout, leadCount = 0, mobileOpen, onMobileClose }: SidebarProps) {
  const plan = (userPlan || 'free') as PlanId;

  const handleNav = (id: NavSection) => {
    onSectionChange(id);
    onMobileClose?.(); // close mobile drawer on nav
  };

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="flex items-center justify-between gap-3 px-4 py-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center shadow-lg"><Zap className="w-5 h-5 text-white" /></div>
          {!collapsed && <div className="overflow-hidden"><div className="flex items-center gap-1"><span className="text-white font-bold text-sm leading-tight">Maps Scraper</span></div><div className="text-xs text-blue-400 font-semibold">Pro AI</div></div>}
        </div>
        {/* Mobile close button */}
        {mobileOpen && <button onClick={onMobileClose} className="lg:hidden p-1.5 rounded-lg hover:bg-gray-800 text-gray-400"><X className="w-5 h-5" /></button>}
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {navItemsDef.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          const locked = !canAccessSection(plan, item.id);
          const badge = item.id === 'leads' ? String(leadCount) : item.badge;
          return (
            <button key={item.id} onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-200 group ${isActive ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : locked ? 'text-gray-600 hover:bg-gray-800/50' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}`}>
              <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : locked ? 'text-gray-700' : 'text-gray-500 group-hover:text-gray-300'}`} />
              {!collapsed && <>
                <span className={`flex-1 text-sm font-medium truncate ${locked ? 'text-gray-600' : ''}`}>{item.label}</span>
                {locked ? <Lock className="w-3.5 h-3.5 text-gray-600" /> : badge ? <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full text-white ${item.id === 'leads' ? 'bg-blue-500' : item.badgeColor || 'bg-gray-600'}`}>{badge}</span> : null}
              </>}
            </button>
          );
        })}
      </nav>

      {/* Bottom */}
      {!collapsed && (
        <div className="px-4 py-4 border-t border-gray-800 space-y-2">
          <UsageBar variant="compact" />
          <div className="flex items-center gap-2 px-3 py-2.5 bg-gradient-to-r from-blue-900/40 to-red-900/40 rounded-xl border border-gray-700">
            <img src="/masteredge-logo.png" alt="Masteredge" className="w-8 h-8 rounded-lg object-contain bg-white" />
            <div className="overflow-hidden"><div className="flex items-center"><span className="text-blue-400 text-xs font-black leading-tight">MASTER</span><span className="text-red-400 text-xs font-black leading-tight">EDGE</span></div><div className="text-gray-500 text-[10px]">Technology</div></div>
          </div>
          {userName && (
            <div className="flex items-center gap-2 px-3 py-2.5 bg-gray-800/50 rounded-xl border border-gray-700">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center flex-shrink-0"><span className="text-white text-xs font-bold">{userName.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase()}</span></div>
              <div className="overflow-hidden flex-1 min-w-0"><div className="text-white text-xs font-semibold truncate">{userName}</div><div className="flex items-center gap-1"><span className="text-[10px] text-gray-500 capitalize">{userRole || 'User'}</span><span className="text-[10px] text-gray-700">•</span><span className="text-[10px] text-amber-400 font-semibold capitalize">{userPlan || 'Free'}</span></div></div>
            </div>
          )}
          {onLogout && (
            <button onClick={onLogout} className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors text-sm font-medium">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>
              Sign Out
            </button>
          )}
        </div>
      )}

      {/* Desktop collapse toggle */}
      <button onClick={onToggle} className="absolute -right-3 top-20 w-6 h-6 bg-gray-800 border border-gray-700 rounded-full hidden lg:flex items-center justify-center hover:bg-gray-700 transition-colors z-10">
        <ChevronRight className={`w-3 h-3 text-gray-400 transition-transform duration-300 ${collapsed ? '' : 'rotate-180'}`} />
      </button>
    </>
  );

  return (
    <>
      {/* Desktop sidebar — hidden on mobile */}
      <aside className={`relative hidden lg:flex flex-col bg-gray-950 border-r border-gray-800 transition-all duration-300 ${collapsed ? 'w-16' : 'w-64'} min-h-screen`}>
        {sidebarContent}
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={onMobileClose}></div>
          <aside className="relative flex flex-col bg-gray-950 border-r border-gray-800 w-72 max-w-[85vw] h-full overflow-hidden animate-slideIn">
            {sidebarContent}
          </aside>
        </div>
      )}
    </>
  );
}
