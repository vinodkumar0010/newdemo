import { Mail, Phone, MessageCircle, ExternalLink, HelpCircle, BookOpen, Zap } from 'lucide-react';

const SUPPORT_EMAIL = 'support@masteredgetech.in';
const WHATSAPP_NUMBER = '+917391015661';
const WHATSAPP_LINK = `https://wa.me/917391015661?text=${encodeURIComponent('Hi, I need help with Maps Scraper Pro AI')}`;

const faqs = [
  { q: 'How do I start scraping leads?', a: 'Go to Scraper Engine → enter a search like "Dentist Sydney" → click Start Scraping. Add your Google Places API key in Settings for real data.' },
  { q: 'Where do I enter my Google API key?', a: 'Go to Settings → Google Places API Key section → paste your key → click Save. You can also enter it on the Scraper Engine page yellow banner.' },
  { q: 'How do I upgrade my plan?', a: 'Go to Pricing Plans → click the plan you want → complete the payment. Your features unlock immediately after upgrade.' },
  { q: 'Why are some tabs locked with 🔒?', a: 'Tabs are locked based on your current plan. Free users get Dashboard, Scraper, Leads, Analytics. Upgrade to Pro or Agency to unlock AI Analysis, Outreach, Team Workspace etc.' },
  { q: 'How do I export my leads?', a: 'Go to Lead Manager → click "Export All" button → CSV file downloads. Or go to Sheets & Export for Google Sheets sync and more formats.' },
  { q: 'How do I add team members?', a: 'Go to Team Workspace (requires Agency plan) → click "Add Team Member" → enter name, email, password, and role → they can login immediately.' },
  { q: 'I forgot my password', a: 'Click "Forgot password?" on the login page → enter your email → a reset link will be sent to your inbox (if email service is configured by the owner).' },
  { q: 'Why is the scraper returning demo data?', a: 'You need to add a real Google Places API key. Without a key, the scraper generates realistic sample data for testing.' },
  { q: 'How do I get emails from leads?', a: 'After scraping, the app automatically crawls each business website to extract emails, social media links, and decision-maker names. Not all websites expose emails publicly.' },
  { q: 'Can I use this on mobile?', a: 'Yes, the app works on mobile browsers. Use the sidebar collapse button (arrow icon) to save screen space on smaller devices.' },
];

export default function Help() {
  return (
    <div className="p-6 space-y-6">
      {/* Hero */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-violet-900 border border-blue-700/50 rounded-2xl p-8 text-center">
        <HelpCircle className="w-12 h-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-black text-white mb-2">Help & Support</h2>
        <p className="text-blue-200 text-sm max-w-xl mx-auto">Need help? We're here for you. Contact us via email or WhatsApp, or browse the FAQs below.</p>
      </div>

      {/* Contact Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Email */}
        <a href={`mailto:${SUPPORT_EMAIL}`} className="block bg-gray-900 border border-gray-800 rounded-2xl p-6 hover:border-blue-500/50 transition-all group">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
              <Mail className="w-7 h-7 text-blue-400" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Email Support</h3>
              <p className="text-gray-500 text-sm">Get help via email</p>
            </div>
          </div>
          <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl flex items-center justify-between">
            <div>
              <div className="text-blue-400 font-bold text-lg">{SUPPORT_EMAIL}</div>
              <div className="text-xs text-gray-500 mt-0.5">We typically reply within 24 hours</div>
            </div>
            <ExternalLink className="w-5 h-5 text-blue-400/50" />
          </div>
          <button className="w-full mt-4 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2">
            <Mail className="w-4 h-4" /> Send Email
          </button>
        </a>

        {/* WhatsApp */}
        <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="block bg-gray-900 border border-gray-800 rounded-2xl p-6 hover:border-emerald-500/50 transition-all group">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors">
              <MessageCircle className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">WhatsApp Support</h3>
              <p className="text-gray-500 text-sm">Chat with us instantly</p>
            </div>
          </div>
          <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl flex items-center justify-between">
            <div>
              <div className="text-emerald-400 font-bold text-lg">{WHATSAPP_NUMBER}</div>
              <div className="text-xs text-gray-500 mt-0.5">Available Mon-Sat, 10 AM - 7 PM IST</div>
            </div>
            <ExternalLink className="w-5 h-5 text-emerald-400/50" />
          </div>
          <button className="w-full mt-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2">
            <MessageCircle className="w-4 h-4" /> Chat on WhatsApp
          </button>
        </a>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <a href={`mailto:${SUPPORT_EMAIL}?subject=Bug Report — Maps Scraper Pro AI`} className="p-4 bg-gray-900 border border-gray-800 rounded-xl text-center hover:border-red-500/40 transition-colors">
          <div className="text-2xl mb-2">🐛</div>
          <div className="text-white text-sm font-semibold">Report Bug</div>
          <div className="text-gray-500 text-xs">via Email</div>
        </a>
        <a href={`mailto:${SUPPORT_EMAIL}?subject=Feature Request — Maps Scraper Pro AI`} className="p-4 bg-gray-900 border border-gray-800 rounded-xl text-center hover:border-violet-500/40 transition-colors">
          <div className="text-2xl mb-2">💡</div>
          <div className="text-white text-sm font-semibold">Feature Request</div>
          <div className="text-gray-500 text-xs">via Email</div>
        </a>
        <a href={`${WHATSAPP_LINK}&text=${encodeURIComponent('Hi, I need help with billing/payment')}`} target="_blank" rel="noopener noreferrer" className="p-4 bg-gray-900 border border-gray-800 rounded-xl text-center hover:border-amber-500/40 transition-colors">
          <div className="text-2xl mb-2">💳</div>
          <div className="text-white text-sm font-semibold">Billing Help</div>
          <div className="text-gray-500 text-xs">via WhatsApp</div>
        </a>
        <a href={`${WHATSAPP_LINK}&text=${encodeURIComponent('Hi, I need urgent help with the scraper')}`} target="_blank" rel="noopener noreferrer" className="p-4 bg-gray-900 border border-gray-800 rounded-xl text-center hover:border-blue-500/40 transition-colors">
          <div className="text-2xl mb-2">🚨</div>
          <div className="text-white text-sm font-semibold">Urgent Support</div>
          <div className="text-gray-500 text-xs">via WhatsApp</div>
        </a>
      </div>

      {/* FAQs */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <BookOpen className="w-5 h-5 text-amber-400" />
          <h3 className="text-white font-semibold text-lg">Frequently Asked Questions</h3>
        </div>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <details key={i} className="group bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
              <summary className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-700/50 transition-colors">
                <span className="text-sm font-semibold text-white pr-4">{faq.q}</span>
                <span className="text-gray-500 group-open:rotate-180 transition-transform text-lg flex-shrink-0">▾</span>
              </summary>
              <div className="px-4 pb-4 text-sm text-gray-400 leading-relaxed border-t border-gray-700 pt-3">{faq.a}</div>
            </details>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gradient-to-r from-blue-900/20 to-red-900/20 border border-gray-700 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center"><Zap className="w-5 h-5 text-white" /></div>
          <div>
            <div className="flex items-center gap-1"><span className="text-blue-400 font-black">MASTER</span><span className="text-red-400 font-black">EDGE</span><span className="text-white font-bold ml-1">Technology</span></div>
            <div className="text-gray-500 text-xs">Google Maps Lead Scraper Pro AI</div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <a href={`mailto:${SUPPORT_EMAIL}`} className="flex items-center gap-1.5 text-sm text-blue-400 hover:text-blue-300"><Mail className="w-4 h-4" />{SUPPORT_EMAIL}</a>
          <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-sm text-emerald-400 hover:text-emerald-300"><Phone className="w-4 h-4" />{WHATSAPP_NUMBER}</a>
        </div>
      </div>
    </div>
  );
}

/* ── Floating Help Button (use in App.tsx) ── */
export function FloatingHelpButton({ onClick }: { onClick: () => void }) {
  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2">
      {/* WhatsApp */}
      <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer"
        className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-lg shadow-emerald-900/40 text-sm font-semibold transition-all hover:scale-105">
        <MessageCircle className="w-4 h-4" /> WhatsApp
      </a>
      {/* Help */}
      <button onClick={onClick}
        className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-full shadow-lg shadow-blue-900/40 text-sm font-semibold transition-all hover:scale-105">
        <HelpCircle className="w-4 h-4" /> Help
      </button>
    </div>
  );
}
