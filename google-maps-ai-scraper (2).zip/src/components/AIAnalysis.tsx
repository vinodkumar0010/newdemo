import { useState, useMemo } from 'react';
import {
  Brain, Globe, Shield, Zap, Search, CheckCircle2, XCircle,
  AlertCircle, Star, TrendingUp, Target, Eye, Activity, Mail,
} from 'lucide-react';
import { useLeadCount } from '../context/LeadContext';
import EmailFinder from './EmailFinder';

const opportunityColors: Record<string, string> = {
  'Website Redesign': 'bg-red-500/10 text-red-400 border-red-500/20',
  'SEO Services': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Google Ads': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  'AI Chatbot': 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  'AI Receptionist': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'Social Media Marketing': 'bg-pink-500/10 text-pink-400 border-pink-500/20',
  'No Website Found': 'bg-red-500/10 text-red-400 border-red-500/20',
  'Missing Online Presence': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
};
const defaultConf: Record<string, number> = { 'Website Redesign': 94, 'SEO Services': 87, 'Google Ads': 79, 'AI Chatbot': 82, 'AI Receptionist': 71, 'Social Media Marketing': 88 };

export default function AIAnalysis() {
  const { leads } = useLeadCount();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeModule, setActiveModule] = useState<'website' | 'email' | 'leads' | 'reviews' | 'competitors'>('website');

  const selectedLead = useMemo(() => {
    if (selectedId) return leads.find(l => l.id === selectedId) || leads[0];
    return leads[0];
  }, [leads, selectedId]);

  const competitors = useMemo(() => {
    if (!selectedLead) return [];
    return leads.filter(l => l.id !== selectedLead.id && l.city === selectedLead.city).slice(0, 4);
  }, [leads, selectedLead]);

  if (leads.length === 0) return (
    <div className="p-6"><div className="text-center py-20 bg-gray-900 border border-gray-800 rounded-2xl">
      <Brain className="w-12 h-12 text-gray-700 mx-auto mb-3" />
      <h3 className="text-white font-semibold mb-1">No leads to analyze</h3>
      <p className="text-gray-500 text-sm">Go to Scraper Engine and scrape some leads first</p>
    </div></div>
  );

  const sl = selectedLead!;
  const wsScore = sl.websiteScore ?? 0;
  const scoreColor = wsScore >= 70 ? 'text-emerald-400' : wsScore >= 40 ? 'text-amber-400' : 'text-red-400';

  const websiteChecks = [
    { name: 'Has Website', icon: '🌐', passed: !!sl.website },
    { name: 'Has Email', icon: '📧', passed: !!sl.email },
    { name: 'Has Phone', icon: '📞', passed: !!sl.phone },
    { name: 'Rating ≥ 4', icon: '⭐', passed: sl.rating >= 4 },
    { name: 'Reviews > 50', icon: '💬', passed: sl.reviews > 50 },
    { name: 'Has Socials', icon: '📱', passed: Object.values(sl.socialMedia || {}).filter(Boolean).length > 0 },
    { name: 'SEO Score ≥ 50', icon: '📊', passed: wsScore >= 50 },
    { name: 'Decision Maker', icon: '👤', passed: !!sl.decisionMaker },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'website', label: 'Website Analysis', icon: Globe },
          { id: 'email', label: 'Email Finder', icon: Mail },
          { id: 'leads', label: 'Lead Scoring', icon: Target },
          { id: 'reviews', label: 'Review Intelligence', icon: Star },
          { id: 'competitors', label: 'Competitor Discovery', icon: Eye },
        ].map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveModule(id as typeof activeModule)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${activeModule === id ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/30' : 'bg-gray-900 border border-gray-800 text-gray-400 hover:text-white hover:border-gray-600'}`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Lead Selector */}
        <div className="xl:col-span-1 space-y-2">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wide px-1">Select Lead ({leads.length})</h3>
          <div className="space-y-1.5 max-h-[65vh] overflow-y-auto pr-1">
            {leads.map(lead => (
              <button key={lead.id} onClick={() => setSelectedId(lead.id)}
                className={`w-full text-left p-3 rounded-xl border transition-all ${sl.id === lead.id ? 'bg-blue-600/10 border-blue-500/40 text-white' : 'bg-gray-900 border-gray-800 text-gray-400 hover:border-gray-600 hover:text-gray-300'}`}>
                <div className="font-medium text-sm truncate">{lead.businessName}</div>
                <div className="flex items-center gap-2 text-xs text-gray-500 mt-0.5">
                  <span>{lead.city}</span>
                  {lead.email && <span className="text-emerald-400">✉</span>}
                  <span className={lead.leadCategory === 'hot' ? 'text-red-400 font-bold' : lead.leadCategory === 'warm' ? 'text-orange-400 font-bold' : 'text-blue-400 font-bold'}>{lead.leadScore}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Main */}
        <div className="xl:col-span-3 space-y-5">
          {activeModule === 'email' && <div className="xl:col-span-3"><EmailFinder /></div>}

          {activeModule === 'website' && (<>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-start justify-between mb-5">
                <div>
                  <h3 className="text-white font-semibold text-lg">{sl.businessName}</h3>
                  <p className="text-gray-500 text-sm">{sl.website || 'No website found'}</p>
                  {sl.email && <p className="text-emerald-400 text-sm mt-1">📧 {sl.email}</p>}
                  {sl.phone && <p className="text-gray-400 text-sm">📞 {sl.phone}</p>}
                </div>
                <div className="relative w-20 h-20">
                  <svg viewBox="0 0 36 36" className="w-20 h-20 -rotate-90">
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1f2937" strokeWidth="3" />
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke={wsScore >= 70 ? '#10b981' : wsScore >= 40 ? '#f59e0b' : '#ef4444'} strokeWidth="3" strokeDasharray={`${wsScore} ${100 - wsScore}`} strokeLinecap="round" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className={`text-2xl font-black ${scoreColor}`}>{wsScore}</span>
                    <span className="text-[9px] text-gray-600 uppercase font-bold">Score</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {websiteChecks.map(c => (
                  <div key={c.name} className={`p-3 rounded-xl border ${c.passed ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
                    <div className="flex items-center justify-between mb-1"><span className="text-lg">{c.icon}</span>{c.passed ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}</div>
                    <div className={`text-xs font-medium ${c.passed ? 'text-emerald-400' : 'text-red-400'}`}>{c.name}</div>
                  </div>
                ))}
              </div>
            </div>
            {/* Opportunities */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4"><Brain className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold">AI Opportunity Detection</h3></div>
              {sl.opportunities.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {sl.opportunities.map(opp => (
                    <div key={opp} className={`p-4 rounded-xl border ${opportunityColors[opp] || 'bg-gray-800 border-gray-700 text-gray-300'}`}>
                      <div className="flex items-start justify-between"><div><div className="font-semibold text-sm mb-1">🎯 Opportunity</div><div className="text-base font-bold">{opp}</div></div>
                        <div className="text-right"><div className="text-2xl font-black">{defaultConf[opp] || 85}%</div><div className="text-[10px] opacity-70">Confidence</div></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : <div className="text-center py-6 text-gray-500"><CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-400" />Well-optimized — no major opportunities detected</div>}
            </div>
            {/* SEO */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4"><Search className="w-5 h-5 text-blue-400" /><h3 className="text-white font-semibold">Local SEO Audit</h3></div>
              {sl.seoIssues && sl.seoIssues.length > 0 ? (
                <div className="space-y-2">{sl.seoIssues.map(issue => (
                  <div key={issue} className="flex items-center justify-between p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                    <div className="flex items-center gap-2"><AlertCircle className="w-4 h-4 text-amber-400" /><span className="text-sm text-amber-300">{issue}</span></div>
                    <span className="text-xs px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20 font-semibold">Fix Needed</span>
                  </div>
                ))}</div>
              ) : <div className="flex items-center gap-2 text-emerald-400"><CheckCircle2 className="w-4 h-4" /><span className="text-sm">No SEO issues found</span></div>}
            </div>
          </>)}

          {activeModule === 'leads' && (
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 space-y-6">
              <div className="flex items-center gap-2 mb-2"><Target className="w-5 h-5 text-red-400" /><h3 className="text-white font-semibold">AI Lead Scoring — {sl.businessName}</h3></div>
              <div className="flex items-center justify-center gap-4">
                <div className={`text-7xl font-black ${sl.leadCategory === 'hot' ? 'text-red-400' : sl.leadCategory === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>{sl.leadScore}</div>
                <div><div className="text-gray-400 text-sm">/ 100</div><div className={`text-lg font-bold ${sl.leadCategory === 'hot' ? 'text-red-400' : sl.leadCategory === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>{sl.leadCategory === 'hot' ? '🔥 Hot Lead' : sl.leadCategory === 'warm' ? '🟠 Warm Lead' : '🔵 Cold Lead'}</div></div>
              </div>
              <div className="space-y-3">
                {[
                  { factor: 'Website Quality', value: sl.websiteScore ? Math.round(sl.websiteScore * 0.25) : 20, max: 25, icon: Globe },
                  { factor: 'Review Count', value: Math.min(20, Math.round(sl.reviews / 50)), max: 20, icon: Star },
                  { factor: 'Rating Score', value: Math.round(sl.rating * 3), max: 15, icon: TrendingUp },
                  { factor: 'Contact Available', value: sl.email ? 15 : 0, max: 15, icon: Activity },
                  { factor: 'Social Presence', value: Object.values(sl.socialMedia || {}).filter(Boolean).length * 3, max: 15, icon: Zap },
                  { factor: 'SEO Opportunity', value: sl.seoIssues ? sl.seoIssues.length * 2 : 0, max: 10, icon: Shield },
                ].map(({ factor, value, max, icon: Icon }) => (
                  <div key={factor} className="flex items-center gap-3"><Icon className="w-4 h-4 text-gray-500 flex-shrink-0" /><div className="flex-1"><div className="flex items-center justify-between mb-1"><span className="text-sm text-gray-300">{factor}</span><span className="text-xs text-gray-500">+{value}/{max}</span></div><div className="h-1.5 bg-gray-800 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full" style={{ width: `${(value / max) * 100}%` }}></div></div></div></div>
                ))}
              </div>
              <div className="pt-4 border-t border-gray-800 space-y-2">
                <h4 className="text-white font-semibold text-sm">Qualification Rules</h4>
                {[
                  { rule: 'Website Missing', bonus: '+20', triggered: !sl.website },
                  { rule: 'Rating Below 4', bonus: '+15', triggered: sl.rating > 0 && sl.rating < 4 },
                  { rule: 'Reviews Above 100', bonus: '+10', triggered: sl.reviews > 100 },
                  { rule: 'No Email Found', bonus: '+10', triggered: !sl.email },
                  { rule: 'No Social Media', bonus: '+10', triggered: Object.values(sl.socialMedia || {}).filter(Boolean).length === 0 },
                ].map(({ rule, bonus, triggered }) => (
                  <div key={rule} className={`flex items-center justify-between p-3 rounded-xl border ${triggered ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-gray-800 border-gray-700'}`}>
                    <div className="flex items-center gap-2">{triggered ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-gray-600" />}<span className={`text-sm ${triggered ? 'text-white' : 'text-gray-500'}`}>{rule}</span></div>
                    <span className={`text-sm font-bold ${triggered ? 'text-emerald-400' : 'text-gray-600'}`}>{triggered ? bonus : '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeModule === 'reviews' && (
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4"><Star className="w-5 h-5 text-amber-400" /><h3 className="text-white font-semibold">Review Intelligence — {sl.businessName}</h3></div>
              <div className="grid grid-cols-3 gap-4 mb-5">
                <div className="text-center p-3 bg-gray-800 rounded-xl"><div className="text-3xl font-black text-amber-400">{sl.reviews}</div><div className="text-xs text-gray-500">Total Reviews</div></div>
                <div className="text-center p-3 bg-gray-800 rounded-xl"><div className="text-3xl font-black text-white">{sl.rating}</div><div className="text-xs text-gray-500">Avg Rating</div></div>
                <div className="text-center p-3 bg-gray-800 rounded-xl"><div className="text-3xl font-black text-red-400">{Math.floor(sl.reviews * 0.08)}</div><div className="text-xs text-gray-500">Est. Negative</div></div>
              </div>
              <div className="p-4 bg-violet-500/5 border border-violet-500/20 rounded-xl"><div className="flex items-center gap-2 mb-2"><Brain className="w-4 h-4 text-violet-400" /><span className="text-sm font-semibold text-violet-400">AI Sentiment Analysis</span></div>
                <p className="text-sm text-gray-300">{sl.reviewSentiment || `${sl.businessName} has ${sl.reviews} reviews with ${sl.rating}★ rating. ${sl.rating >= 4 ? 'Strong reputation.' : 'Room for improvement.'}`}</p>
              </div>
            </div>
          )}

          {activeModule === 'competitors' && (
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-4"><Eye className="w-5 h-5 text-emerald-400" /><h3 className="text-white font-semibold">Competitors in {sl.city} ({competitors.length} found)</h3></div>
              {competitors.length > 0 ? (
                <div className="space-y-3">
                  {competitors.map((c, i) => (
                    <div key={c.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                      <div><div className="font-medium text-white text-sm">{c.businessName}</div><div className="text-xs text-gray-500">{c.category} · {c.city}</div></div>
                      <div className="flex items-center gap-3">
                        <div className="text-right"><div className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /><span className="text-sm text-white font-semibold">{c.rating}</span></div><div className="text-xs text-gray-500">{c.reviews} reviews</div></div>
                        {i === 0 && <span className="text-[10px] px-1.5 py-0.5 bg-red-500/10 text-red-400 border border-red-500/20 rounded-md">Top</span>}
                      </div>
                    </div>
                  ))}
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <div className="p-3 bg-gray-800 rounded-xl text-center"><div className="text-lg font-bold text-white">{(competitors.reduce((a, c) => a + c.rating, 0) / competitors.length).toFixed(1)}</div><div className="text-xs text-gray-500">Avg Rating</div></div>
                    <div className="p-3 bg-gray-800 rounded-xl text-center"><div className="text-lg font-bold text-white">{Math.round(competitors.reduce((a, c) => a + c.reviews, 0) / competitors.length)}</div><div className="text-xs text-gray-500">Avg Reviews</div></div>
                  </div>
                </div>
              ) : <div className="text-center py-8 text-gray-500">No other leads found in {sl.city}. Scrape more leads from this city to see competitors.</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
