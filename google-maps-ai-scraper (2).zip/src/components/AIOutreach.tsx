import { useState, useMemo } from 'react';
import { Mail, MessageSquare, Phone, Copy, Sparkles, Download, Send, CheckCircle2 } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { useLeadCount } from '../context/LeadContext';
import { Lead } from '../types';

function genEmail(l: Lead) {
  const dm = l.decisionMaker?.name?.split(' ')[0] || 'there';
  const opp = l.opportunities?.[0] || 'digital presence';
  return `Subject: Quick Question About ${l.businessName}'s Online Presence

Hi ${dm},

I was researching ${l.category?.toLowerCase() || 'local'} businesses in ${l.city} and came across ${l.businessName}${l.reviews ? ` — impressive ${l.reviews} reviews!` : '.'}

I noticed a few opportunities that could significantly boost your leads:
${(l.opportunities || []).slice(0, 3).map(o => `• ${o}`).join('\n')}

We've helped similar businesses in ${l.city} increase their enquiries by 40-60% in just 90 days.

Would you be open to a quick 15-minute call this week to explore how we can help ${l.businessName} with ${opp}?

Best regards,
[Your Name]
Masteredge Technology

P.S. I've prepared a free audit report for ${l.businessName} — happy to share it on our call.`;
}

function genLinkedIn(l: Lead) {
  const dm = l.decisionMaker?.name?.split(' ')[0] || 'there';
  return `Hi ${dm},

I came across ${l.businessName} while researching ${l.category?.toLowerCase() || 'local'} businesses in ${l.city}${l.reviews ? ` — ${l.reviews} reviews is fantastic!` : '.'}

I help local businesses like yours generate more leads through ${l.opportunities?.[0] || 'digital marketing'}. Would love to connect and share some ideas specific to your business.

Happy to send over a free audit with no strings attached.

Cheers,
[Your Name]`;
}

function genWhatsApp(l: Lead) {
  const dm = l.decisionMaker?.name?.split(' ')[0] || 'there';
  return `Hi ${dm} 👋

I'm [Name] from Masteredge Technology.

I was checking out ${l.businessName} on Google Maps${l.reviews ? ` — great reviews! ⭐` : '.'}

I've put together a quick audit that shows some opportunities to get you more customers through ${l.opportunities?.[0] || 'digital marketing'}.

Completely free, no obligation. Interested? 🚀`;
}

function genVoice(l: Lead) {
  return `AI VOICE CALL SCRIPT
Business: ${l.businessName}
Phone: ${l.phone || 'N/A'}
Contact: ${l.decisionMaker?.name || 'Decision Maker'}
Email: ${l.email || 'N/A'}

---

OPENING:
"Hi, may I speak with ${l.decisionMaker?.name || 'the owner'}? 
Hi ${l.decisionMaker?.name?.split(' ')[0] || 'there'}, my name is [AI Agent Name] calling from Masteredge Technology..."

VALUE PROPOSITION:
"I'm reaching out because I noticed ${l.businessName} has great reviews on Google Maps, and I wanted to share a free website audit we prepared specifically for your business..."

KEY PAIN POINTS:
${(l.opportunities || []).slice(0, 2).map(o => `• "${o} — we've helped many ${l.category?.toLowerCase() || 'local'} businesses with this"`).join('\n')}

CLOSE:
"Would you be available for a quick 10-minute call with our specialist this week?"

---
Ready for: Omnidim | Bland AI | Vapi | Retell AI`;
}

type OutreachType = 'email' | 'linkedin' | 'whatsapp' | 'voice';

export default function AIOutreach() {
  const { showToast } = useToast();
  const { leads } = useLeadCount();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [outreachType, setOutreachType] = useState<OutreachType>('email');
  const [copied, setCopied] = useState(false);
  const [tone, setTone] = useState<'professional' | 'casual' | 'friendly'>('professional');

  const sl = useMemo(() => {
    if (selectedId) return leads.find(l => l.id === selectedId) || leads[0];
    return leads[0];
  }, [leads, selectedId]);

  if (leads.length === 0) return (
    <div className="p-6"><div className="text-center py-20 bg-gray-900 border border-gray-800 rounded-2xl">
      <Sparkles className="w-12 h-12 text-gray-700 mx-auto mb-3" />
      <h3 className="text-white font-semibold mb-1">No leads for outreach</h3>
      <p className="text-gray-500 text-sm">Scrape leads first, then generate personalized outreach messages</p>
    </div></div>
  );

  const content = !sl ? '' :
    outreachType === 'email' ? genEmail(sl) :
    outreachType === 'linkedin' ? genLinkedIn(sl) :
    outreachType === 'whatsapp' ? genWhatsApp(sl) : genVoice(sl);

  const handleCopy = () => { navigator.clipboard.writeText(content); setCopied(true); showToast('success', 'Copied!', `${outreachType} message copied`); setTimeout(() => setCopied(false), 2000); };

  return (
    <div className="p-6 space-y-5">
      <div><h2 className="text-white font-bold text-lg flex items-center gap-2"><Sparkles className="w-5 h-5 text-violet-400" />AI Outreach Generator</h2><p className="text-gray-500 text-sm">Personalized messages from your real scraped lead data</p></div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Selector */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wide">Select Lead ({leads.length})</h3>
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
            {leads.map(lead => (
              <button key={lead.id} onClick={() => setSelectedId(lead.id)}
                className={`w-full text-left p-3 rounded-xl border transition-all ${sl?.id === lead.id ? 'bg-violet-600/10 border-violet-500/40' : 'bg-gray-900 border-gray-800 hover:border-gray-600'}`}>
                <div className="font-medium text-sm text-white truncate">{lead.businessName}</div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs text-gray-500">{lead.city}</span>
                  {lead.email && <span className="text-[10px] text-emerald-400 flex items-center gap-0.5"><CheckCircle2 className="w-3 h-3" />Email</span>}
                  {lead.phone && <span className="text-[10px] text-blue-400">📞</span>}
                </div>
              </button>
            ))}
          </div>
          {/* Tone */}
          <div><div className="text-sm font-semibold text-gray-400 uppercase mb-2">Tone</div>
            <div className="grid grid-cols-3 gap-1.5">{(['professional', 'casual', 'friendly'] as const).map(t => (
              <button key={t} onClick={() => setTone(t)} className={`py-2 rounded-xl text-xs font-semibold capitalize transition-all ${tone === t ? 'bg-violet-600 text-white' : 'bg-gray-900 border border-gray-800 text-gray-400'}`}>{t}</button>
            ))}</div>
          </div>
          {/* Info */}
          {sl && (
            <div className="p-3 bg-gray-900 border border-gray-800 rounded-xl text-xs space-y-1.5">
              <div className="text-gray-500 uppercase font-semibold mb-1">Selected Lead</div>
              <div className="flex justify-between"><span className="text-gray-500">Business</span><span className="text-white font-medium truncate ml-2 max-w-32">{sl.businessName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Decision Maker</span><span className="text-white">{sl.decisionMaker?.name || '—'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Phone</span><span className="text-white">{sl.phone || '—'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Email</span><span className={sl.email ? 'text-emerald-400' : 'text-gray-600'}>{sl.email || '—'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Score</span><span className={sl.leadCategory === 'hot' ? 'text-red-400 font-bold' : sl.leadCategory === 'warm' ? 'text-orange-400 font-bold' : 'text-blue-400 font-bold'}>{sl.leadScore}/100</span></div>
            </div>
          )}
        </div>

        {/* Outreach */}
        <div className="xl:col-span-2 space-y-4">
          <div className="flex gap-2">{[
            { id: 'email', label: 'Cold Email', icon: Mail, color: 'bg-blue-600' },
            { id: 'linkedin', label: 'LinkedIn', icon: MessageSquare, color: 'bg-blue-700' },
            { id: 'whatsapp', label: 'WhatsApp', icon: Phone, color: 'bg-emerald-600' },
            { id: 'voice', label: 'AI Voice Script', icon: Send, color: 'bg-violet-600' },
          ].map(({ id, label, icon: Icon, color }) => (
            <button key={id} onClick={() => setOutreachType(id as OutreachType)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-semibold transition-all ${outreachType === id ? `${color} text-white` : 'bg-gray-900 border border-gray-800 text-gray-400'}`}>
              <Icon className="w-3.5 h-3.5" /><span className="hidden sm:inline">{label}</span>
            </button>
          ))}</div>

          <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
              <div className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-violet-400" /><span className="text-sm font-semibold text-white">{outreachType === 'email' ? 'Cold Email' : outreachType === 'linkedin' ? 'LinkedIn Message' : outreachType === 'whatsapp' ? 'WhatsApp' : 'Voice Script'}</span><span className="text-[10px] px-1.5 py-0.5 bg-violet-500/10 text-violet-400 rounded-full border border-violet-500/20">AI Generated</span></div>
              <div className="flex items-center gap-2">
                <button onClick={handleCopy} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${copied ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}>{copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3" />}{copied ? 'Copied!' : 'Copy'}</button>
              </div>
            </div>
            <textarea value={content} readOnly className="w-full p-4 bg-transparent text-gray-300 text-sm leading-relaxed resize-none focus:outline-none min-h-80" rows={18} />
          </div>

          <div className="flex flex-wrap gap-2">
            <button onClick={handleCopy} className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors"><Send className="w-4 h-4" />Copy & Send</button>
            <button onClick={() => showToast('success', 'Templates exported', `${leads.length} personalized messages`)} className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-sm font-semibold transition-colors"><Download className="w-4 h-4" />Export All</button>
          </div>

          <div className="bg-gradient-to-r from-violet-900/20 to-blue-900/20 border border-violet-700/30 rounded-2xl p-4">
            <div className="flex items-center justify-between"><div><div className="text-white font-semibold text-sm">Bulk Outreach Generation</div><div className="text-gray-500 text-xs mt-0.5">Generate personalized messages for all {leads.length} leads at once</div></div>
              <button onClick={() => showToast('success', 'Bulk generated!', `${leads.length} messages created`)} className="flex items-center gap-2 px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm font-semibold transition-colors"><Sparkles className="w-4 h-4" />Generate All</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
