import { useState, useMemo } from 'react';
import {
  Users, Activity, MessageSquare, Shield, Clock, Plus, X, Copy,
  Trash2, Edit3, CheckCircle2, AlertCircle, Search, UserPlus,
} from 'lucide-react';
import { useLeadCount } from '../context/LeadContext';
import { useAuth } from '../context/AuthContext';
import { useTeam, TeamRole } from '../context/TeamContext';
import { useToast } from '../context/ToastContext';

const ROLE_LABELS: Record<TeamRole, string> = { admin: 'Admin', scraper: 'Scraper', outreach: 'Outreach', analyst: 'Analyst', viewer: 'Viewer' };
const ROLE_COLORS: Record<TeamRole, string> = { admin: 'bg-blue-500', scraper: 'bg-violet-500', outreach: 'bg-emerald-500', analyst: 'bg-amber-500', viewer: 'bg-gray-500' };
const ROLE_BADGE: Record<TeamRole, string> = { admin: 'bg-blue-500/10 text-blue-400 border-blue-500/20', scraper: 'bg-violet-500/10 text-violet-400 border-violet-500/20', outreach: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', analyst: 'bg-amber-500/10 text-amber-400 border-amber-500/20', viewer: 'bg-gray-500/10 text-gray-400 border-gray-500/20' };
const STATUS_COLORS = { online: 'bg-emerald-400', away: 'bg-amber-400', offline: 'bg-gray-600' };
const ALL_ROLES: TeamRole[] = ['admin', 'scraper', 'outreach', 'analyst', 'viewer'];

function initials(name: string) { return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase(); }
function ago(ts: string) {
  const ms = Date.now() - new Date(ts).getTime();
  if (ms < 60000) return 'Just now';
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ago`;
  if (ms < 86400000) return `${Math.floor(ms / 3600000)}h ago`;
  return `${Math.floor(ms / 86400000)}d ago`;
}

export default function TeamWorkspace() {
  const { leads, count } = useLeadCount();
  const { user } = useAuth();
  const { members, addMember, removeMember, updateMemberRole, updateMemberStatus, activityLog, addActivity, notes, addNote, removeNote, rolePermissions } = useTeam();
  const { showToast } = useToast();

  const isAdmin = user?.role === 'owner' || user?.role === 'admin';

  // ── Add Member form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<TeamRole>('viewer');

  // ── Created credentials modal
  const [createdCreds, setCreatedCreds] = useState<{ name: string; email: string; password: string; role: string } | null>(null);

  // ── Edit Role
  const [editingRole, setEditingRole] = useState<string | null>(null);

  // ── Notes
  const [noteLeadName, setNoteLeadName] = useState('');
  const [noteText, setNoteText] = useState('');
  const [noteSearch, setNoteSearch] = useState('');

  // ── Delete confirm
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // ── Status toggle
  const [statusDropdown, setStatusDropdown] = useState<string | null>(null);

  // ── Active tab
  const [activeTab, setActiveTab] = useState<'members' | 'activity' | 'notes' | 'roles'>('members');

  const stats = useMemo(() => ({
    withEmail: leads.filter(l => l.email).length,
    hot: leads.filter(l => l.leadCategory === 'hot').length,
    avgScore: leads.length > 0 ? Math.round(leads.reduce((a, l) => a + l.leadScore, 0) / leads.length) : 0,
  }), [leads]);

  const handleAddMember = () => {
    const pw = newPassword || `${newName.split(' ')[0]}@${Math.floor(1000 + Math.random() * 9000)}`;
    const res = addMember(newName, newEmail, newRole, pw);
    if (res.success) {
      showToast('success', 'Team member added!', res.message);
      addActivity(user?.name || 'Admin', 'Added member', `${newName} (${ROLE_LABELS[newRole]}) — login account created`);
      setCreatedCreds({ name: newName, email: newEmail, password: pw, role: ROLE_LABELS[newRole] });
      setNewName(''); setNewEmail(''); setNewPassword(''); setNewRole('viewer'); setShowAddForm(false);
    } else {
      showToast('error', 'Failed', res.message);
    }
  };

  const handleRemoveMember = (id: string) => {
    const m = members.find(x => x.id === id);
    removeMember(id);
    setDeleteConfirm(null);
    showToast('success', 'Member removed', `${m?.name || 'Member'} removed from team`);
    addActivity(user?.name || 'Admin', 'Removed member', m?.name || 'Unknown');
  };

  const handleChangeRole = (id: string, role: TeamRole) => {
    const m = members.find(x => x.id === id);
    updateMemberRole(id, role);
    setEditingRole(null);
    showToast('success', 'Role updated', `${m?.name}: ${ROLE_LABELS[role]}`);
    addActivity(user?.name || 'Admin', 'Changed role', `${m?.name} → ${ROLE_LABELS[role]}`);
  };

  const handleAddNote = () => {
    if (!noteText.trim()) { showToast('error', 'Empty note', 'Please write something'); return; }
    addNote(noteLeadName || 'General', noteText, user?.name || 'Admin');
    showToast('success', 'Note added', noteLeadName || 'General note');
    setNoteText(''); setNoteLeadName('');
  };

  const filteredNotes = noteSearch ? notes.filter(n => n.leadName.toLowerCase().includes(noteSearch.toLowerCase()) || n.note.toLowerCase().includes(noteSearch.toLowerCase())) : notes;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2"><Users className="w-5 h-5 text-blue-400" />Team Workspace</h2>
          <p className="text-gray-500 text-sm">{members.length} member{members.length !== 1 ? 's' : ''} · {count} leads in database</p>
        </div>
        {isAdmin && (
          <button onClick={() => setShowAddForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors">
            <UserPlus className="w-4 h-4" />Add Team Member
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-900 border border-gray-800 rounded-xl w-fit">
        {([
          { id: 'members', label: `Members (${members.length})`, icon: Users },
          { id: 'activity', label: `Activity (${activityLog.length})`, icon: Activity },
          { id: 'notes', label: `Notes (${notes.length})`, icon: MessageSquare },
          { id: 'roles', label: 'Roles & Permissions', icon: Shield },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id as typeof activeTab)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === t.id ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      {/* ═══════ Add Member Modal ═══════ */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowAddForm(false)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg flex items-center gap-2"><UserPlus className="w-5 h-5 text-blue-400" />Add Team Member</h3>
              <button onClick={() => setShowAddForm(false)} className="text-gray-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Full Name *</label>
                <input type="text" value={newName} onChange={e => setNewName(e.target.value)} placeholder="John Doe"
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Email Address *</label>
                <input type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="john@company.com"
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Login Password *</label>
                <input type="text" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Min 6 characters (auto-generated if empty)"
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500 font-mono" />
                <p className="text-[10px] text-gray-600 mt-1">This member will use this password to sign in. Leave blank to auto-generate.</p>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Role *</label>
                <div className="grid grid-cols-5 gap-1.5">
                  {ALL_ROLES.map(r => (
                    <button key={r} onClick={() => setNewRole(r)}
                      className={`py-2.5 rounded-xl text-xs font-semibold capitalize transition-all ${newRole === r ? `${ROLE_COLORS[r]} text-white` : 'bg-gray-800 border border-gray-700 text-gray-400 hover:border-gray-500'}`}>
                      {ROLE_LABELS[r]}
                    </button>
                  ))}
                </div>
                <div className="mt-2 p-2.5 bg-gray-800 rounded-xl">
                  <div className="text-[10px] text-gray-500 uppercase font-semibold mb-1">Permissions for {ROLE_LABELS[newRole]}:</div>
                  <div className="flex flex-wrap gap-1">
                    {rolePermissions[newRole].map(p => <span key={p} className="text-[10px] px-1.5 py-0.5 bg-blue-500/10 text-blue-400 rounded-md border border-blue-500/20">{p}</span>)}
                  </div>
                </div>
              </div>
              <button onClick={handleAddMember} disabled={!newName.trim() || !newEmail.trim()}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-xl font-bold text-sm transition-colors">
                Add to Team
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ Delete Confirm ═══════ */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center"><Trash2 className="w-5 h-5 text-red-400" /></div>
              <div><h3 className="text-white font-semibold">Remove member?</h3><p className="text-sm text-gray-500">{members.find(m => m.id === deleteConfirm)?.name}</p></div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setDeleteConfirm(null)} className="px-4 py-2 bg-gray-800 text-gray-300 rounded-xl text-sm font-semibold">Cancel</button>
              <button onClick={() => handleRemoveMember(deleteConfirm)} className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-sm font-semibold">Remove</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ Created Credentials Modal ═══════ */}
      {createdCreds && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setCreatedCreds(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 text-emerald-400" /></div>
              <div><h3 className="text-white font-bold">Member Account Created!</h3><p className="text-gray-500 text-sm">Share these credentials with {createdCreds.name}</p></div>
            </div>
            <div className="space-y-3 p-4 bg-gray-800 rounded-xl border border-gray-700">
              <div className="flex justify-between items-center"><span className="text-sm text-gray-400">Name</span><span className="text-sm text-white font-semibold">{createdCreds.name}</span></div>
              <div className="flex justify-between items-center"><span className="text-sm text-gray-400">Role</span><span className="text-sm text-white font-semibold">{createdCreds.role}</span></div>
              <div className="border-t border-gray-700 pt-3">
                <div className="flex justify-between items-center mb-2"><span className="text-sm text-gray-400">Login Email</span><span className="text-sm text-emerald-400 font-mono">{createdCreds.email}</span></div>
                <div className="flex justify-between items-center"><span className="text-sm text-gray-400">Password</span><span className="text-sm text-emerald-400 font-mono">{createdCreds.password}</span></div>
              </div>
            </div>
            <div className="mt-4 p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl">
              <p className="text-xs text-blue-300">💡 This member can now sign in at the login page using the email and password above. They will see data based on their assigned role permissions.</p>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => {
                navigator.clipboard.writeText(`Login Credentials for ${createdCreds.name}\nRole: ${createdCreds.role}\nEmail: ${createdCreds.email}\nPassword: ${createdCreds.password}\nLogin URL: ${window.location.origin}`);
                showToast('success', 'Credentials copied!', 'Share with the team member');
              }} className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors">
                <Copy className="w-4 h-4" />Copy Credentials
              </button>
              <button onClick={() => setCreatedCreds(null)} className="px-4 py-2.5 bg-gray-800 text-gray-300 hover:bg-gray-700 rounded-xl text-sm font-semibold">Done</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ MEMBERS TAB ═══════ */}
      {activeTab === 'members' && (
        <div className="space-y-4">
          {/* Owner card (always first) */}
          <div className="bg-gradient-to-r from-amber-900/20 to-orange-900/20 border border-amber-700/40 rounded-2xl p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0">
              <span className="text-white text-sm font-black">{initials(user?.name || 'ME')}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><span className="font-semibold text-white">{user?.name || 'You'}</span><span className="text-[10px] px-2 py-0.5 bg-amber-500/20 text-amber-400 rounded-full border border-amber-500/30 font-bold">OWNER</span><span className="flex items-center gap-1 text-[10px] text-emerald-400"><span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span>Online</span></div>
              <div className="text-xs text-gray-500">{user?.email} · {user?.plan} plan · All permissions</div>
            </div>
            <div className="text-right flex-shrink-0"><div className="text-2xl font-black text-white">{count}</div><div className="text-xs text-gray-500">Total leads</div></div>
          </div>

          {/* Member cards */}
          {members.length === 0 ? (
            <div className="text-center py-12 bg-gray-900 border border-gray-800 rounded-2xl">
              <Users className="w-10 h-10 text-gray-700 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-1">No team members yet</h3>
              <p className="text-gray-500 text-sm mb-4">Add your first team member to start collaborating</p>
              {isAdmin && <button onClick={() => setShowAddForm(true)} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold"><UserPlus className="w-4 h-4 inline mr-1.5" />Add Member</button>}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {members.map(m => (
                <div key={m.id} className="bg-gray-900 border border-gray-800 rounded-2xl p-4 hover:border-gray-700 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={`w-11 h-11 rounded-xl ${m.color} flex items-center justify-center`}><span className="text-white text-sm font-bold">{initials(m.name)}</span></div>
                        {/* Status dot */}
                        <div className="relative">
                          <button onClick={() => isAdmin ? setStatusDropdown(statusDropdown === m.id ? null : m.id) : undefined}
                            className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-gray-900 ${STATUS_COLORS[m.status]} ${isAdmin ? 'cursor-pointer' : ''}`} />
                          {statusDropdown === m.id && isAdmin && (
                            <div className="absolute top-5 left-0 z-20 bg-gray-800 border border-gray-700 rounded-xl shadow-xl p-1.5 w-28">
                              {(['online', 'away', 'offline'] as const).map(s => (
                                <button key={s} onClick={() => { updateMemberStatus(m.id, s); setStatusDropdown(null); }}
                                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs text-gray-300 hover:bg-gray-700 capitalize">
                                  <span className={`w-2 h-2 rounded-full ${STATUS_COLORS[s]}`}></span>{s}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      <div>
                        <div className="font-semibold text-white text-sm">{m.name}</div>
                        <div className="text-xs text-gray-500 truncate max-w-[140px]">{m.email}</div>
                      </div>
                    </div>
                    {isAdmin && (
                      <button onClick={() => setDeleteConfirm(m.id)} className="p-1.5 rounded-lg text-gray-600 hover:text-red-400 hover:bg-red-500/10 transition-colors" title="Remove">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Role */}
                  <div className="mb-3 relative">
                    {editingRole === m.id && isAdmin ? (
                      <div className="grid grid-cols-5 gap-1">
                        {ALL_ROLES.map(r => (
                          <button key={r} onClick={() => handleChangeRole(m.id, r)}
                            className={`py-1.5 rounded-lg text-[10px] font-semibold capitalize transition-all ${m.role === r ? `${ROLE_COLORS[r]} text-white` : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}>
                            {ROLE_LABELS[r]}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${ROLE_BADGE[m.role]}`}>{ROLE_LABELS[m.role]}</span>
                        {isAdmin && <button onClick={() => setEditingRole(m.id)} className="text-gray-600 hover:text-blue-400 transition-colors" title="Change role"><Edit3 className="w-3 h-3" /></button>}
                      </div>
                    )}
                  </div>

                  {/* Permissions preview */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {rolePermissions[m.role].slice(0, 4).map(p => <span key={p} className="text-[9px] px-1.5 py-0.5 bg-gray-800 text-gray-500 rounded">{p}</span>)}
                    {rolePermissions[m.role].length > 4 && <span className="text-[9px] px-1.5 py-0.5 bg-gray-800 text-gray-500 rounded">+{rolePermissions[m.role].length - 4}</span>}
                  </div>

                  {/* Login status */}
                  {isAdmin && (
                    <div className="flex items-center gap-2 mb-2 p-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                      <span className="text-[10px] text-emerald-400">Login account active</span>
                      <span className="text-[10px] text-gray-600 ml-auto">{m.email}</span>
                    </div>
                  )}

                  {/* Footer */}
                  <div className="flex items-center justify-between text-xs text-gray-600 pt-3 border-t border-gray-800">
                    <span>Joined {ago(m.joinedAt)}</span>
                    <span className={`capitalize ${m.status === 'online' ? 'text-emerald-400' : m.status === 'away' ? 'text-amber-400' : 'text-gray-600'}`}>{m.status}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══════ ACTIVITY TAB ═══════ */}
      {activeTab === 'activity' && (
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Activity Log ({activityLog.length})</h3>
            {activityLog.length > 0 && <span className="text-xs text-gray-600">Most recent first</span>}
          </div>
          {activityLog.length > 0 ? (
            <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
              {activityLog.slice(0, 30).map(a => (
                <div key={a.id} className="flex items-start gap-3 p-3 bg-gray-800 rounded-xl">
                  <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <Activity className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-medium text-white">{a.action}</span>
                      <span className="text-xs text-gray-600">by {a.userName}</span>
                    </div>
                    <div className="text-xs text-gray-500 truncate">{a.detail}</div>
                  </div>
                  <span className="text-[10px] text-gray-600 flex-shrink-0">{ago(a.timestamp)}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-600">
              <Activity className="w-8 h-8 mx-auto mb-2 text-gray-700" />
              <p className="text-sm">No activity yet. Add team members or scrape leads.</p>
            </div>
          )}
        </div>
      )}

      {/* ═══════ NOTES TAB ═══════ */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          {/* Add Note */}
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2"><Plus className="w-4 h-4 text-violet-400" />Add Note</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <input type="text" value={noteLeadName} onChange={e => setNoteLeadName(e.target.value)} placeholder="Lead name (optional)"
                className="sm:w-48 px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" />
              <input type="text" value={noteText} onChange={e => setNoteText(e.target.value)} placeholder="Write a note…"
                onKeyDown={e => e.key === 'Enter' && handleAddNote()}
                className="flex-1 px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" />
              <button onClick={handleAddNote} className="px-4 py-2.5 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center gap-1.5">
                <Plus className="w-4 h-4" />Add
              </button>
            </div>
          </div>

          {/* Search */}
          {notes.length > 0 && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input type="text" value={noteSearch} onChange={e => setNoteSearch(e.target.value)} placeholder="Search notes…"
                className="w-full pl-9 pr-4 py-2.5 bg-gray-900 border border-gray-800 rounded-xl text-sm text-gray-300 placeholder-gray-600 focus:outline-none focus:border-blue-500" />
            </div>
          )}

          {/* Notes list */}
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            {filteredNotes.length > 0 ? (
              <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
                {filteredNotes.map(n => (
                  <div key={n.id} className="p-3 bg-gray-800 rounded-xl group">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm font-semibold text-white">{n.leadName}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-600">{ago(n.timestamp)}</span>
                        <button onClick={() => { removeNote(n.id); showToast('success', 'Note deleted', ''); }}
                          className="opacity-0 group-hover:opacity-100 text-gray-600 hover:text-red-400 transition-all"><Trash2 className="w-3 h-3" /></button>
                      </div>
                    </div>
                    <p className="text-xs text-gray-300 mb-1.5">{n.note}</p>
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-violet-500 flex items-center justify-center"><span className="text-[7px] text-white font-bold">{initials(n.userName)}</span></div>
                      <span className="text-xs text-gray-500">{n.userName}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-gray-600">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-700" />
                <p className="text-sm">{notes.length === 0 ? 'No notes yet. Add one above.' : 'No notes match your search.'}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════ ROLES TAB ═══════ */}
      {activeTab === 'roles' && (
        <div className="space-y-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-5"><Shield className="w-5 h-5 text-amber-400" /><h3 className="text-white font-semibold">Role Definitions & Permissions</h3></div>
            <div className="space-y-3">
              {ALL_ROLES.map(role => {
                const perms = rolePermissions[role];
                const memberCount = members.filter(m => m.role === role).length;
                return (
                  <div key={role} className="p-4 bg-gray-800 rounded-xl border border-gray-700">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg ${ROLE_COLORS[role]} flex items-center justify-center`}><Users className="w-4 h-4 text-white" /></div>
                        <div>
                          <div className="font-semibold text-white">{ROLE_LABELS[role]}</div>
                          <div className="text-xs text-gray-500">{memberCount} member{memberCount !== 1 ? 's' : ''}</div>
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-semibold ${ROLE_BADGE[role]}`}>{perms.length} permissions</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {perms.map(p => (
                        <span key={p} className="flex items-center gap-1 text-xs px-2 py-1 bg-gray-700 text-gray-300 rounded-lg">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />{p}
                        </span>
                      ))}
                    </div>
                    {/* Members in this role */}
                    {memberCount > 0 && (
                      <div className="mt-3 pt-3 border-t border-gray-700">
                        <div className="text-[10px] text-gray-500 uppercase font-semibold mb-1.5">Members with this role:</div>
                        <div className="flex flex-wrap gap-2">
                          {members.filter(m => m.role === role).map(m => (
                            <div key={m.id} className="flex items-center gap-1.5 px-2 py-1 bg-gray-900 rounded-lg border border-gray-700">
                              <div className={`w-5 h-5 rounded ${m.color} flex items-center justify-center`}><span className="text-[8px] text-white font-bold">{initials(m.name)}</span></div>
                              <span className="text-xs text-gray-300">{m.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {!isAdmin && (
            <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span className="text-sm text-amber-300">Only owners and admins can add members or change roles.</span>
            </div>
          )}
        </div>
      )}

      {/* ═══════ Bottom Stats ═══════ */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4"><Clock className="w-5 h-5 text-gray-400" /><h3 className="text-white font-semibold">Team Summary (Real Data)</h3></div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { label: 'Total Leads', value: String(count) },
            { label: 'Team Members', value: String(members.length + 1) },
            { label: 'Emails Found', value: String(stats.withEmail) },
            { label: 'Hot Leads', value: String(stats.hot) },
            { label: 'Avg Score', value: String(stats.avgScore) },
          ].map(s => (
            <div key={s.label} className="p-3 bg-gray-800 rounded-xl"><div className="text-2xl font-black text-white mb-0.5">{s.value}</div><div className="text-xs text-gray-500">{s.label}</div></div>
          ))}
        </div>
      </div>
    </div>
  );
}
