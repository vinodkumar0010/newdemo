import { useState } from 'react';
import { CheckCircle2, Zap, Crown, Building2, Star, CreditCard, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { getStripeKey, getStripePriceId, isStripeConfigured } from '../lib/stripeConfig';

type PlanId = 'free' | 'pro' | 'agency' | 'enterprise';

const plans: {
  id: PlanId; name: string; price: string; priceNum: number; period: string;
  icon: typeof Zap; color: string; border: string; badge: string | null;
  features: string[]; missing: string[]; cta: string; ctaStyle: string;
}[] = [
  {
    id: 'free', name: 'Free', price: '$0', priceNum: 0, period: '/month', icon: Zap,
    color: 'from-gray-500 to-gray-600', border: 'border-gray-700', badge: null,
    cta: 'Current Plan', ctaStyle: 'bg-gray-700 hover:bg-gray-600 text-white',
    features: [
      '100 Leads per Day',
      'Max 100 Leads per Scrape',
      'Google Maps Scraping',
      'Basic Lead Scoring',
      'CSV Export',
      'Search & Filter Leads',
      'Lead Delete & Management',
      'Community Support',
    ],
    missing: ['AI Email Finder', 'AI Website Analysis', 'Google Sheets Sync', 'AI Outreach', 'Team Workspace'],
  },
  {
    id: 'pro', name: 'Pro', price: '$29', priceNum: 29, period: '/month', icon: Star,
    color: 'from-blue-500 to-cyan-500', border: 'border-blue-500/40', badge: 'Most Popular',
    cta: 'Upgrade to Pro', ctaStyle: 'bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-400 hover:to-cyan-400 text-white shadow-lg shadow-blue-900/30',
    features: [
      'Unlimited Daily Leads',
      'Max 100 Leads per Scrape',
      'AI Email Finder (Website Crawling)',
      'AI Lead Scoring (0-100)',
      'AI Website Analysis (SEO Audit)',
      'AI Opportunity Detection',
      'Google Sheets Real-Time Sync',
      'Advanced Filters (Rating, Score, City)',
      'Smart Filters (Email, Website, Social)',
      'CSV + Excel + JSON Export',
      'Full Audit Report Download',
      'Email Generator (Personalized)',
      'Decision Maker Discovery',
      'Social Media Extraction',
      'Priority Email Support',
    ],
    missing: ['Team Workspace', 'AI Outreach Generator', 'Voice Agent Export'],
  },
  {
    id: 'agency', name: 'Agency', price: '$99', priceNum: 99, period: '/month', icon: Building2,
    color: 'from-violet-500 to-purple-500', border: 'border-violet-500/40', badge: 'Agency Killer',
    cta: 'Start Agency Trial', ctaStyle: 'bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-400 hover:to-purple-400 text-white shadow-lg shadow-violet-900/30',
    features: [
      'Everything in Pro',
      'Team Workspace (10 Users)',
      'AI Outreach Generator (Email, LinkedIn, WhatsApp)',
      'AI Voice Call Script Generator',
      'Voice Agent Export (Vapi, Bland AI, Retell, Omnidim)',
      'Competitor Discovery & Analysis',
      'Review Intelligence (AI Sentiment)',
      'White Label PDF Audit Reports',
      'Bulk Outreach Generation',
      'Team Activity Log & Notes',
      'Role-Based Access Control (5 Roles)',
      'Dedicated Account Manager',
    ],
    missing: ['Unlimited Users', 'Custom AI Training'],
  },
  {
    id: 'enterprise', name: 'Enterprise', price: '$299', priceNum: 299, period: '/month', icon: Crown,
    color: 'from-amber-500 to-orange-500', border: 'border-amber-500/40', badge: 'Full Power',
    cta: 'Contact Sales', ctaStyle: 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white shadow-lg shadow-amber-900/30',
    features: [
      'Everything in Agency',
      'Unlimited Team Members',
      'Full API Access',
      'Custom Branding & White Label',
      'Advanced Google Sheets Integration',
      'Dedicated Infrastructure',
      'SLA Guarantee (99.9% Uptime)',
      'Custom AI Model Training',
      'Priority 24/7 Support (WhatsApp + Email)',
      'Onboarding + Training Sessions',
      'Custom Feature Development',
      'Multi-Location Bulk Scraping',
    ],
    missing: [],
  },
];

const comparisonRows = [
  { feature: 'Daily Lead Limit', values: ['100', 'Unlimited', 'Unlimited', 'Unlimited'] },
  { feature: 'Leads per Scrape', values: ['100', '100', '100', '100'] },
  { feature: 'AI Email Finder', values: [false, true, true, true] },
  { feature: 'AI Lead Scoring', values: ['Basic', 'Advanced', 'Advanced', 'Advanced'] },
  { feature: 'Website Analysis & SEO Audit', values: [false, true, true, true] },
  { feature: 'Google Sheets Sync', values: [false, true, true, true] },
  { feature: 'AI Outreach Generator', values: [false, false, true, true] },
  { feature: 'Team Workspace', values: [false, false, '10 users', 'Unlimited'] },
  { feature: 'Voice Agent Export', values: [false, false, true, true] },
  { feature: 'Competitor Discovery', values: [false, false, true, true] },
  { feature: 'Review Intelligence', values: [false, false, true, true] },
  { feature: 'White Label Reports', values: [false, false, true, true] },
  { feature: 'API Access', values: [false, false, false, true] },
  { feature: 'Custom AI Training', values: [false, false, false, true] },
  { feature: 'Support', values: ['Community', 'Email', 'Dedicated Manager', '24/7 Priority'] },
];

function getPriceId(planId: PlanId): string {
  if (planId === 'pro') return getStripePriceId('pro');
  if (planId === 'agency') return getStripePriceId('agency');
  if (planId === 'enterprise') return getStripePriceId('enterprise');
  return '';
}

export default function Pricing() {
  const { user, updatePlan } = useAuth();
  const { showToast } = useToast();
  const [processing, setProcessing] = useState<PlanId | null>(null);

  const isOwner = user?.role === 'owner';
  const currentPlan = user?.plan || 'free';
  const planOrder: PlanId[] = ['free', 'pro', 'agency', 'enterprise'];

  const stripeConfigured = isStripeConfigured();

  // ── Load Stripe.js dynamically ──
  const loadStripe = async (): Promise<any> => {
    const pk = getStripeKey();
    if (!pk) return null;
    // Check if already loaded
    if ((window as any).Stripe) return (window as any).Stripe(pk);
    // Load script
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://js.stripe.com/v3/';
      script.onload = () => resolve((window as any).Stripe?.(pk) || null);
      script.onerror = () => resolve(null);
      document.head.appendChild(script);
    });
  };

  // ── Handle plan upgrade with real Stripe ──
  const handlePlanClick = async (planId: PlanId) => {
    if (planId === currentPlan) { showToast('info', 'Already on this plan', ''); return; }
    if (planId === 'free') { updatePlan('free'); showToast('success', 'Downgraded to Free', ''); return; }

    if (!stripeConfigured) {
      showToast('error', 'Payment not configured', isOwner ? 'Go to Settings → Stripe Payment Gateway → enter your keys' : 'Contact the administrator to set up payments');
      return;
    }

    const priceId = getPriceId(planId);
    if (!priceId) {
      showToast('error', `Price ID not set for ${planId}`, isOwner ? 'Go to Settings → Stripe → enter the Price ID for this plan' : 'Contact administrator');
      return;
    }

    setProcessing(planId);

    try {
      const stripe = await loadStripe();
      if (!stripe) {
        showToast('error', 'Stripe failed to load', 'Check your Publishable Key in Settings');
        setProcessing(null);
        return;
      }

      // Redirect to Stripe Checkout
      const { error } = await stripe.redirectToCheckout({
        lineItems: [{ price: priceId, quantity: 1 }],
        mode: 'subscription',
        successUrl: `${window.location.origin}?payment=success&plan=${planId}`,
        cancelUrl: `${window.location.origin}?payment=cancelled`,
        customerEmail: user?.email || undefined,
      });

      if (error) {
        showToast('error', 'Payment error', error.message || 'Something went wrong');
      }
    } catch (err: any) {
      showToast('error', 'Payment failed', err?.message || 'Could not connect to Stripe');
    }

    setProcessing(null);
  };

  // ── Check for payment success return from Stripe ──
  useState(() => {
    const params = new URLSearchParams(window.location.search);
    const payment = params.get('payment');
    const plan = params.get('plan') as PlanId | null;
    if (payment === 'success' && plan) {
      updatePlan(plan);
      showToast('success', 'Payment successful!', `Upgraded to ${plan} plan`);
      window.history.replaceState({}, '', window.location.pathname);
    } else if (payment === 'cancelled') {
      showToast('info', 'Payment cancelled', 'No charges were made');
      window.history.replaceState({}, '', window.location.pathname);
    }
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="text-center py-4">
        <h2 className="text-3xl font-black text-white mb-2">Choose Your Plan</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">From solo freelancers to enterprise agencies — scale your lead generation with AI-powered tools.</p>
        {isOwner && !stripeConfigured && (
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl text-sm">
            <AlertCircle className="w-4 h-4" />
            Stripe not configured — <a href="#" onClick={e => { e.preventDefault(); showToast('info', 'Go to Settings', 'Settings → Stripe Payment Gateway → enter your keys'); }} className="underline font-semibold">Set up in Settings</a>
          </div>
        )}
        {isOwner && stripeConfigured && (
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-sm">
            <CheckCircle2 className="w-4 h-4" />
            Stripe payments active
          </div>
        )}
      </div>

      {/* Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
        {plans.map(plan => {
          const Icon = plan.icon;
          const isCurrent = plan.id === currentPlan;
          const isUpgrade = planOrder.indexOf(plan.id) > planOrder.indexOf(currentPlan as PlanId);
          const isDowngrade = planOrder.indexOf(plan.id) < planOrder.indexOf(currentPlan as PlanId);
          const isProcessingThis = processing === plan.id;

          return (
            <div key={plan.id} className={`relative bg-gray-900 border ${isCurrent ? 'border-emerald-500/60 ring-2 ring-emerald-500/20' : plan.border} rounded-2xl p-5 flex flex-col ${plan.id === 'pro' && !isCurrent ? 'ring-1 ring-blue-500/30' : ''}`}>
              {plan.badge && <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-gradient-to-r ${plan.color} text-white text-xs font-bold rounded-full whitespace-nowrap`}>{plan.badge}</div>}
              {isCurrent && <div className="absolute -top-3 right-4 px-3 py-1 bg-emerald-500 text-white text-xs font-bold rounded-full">Current</div>}

              <div className="flex items-center gap-3 mb-4 mt-2">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center`}><Icon className="w-5 h-5 text-white" /></div>
                <div className="text-lg font-bold text-white">{plan.name}</div>
              </div>

              <div className="mb-5"><div className="flex items-baseline gap-1"><span className={`text-4xl font-black bg-gradient-to-r ${plan.color} bg-clip-text text-transparent`}>{plan.price}</span><span className="text-gray-500 text-sm">{plan.period}</span></div></div>

              <button
                onClick={() => handlePlanClick(plan.id)}
                disabled={isCurrent || !!processing}
                className={`w-full py-2.5 rounded-xl text-sm font-bold transition-all mb-5 disabled:opacity-50 ${isCurrent ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 cursor-default' : plan.ctaStyle}`}
              >
                {isProcessingThis ? (
                  <span className="flex items-center justify-center gap-2"><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>Redirecting to Stripe…</span>
                ) : isCurrent ? '✓ Current Plan' : isUpgrade ? `Upgrade — ${plan.price}/mo` : isDowngrade ? `Downgrade to ${plan.name}` : plan.cta}
              </button>

              <div className="space-y-2 flex-1">
                {plan.features.map(f => <div key={f} className="flex items-start gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /><span className="text-xs text-gray-300">{f}</span></div>)}
                {plan.missing.slice(0, 3).map(f => <div key={f} className="flex items-start gap-2 opacity-40"><div className="w-4 h-4 flex-shrink-0 mt-0.5 flex items-center justify-center"><div className="w-3 h-0.5 bg-gray-600 rounded"></div></div><span className="text-xs text-gray-500 line-through">{f}</span></div>)}
              </div>
            </div>
          );
        })}
      </div>

      {/* USP */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-900 via-violet-900 to-indigo-900 border border-blue-700/50 rounded-2xl p-6">
        <div className="relative text-center">
          <div className="text-xl font-black text-white mb-2">🚀 Ultimate USP</div>
          <p className="text-blue-200 text-sm max-w-3xl mx-auto leading-relaxed">
            <span className="text-white font-bold">Scrape Google Maps</span>{' → '}<span className="text-white font-bold">Find Contacts</span>{' → '}<span className="text-white font-bold">Analyze Website</span>{' → '}<span className="text-white font-bold">Score Leads</span>{' → '}<span className="text-white font-bold">Generate Outreach</span>{' → '}<span className="text-white font-bold">Export to Google Sheets & AI Voice Agents</span>
          </p>
        </div>
      </div>

      {/* Comparison */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 overflow-x-auto">
        <h3 className="text-white font-semibold mb-4">Full Feature Comparison</h3>
        <table className="w-full text-sm min-w-[640px]">
          <thead><tr className="border-b border-gray-800"><th className="text-left text-gray-500 pb-3 pr-4">Feature</th>{plans.map(p => <th key={p.id} className="text-center text-gray-300 pb-3 px-2">{p.name}</th>)}</tr></thead>
          <tbody>{comparisonRows.map(({ feature, values }) => (
            <tr key={feature} className="border-b border-gray-800/50"><td className="py-2.5 pr-4 text-gray-400">{feature}</td>
              {values.map((val, i) => <td key={i} className="py-2.5 px-2 text-center">{typeof val === 'boolean' ? (val ? <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" /> : <div className="w-4 h-0.5 bg-gray-700 mx-auto rounded"></div>) : <span className="text-xs text-white font-semibold">{val}</span>}</td>)}
            </tr>
          ))}</tbody>
        </table>
      </div>

      {/* How Stripe Payment Works — info for owner */}
      {isOwner && (
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3"><CreditCard className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold">How Stripe Payments Work</h3></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-center">
            {[
              { step: '1', label: 'User clicks Upgrade', desc: 'On this Pricing page' },
              { step: '2', label: 'Redirected to Stripe', desc: 'Stripe\'s secure checkout page' },
              { step: '3', label: 'User pays with card', desc: 'Stripe handles PCI compliance' },
              { step: '4', label: 'Returns to app', desc: 'Plan upgrades automatically' },
            ].map(s => (
              <div key={s.step} className="p-3 bg-gray-800 rounded-xl">
                <div className="text-2xl font-black text-violet-400 mb-1">{s.step}</div>
                <div className="text-white text-sm font-semibold">{s.label}</div>
                <div className="text-gray-500 text-xs">{s.desc}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 p-3 bg-violet-500/5 border border-violet-500/20 rounded-xl">
            <p className="text-xs text-violet-300">💡 <strong>No secret key needed in the app.</strong> The Publishable Key (pk_test/pk_live) is safe to use in frontend. Stripe handles all card processing on their secure servers. You manage payments, refunds, and subscriptions from <a href="https://dashboard.stripe.com" target="_blank" rel="noopener noreferrer" className="underline">dashboard.stripe.com</a>.</p>
          </div>
        </div>
      )}

      {/* Brand */}
      <div className="flex items-center justify-center gap-4 py-4">
        <div className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-blue-900/40 to-red-900/40 border border-gray-700 rounded-2xl">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center"><span className="text-white text-sm font-black">ME</span></div>
          <div><div className="flex items-center gap-1"><span className="text-blue-400 font-black text-lg">MASTER</span><span className="text-red-400 font-black text-lg">EDGE</span></div><div className="text-gray-500 text-xs">Technology</div></div>
        </div>
      </div>
    </div>
  );
}
