import { useState } from 'react';
import { Key, Bell, Globe, Shield, Zap, CheckCircle2, User, Mail, Lock, Eye, EyeOff, AlertCircle, Trash2, CreditCard, Users, Crown, ChevronDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useLeadCount } from '../context/LeadContext';
import { getOwnerKey, setOwnerKey, hasOwnerKey } from '../lib/ownerKeys';

const securityItems = ['Store data locally (IndexedDB)', 'Enable data encryption', 'Auto-delete leads after 90 days', 'GDPR compliance mode'];
function SecurityBlock() {
  const [s, setS] = useState<Record<string, boolean>>({ [securityItems[0]]: true, [securityItems[1]]: true, [securityItems[2]]: false, [securityItems[3]]: false });
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4"><Shield className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold">Security &amp; Privacy</h3></div>
      <div className="space-y-3">{securityItems.map(o => (
        <div key={o} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl"><span className="text-sm text-gray-300">{o}</span>
          <button onClick={() => setS(p => ({ ...p, [o]: !p[o] }))} className={`relative w-11 h-6 rounded-full transition-colors ${s[o] ? 'bg-violet-500' : 'bg-gray-700'}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${s[o] ? 'translate-x-5' : 'translate-x-0.5'}`}></span></button>
        </div>
      ))}</div>
    </div>
  );
}

/* reusable secret field */
function SecretField({ label, value, onChange, placeholder, show, onToggle }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; show: boolean; onToggle: () => void }) {
  return (
    <div>
      <label className="block text-sm text-gray-400 mb-1.5 font-medium">{label}</label>
      <div className="relative">
        <input type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-blue-500 pr-10" />
        <button type="button" onClick={onToggle} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">{show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
      </div>
    </div>
  );
}

/* ── User Management (Owner only) ── */
function UserManagement() {
  const { showToast } = useToast();
  const [users, setUsers] = useState<any[]>(() => {
    try { return JSON.parse(localStorage.getItem('maps_scraper_users') || '[]'); } catch { return []; }
  });
  const [editPlan, setEditPlan] = useState<string | null>(null);

  const refresh = () => {
    try { setUsers(JSON.parse(localStorage.getItem('maps_scraper_users') || '[]')); } catch {}
  };

  const changePlan = (userId: string, plan: string) => {
    const all = JSON.parse(localStorage.getItem('maps_scraper_users') || '[]');
    const idx = all.findIndex((u: any) => u.id === userId);
    if (idx >= 0) {
      all[idx].plan = plan;
      localStorage.setItem('maps_scraper_users', JSON.stringify(all));
      setUsers(all);
      setEditPlan(null);
      showToast('success', 'Plan updated', `${all[idx].name}: ${plan}`);
    }
  };

  const changeRole = (userId: string, role: string) => {
    const all = JSON.parse(localStorage.getItem('maps_scraper_users') || '[]');
    const idx = all.findIndex((u: any) => u.id === userId);
    if (idx >= 0) {
      all[idx].role = role;
      localStorage.setItem('maps_scraper_users', JSON.stringify(all));
      setUsers(all);
      showToast('success', 'Role updated', `${all[idx].name}: ${role}`);
    }
  };

  const deleteUser = (userId: string) => {
    const all = JSON.parse(localStorage.getItem('maps_scraper_users') || '[]');
    const u = all.find((x: any) => x.id === userId);
    const filtered = all.filter((x: any) => x.id !== userId);
    localStorage.setItem('maps_scraper_users', JSON.stringify(filtered));
    setUsers(filtered);
    showToast('success', 'User deleted', u?.name || '');
  };

  const planColors: Record<string, string> = { free: 'bg-gray-500/10 text-gray-400 border-gray-500/20', pro: 'bg-blue-500/10 text-blue-400 border-blue-500/20', agency: 'bg-violet-500/10 text-violet-400 border-violet-500/20', enterprise: 'bg-amber-500/10 text-amber-400 border-amber-500/20' };
  const roleColors: Record<string, string> = { owner: 'bg-amber-500/10 text-amber-400 border-amber-500/20', admin: 'bg-blue-500/10 text-blue-400 border-blue-500/20', user: 'bg-gray-500/10 text-gray-400 border-gray-500/20' };

  return (
    <div className="bg-gradient-to-r from-indigo-900/20 to-blue-900/20 border border-indigo-700/40 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2"><Users className="w-5 h-5 text-indigo-400" /><h3 className="text-white font-semibold text-lg">User Management</h3><span className="text-[10px] px-2 py-0.5 bg-indigo-500/20 text-indigo-400 rounded-full border border-indigo-500/30 font-bold">OWNER</span></div>
        <button onClick={refresh} className="text-xs text-gray-500 hover:text-white transition-colors">Refresh</button>
      </div>
      <p className="text-gray-400 text-sm mb-4">Manage all registered users — view plans, change roles, upgrade/downgrade accounts.</p>

      {users.length === 0 ? (
        <div className="text-center py-8 text-gray-600">No users found</div>
      ) : (
        <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-1">
          {users.map((u: any) => (
            <div key={u.id} className="flex flex-wrap items-center gap-3 p-3 bg-gray-800/60 rounded-xl border border-gray-700">
              {/* Avatar */}
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${u.role === 'owner' ? 'bg-gradient-to-br from-amber-500 to-orange-500' : 'bg-gradient-to-br from-blue-500 to-violet-500'}`}>
                <span className="text-white text-xs font-bold">{(u.name || 'U').split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase()}</span>
              </div>
              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-white truncate">{u.name || 'Unknown'}</div>
                <div className="text-xs text-gray-500 truncate">{u.email}</div>
              </div>
              {/* Role */}
              <div className="relative">
                {u.role === 'owner' ? (
                  <span className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-semibold ${roleColors[u.role] || roleColors.user}`}><Crown className="w-3 h-3" />{u.role}</span>
                ) : (
                  <select value={u.role} onChange={e => changeRole(u.id, e.target.value)}
                    className="text-[10px] px-2 py-1 bg-gray-900 border border-gray-700 rounded-lg text-gray-300 font-semibold capitalize cursor-pointer focus:outline-none focus:border-blue-500">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                )}
              </div>
              {/* Plan */}
              {editPlan === u.id ? (
                <div className="flex gap-1">
                  {['free', 'pro', 'agency', 'enterprise'].map(p => (
                    <button key={p} onClick={() => changePlan(u.id, p)}
                      className={`text-[10px] px-2 py-1 rounded-lg font-semibold capitalize transition-all ${u.plan === p ? 'bg-blue-600 text-white' : 'bg-gray-900 border border-gray-700 text-gray-400 hover:border-blue-500'}`}>{p}</button>
                  ))}
                </div>
              ) : (
                <button onClick={() => setEditPlan(u.id)} className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold capitalize ${planColors[u.plan] || planColors.free}`}>
                  {u.plan || 'free'} <ChevronDown className="w-2.5 h-2.5 inline" />
                </button>
              )}
              {/* Joined */}
              <span className="text-[10px] text-gray-600 hidden sm:block">{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}</span>
              {/* Delete */}
              {u.role !== 'owner' && (
                <button onClick={() => { if (confirm(`Delete ${u.name}?`)) deleteUser(u.id); }} className="p-1 text-gray-600 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="mt-3 pt-3 border-t border-gray-700 flex items-center justify-between text-xs text-gray-500">
        <span>{users.length} total users</span>
        <span>{users.filter((u: any) => u.plan !== 'free').length} paid users</span>
      </div>
    </div>
  );
}

export default function Settings() {
  const { user, updateProfile } = useAuth();
  const { showToast } = useToast();
  const { apiKey, setApiKey } = useLeadCount();
  const isOwner = user?.role === 'owner' || user?.role === 'admin';

  // profile
  const [profileName, setProfileName] = useState(user?.name || '');
  const [profileEmail, setProfileEmail] = useState(user?.email || '');
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);

  // google places
  const [localApiKey, setLocalApiKey] = useState(apiKey);
  const [showKey, setShowKey] = useState(false);

  // notifications — persist in localStorage
  const [notifications, setNotifications] = useState(() => {
    try { const s = localStorage.getItem('ms_notifications'); return s ? JSON.parse(s) : { scrapeComplete: true, hotLeadFound: true, emailFound: false, exportReady: true }; } catch { return { scrapeComplete: true, hotLeadFound: true, emailFound: false, exportReady: true }; }
  });

  const toggleNotification = (key: string, value: boolean) => {
    const updated = { ...notifications, [key]: !value };
    setNotifications(updated);
    localStorage.setItem('ms_notifications', JSON.stringify(updated));
    // Request browser notification permission if enabling
    if (!value && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    showToast('success', !value ? 'Notification enabled' : 'Notification disabled', '');
  };

  // stripe
  const [stripePk, setStripePk] = useState(getOwnerKey('stripe_pk'));
  const [stripeMode, setStripeMode] = useState(getOwnerKey('stripe_mode') || 'test');
  const [pricePro, setPricePro] = useState(getOwnerKey('stripe_price_pro'));
  const [priceAgency, setPriceAgency] = useState(getOwnerKey('stripe_price_agency'));
  const [priceEnterprise, setPriceEnterprise] = useState(getOwnerKey('stripe_price_enterprise'));
  const [showStripe, setShowStripe] = useState(false);

  // resend email
  const [resendKey, setResendKey] = useState(getOwnerKey('resend_api_key'));
  const [resendFrom, setResendFrom] = useState(getOwnerKey('resend_from') || '');
  const [showResend, setShowResend] = useState(false);

  // handlers
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) { showToast('error', 'Name required', ''); return; }
    updateProfile({ name: profileName, email: profileEmail });
    showToast('success', 'Profile updated!', '');
  };
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmNewPassword) { showToast('error', 'Fill all fields', ''); return; }
    if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) { showToast('error', 'Weak password', '8+, uppercase & number'); return; }
    if (newPassword !== confirmNewPassword) { showToast('error', 'Mismatch', ''); return; }
    showToast('success', 'Password updated!', '');
    setShowPasswordForm(false); setCurrentPassword(''); setNewPassword(''); setConfirmNewPassword('');
  };
  const handleSaveApiKey = () => {
    setApiKey(localApiKey.trim());
    showToast('success', localApiKey.trim() ? 'Google API Key saved!' : 'Key removed', localApiKey.trim() ? 'Real data mode' : 'Demo mode');
  };
  const handleSaveStripe = () => {
    if (!stripePk.trim()) { showToast('error', 'Missing Publishable Key', 'Enter your Stripe pk_... key'); return; }
    if (!stripePk.trim().startsWith('pk_')) { showToast('error', 'Invalid Publishable Key', 'Key must start with pk_test_ or pk_live_'); return; }
    // Validate price IDs
    const priceIds = [pricePro, priceAgency, priceEnterprise].filter(p => p.trim());
    const wrongIds = priceIds.filter(p => p.trim().startsWith('prod_'));
    if (wrongIds.length > 0) { showToast('error', 'Wrong ID type!', 'You entered a Product ID (prod_xxx). Use the Price ID (price_xxx) instead. Find it in Stripe → Products → click product → Pricing section.'); return; }
    const invalidIds = priceIds.filter(p => p.trim() && !p.trim().startsWith('price_'));
    if (invalidIds.length > 0) { showToast('error', 'Invalid Price ID', 'Price IDs must start with price_ — find them in Stripe Dashboard → Products → Pricing'); return; }
    setOwnerKey('stripe_pk', stripePk.trim());
    setOwnerKey('stripe_mode', stripeMode);
    setOwnerKey('stripe_price_pro', pricePro.trim());
    setOwnerKey('stripe_price_agency', priceAgency.trim());
    setOwnerKey('stripe_price_enterprise', priceEnterprise.trim());
    showToast('success', 'Stripe configuration saved!', `Mode: ${stripeMode === 'live' ? '🔴 LIVE' : '🟡 TEST'}`);
  };

  const handleSaveResend = () => {
    if (!resendKey.trim()) { showToast('error', 'Missing API Key', 'Enter Resend API key'); return; }
    setOwnerKey('resend_api_key', resendKey.trim());
    setOwnerKey('resend_from', resendFrom.trim());
    showToast('success', 'Email service saved!', 'Forgot Password emails will be sent via Resend');
  };

  return (
    <div className="p-6 space-y-6">
      {/* ── Profile ── */}
      {user && (
        <div className="bg-gradient-to-r from-blue-900/30 to-violet-900/30 border border-blue-700/40 rounded-2xl p-5">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center shadow-lg"><span className="text-white text-xl font-black">{user.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}</span></div>
            <div><div className="text-xl font-bold text-white">{user.name}</div><div className="text-sm text-gray-400">{user.email}</div>
              <div className="flex items-center gap-2 mt-1.5"><span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20 font-semibold capitalize">{user.role}</span><span className="text-[10px] px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20 font-semibold capitalize">{user.plan} Plan</span></div></div>
          </div>
          <div className="pt-5 border-t border-white/10">
            <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2"><User className="w-4 h-4 text-blue-400" />Edit Profile</h3>
            <form onSubmit={handleSaveProfile} className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div><label className="block text-xs text-gray-400 mb-1">Full Name</label><input type="text" value={profileName} onChange={e => setProfileName(e.target.value)} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 focus:outline-none focus:border-blue-500" /></div>
              <div><label className="block text-xs text-gray-400 mb-1">Email</label><div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" /><input type="email" value={profileEmail} onChange={e => setProfileEmail(e.target.value)} className="w-full pl-9 pr-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 focus:outline-none focus:border-blue-500" /></div></div>
              <div className="md:col-span-2 flex items-center gap-2"><button type="submit" className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold">Save</button><button type="button" onClick={() => setShowPasswordForm(!showPasswordForm)} className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl text-sm font-semibold border border-gray-700"><Lock className="w-3.5 h-3.5 inline mr-1.5" />Password</button></div>
            </form>
            {showPasswordForm && (
              <form onSubmit={handleChangePassword} className="mt-4 pt-4 border-t border-white/10 grid grid-cols-1 md:grid-cols-3 gap-3">
                <div><label className="block text-xs text-gray-400 mb-1">Current</label><div className="relative"><input type={showCurrent ? 'text' : 'password'} value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300" /><button type="button" onClick={() => setShowCurrent(!showCurrent)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">{showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div></div>
                <div><label className="block text-xs text-gray-400 mb-1">New</label><div className="relative"><input type={showNew ? 'text' : 'password'} value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300" /><button type="button" onClick={() => setShowNew(!showNew)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">{showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div></div>
                <div><label className="block text-xs text-gray-400 mb-1">Confirm</label><input type="password" value={confirmNewPassword} onChange={e => setConfirmNewPassword(e.target.value)} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300" /></div>
                <div className="md:col-span-3 flex gap-2"><button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-sm font-semibold">Update</button><button type="button" onClick={() => { setShowPasswordForm(false); setCurrentPassword(''); setNewPassword(''); setConfirmNewPassword(''); }} className="px-4 py-2 bg-gray-800 text-gray-300 rounded-xl text-sm font-semibold">Cancel</button></div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ══════ OWNER: User Management ══════ */}
      {isOwner && <UserManagement />}

      {/* ── Google Places API Key (all users) ── */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-2">
          <Key className="w-5 h-5 text-amber-400" /><h3 className="text-white font-semibold text-lg">Google Places API Key</h3>
          {apiKey ? <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold ml-2 px-2 py-0.5 bg-emerald-500/10 rounded-full border border-emerald-500/20"><CheckCircle2 className="w-3 h-3" />Active</span>
                  : <span className="flex items-center gap-1 text-[10px] text-amber-400 font-semibold ml-2 px-2 py-0.5 bg-amber-500/10 rounded-full border border-amber-500/20"><AlertCircle className="w-3 h-3" />Demo</span>}
        </div>
        <p className="text-gray-500 text-sm mb-4">Add your Google Places API key to scrape real business data from Google Maps.</p>
        <div className="flex gap-2">
          <div className="relative flex-1"><input type={showKey ? 'text' : 'password'} value={localApiKey} onChange={e => setLocalApiKey(e.target.value)} placeholder="Enter Google API Key (AIzaSy…)" className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 font-mono focus:outline-none focus:border-amber-500 pr-10" /><button onClick={() => setShowKey(!showKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">{showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div>
          <button onClick={handleSaveApiKey} className="flex items-center gap-1.5 px-4 py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-sm"><Key className="w-4 h-4" />Save</button>
          {apiKey && <button onClick={() => { setLocalApiKey(''); setApiKey(''); showToast('info', 'Removed', 'Demo mode'); }} className="px-3 py-3 bg-gray-800 hover:bg-red-500/20 text-gray-400 hover:text-red-400 rounded-xl"><Trash2 className="w-4 h-4" /></button>}
        </div>
        <div className="mt-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl"><p className="text-xs text-blue-300">💡 <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="underline">Google Cloud Console</a> → Create Project → Enable "Places API (New)" → Create Key → Paste above.</p></div>
      </div>

      {/* ══════ OWNER: Stripe Payment Gateway ══════ */}
      {isOwner && (
        <div className="bg-gradient-to-r from-violet-900/20 to-indigo-900/20 border border-violet-700/40 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <CreditCard className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold text-lg">Stripe Payment Gateway</h3>
            <span className="text-[10px] px-2 py-0.5 bg-violet-500/20 text-violet-400 rounded-full border border-violet-500/30 font-bold">OWNER</span>
            {hasOwnerKey('stripe_pk') ? <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold ml-auto px-2 py-0.5 bg-emerald-500/10 rounded-full border border-emerald-500/20"><CheckCircle2 className="w-3 h-3" />Configured</span>
              : <span className="flex items-center gap-1 text-[10px] text-red-400 font-semibold ml-auto px-2 py-0.5 bg-red-500/10 rounded-full border border-red-500/20"><AlertCircle className="w-3 h-3" />Not set</span>}
          </div>
          <p className="text-gray-400 text-sm mb-4">Enter your Stripe keys so users can pay for plan upgrades. Get keys from <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener noreferrer" className="text-violet-400 underline">Stripe Dashboard</a>.</p>

          <div className="space-y-4">
            <SecretField label="Publishable Key (pk_test_… or pk_live_…) *" value={stripePk} onChange={setStripePk} placeholder="pk_test_xxxxxxxxxxxx" show={showStripe} onToggle={() => setShowStripe(!showStripe)} />

            <div className="p-3 bg-red-500/5 border border-red-500/20 rounded-xl mb-3">
              <p className="text-xs text-red-300">⚠️ <strong>Use Price ID (price_xxx), NOT Product ID (prod_xxx).</strong> In Stripe Dashboard → Products → click your product → scroll down to Pricing → copy the <code className="bg-gray-800 px-1 rounded">price_</code> ID.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div><label className="block text-sm text-gray-400 mb-1.5">Pro Price ID</label><input type="text" value={pricePro} onChange={e => setPricePro(e.target.value)} placeholder="price_1Nxxxxxxxxxxxx" className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 font-mono focus:outline-none focus:border-violet-500" /></div>
              <div><label className="block text-sm text-gray-400 mb-1.5">Agency Price ID</label><input type="text" value={priceAgency} onChange={e => setPriceAgency(e.target.value)} placeholder="price_1Nxxxxxxxxxxxx" className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 font-mono focus:outline-none focus:border-violet-500" /></div>
              <div><label className="block text-sm text-gray-400 mb-1.5">Enterprise Price ID</label><input type="text" value={priceEnterprise} onChange={e => setPriceEnterprise(e.target.value)} placeholder="price_1Nxxxxxxxxxxxx" className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 font-mono focus:outline-none focus:border-violet-500" /></div>
            </div>

            <div><label className="block text-sm text-gray-400 mb-1.5">Payment Mode</label>
              <div className="flex gap-2">
                <button onClick={() => setStripeMode('test')} className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${stripeMode === 'test' ? 'bg-blue-600 text-white' : 'bg-gray-800 border border-gray-700 text-gray-400'}`}>🟡 Test (Sandbox)</button>
                <button onClick={() => setStripeMode('live')} className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${stripeMode === 'live' ? 'bg-red-600 text-white' : 'bg-gray-800 border border-gray-700 text-gray-400'}`}>🔴 Live (Real Payments)</button>
              </div>
            </div>

            <button onClick={handleSaveStripe} className="w-full py-3 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-xl text-sm transition-colors flex items-center justify-center gap-2"><CreditCard className="w-4 h-4" />Save Stripe Configuration</button>

            {stripeMode === 'live' && <div className="p-3 bg-red-500/5 border border-red-500/20 rounded-xl flex items-start gap-2"><AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" /><p className="text-xs text-red-300"><strong>⚠ LIVE MODE</strong> — Real money will be charged. Ensure your Stripe account is verified.</p></div>}

            <div className="p-3 bg-violet-500/5 border border-violet-500/20 rounded-xl">
              <p className="text-xs text-violet-300">💡 <strong>How to get keys:</strong> <a href="https://dashboard.stripe.com" target="_blank" rel="noopener noreferrer" className="underline">stripe.com</a> → Developers → API Keys → Copy Publishable Key. Create Products → Copy each Price ID (price_xxxx). Use <strong>Test</strong> keys first to verify.</p>
            </div>
          </div>
        </div>
      )}

      {/* Google OAuth — pre-configured, no settings needed */}
      {isOwner && (
        <div className="bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border border-blue-700/40 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center"><Globe className="w-5 h-5 text-blue-400" /></div>
          <div className="flex-1"><div className="text-white font-semibold">Google Sign-In</div><div className="text-xs text-gray-500">Pre-configured — users can sign in with Google</div></div>
          <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold px-2.5 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20"><CheckCircle2 className="w-3 h-3" />Active</span>
        </div>
      )}

      {/* ══════ OWNER: Resend Email Service ══════ */}
      {isOwner && (
        <div className="bg-gradient-to-r from-emerald-900/20 to-teal-900/20 border border-emerald-700/40 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <Mail className="w-5 h-5 text-emerald-400" /><h3 className="text-white font-semibold text-lg">Email Service (Resend)</h3>
            <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-500/30 font-bold">OWNER</span>
            {hasOwnerKey('resend_api_key') ? <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold ml-auto px-2 py-0.5 bg-emerald-500/10 rounded-full border border-emerald-500/20"><CheckCircle2 className="w-3 h-3" />Active</span>
              : <span className="flex items-center gap-1 text-[10px] text-amber-400 font-semibold ml-auto px-2 py-0.5 bg-amber-500/10 rounded-full border border-amber-500/20"><AlertCircle className="w-3 h-3" />Not set</span>}
          </div>
          <p className="text-gray-400 text-sm mb-4">Enable "Forgot Password" emails for your users. Get a free API key from <a href="https://resend.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-emerald-400 underline">resend.com</a> (100 free emails/day).</p>
          <div className="space-y-4">
            <SecretField label="Resend API Key *" value={resendKey} onChange={setResendKey} placeholder="re_xxxxxxxxxxxx" show={showResend} onToggle={() => setShowResend(!showResend)} />
            <div>
              <label className="block text-sm text-gray-400 mb-1.5 font-medium">From Email Address</label>
              <input type="email" value={resendFrom} onChange={e => setResendFrom(e.target.value)} placeholder="noreply@yourdomain.com"
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500" />
              <p className="text-[10px] text-gray-600 mt-1">Must be a verified domain in Resend. Free accounts can use onboarding@resend.dev</p>
            </div>
            <button onClick={handleSaveResend} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm transition-colors flex items-center justify-center gap-2"><Mail className="w-4 h-4" />Save Email Configuration</button>
            <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
              <p className="text-xs text-emerald-300">💡 <strong>What this enables:</strong> When users click "Forgot Password" on the login page, a real password reset email will be sent to their inbox with a secure reset link.</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Notifications */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><Bell className="w-5 h-5 text-blue-400" /><h3 className="text-white font-semibold">Notifications</h3></div>
          <div className="space-y-3">{(Object.entries(notifications) as [string, boolean][]).map(([key, value]) => {
            const labels: Record<string, string> = { scrapeComplete: 'Scraping completed', hotLeadFound: 'Hot lead detected', emailFound: 'Email discovered', exportReady: 'Export ready' };
            return (<div key={key} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl"><span className="text-sm text-gray-300">{labels[key]}</span><button onClick={() => toggleNotification(key, value)} className={`relative w-11 h-6 rounded-full transition-colors ${value ? 'bg-blue-500' : 'bg-gray-700'}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${value ? 'translate-x-5' : 'translate-x-0.5'}`}></span></button></div>);
          })}</div>
        </div>

        {/* Scraper */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><Globe className="w-5 h-5 text-emerald-400" /><h3 className="text-white font-semibold">Scraper Defaults</h3></div>
          <div className="space-y-4">
            <div><label className="block text-sm text-gray-400 mb-1.5">Default Country</label><select className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300"><option>Australia</option><option>India</option><option>United States</option><option>United Kingdom</option><option>Canada</option></select></div>
            <div><label className="block text-sm text-gray-400 mb-1.5">Default Language</label><select className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300"><option>English</option><option>Hindi</option><option>Spanish</option></select></div>
          </div>
        </div>

        <SecurityBlock />

        {/* About */}
        <div className="bg-gradient-to-r from-blue-900/30 to-indigo-900/30 border border-blue-700/30 rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center"><Zap className="w-6 h-6 text-white" /></div>
            <div><div className="flex items-center gap-2"><span className="text-blue-400 font-black text-lg">MASTER</span><span className="text-red-400 font-black text-lg">EDGE</span></div><div className="text-gray-500 text-sm">Maps Scraper Pro AI v2.0</div></div>
            <div className="ml-auto text-right"><div className="text-xs text-gray-500">Status</div><div className="text-sm font-bold text-white">{apiKey ? '🟢 Live' : '🟡 Demo'}</div></div>
          </div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">{[
            { label: 'Scraper', value: apiKey ? '✅ API' : '⚠ Demo' },
            { label: 'Payments', value: hasOwnerKey('stripe_pk') ? '✅ Stripe' : '⚠ None' },
            { label: 'Google Auth', value: '✅ OAuth' },
            { label: 'Email', value: hasOwnerKey('resend_api_key') ? '✅ Resend' : '⚠ None' },
          ].map(i => (<div key={i.label} className="text-center p-2.5 bg-white/5 rounded-xl"><div className="text-white font-bold text-sm">{i.value}</div><div className="text-gray-600 text-xs">{i.label}</div></div>))}</div>
        </div>
      </div>
    </div>
  );
}
