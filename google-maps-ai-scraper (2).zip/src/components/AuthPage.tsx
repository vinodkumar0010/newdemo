import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  Globe,
  Brain,
  ArrowRight,
  AlertCircle,
  Sparkles,
  Users,
  BarChart3,
  Database,
  Shield,
} from 'lucide-react';

type Tab = 'login' | 'signup';

const features = [
  { icon: Globe,    label: 'Google Maps Scraper', desc: 'Infinite lead extraction' },
  { icon: Brain,    label: 'AI Email Finder',     desc: '98% accuracy validation' },
  { icon: BarChart3,label: 'Lead Scoring',        desc: 'Smart qualification engine' },
  { icon: Database, label: 'Google Sheets Sync',  desc: 'Real-time export to Sheets' },
  { icon: Users,    label: 'Team Workspace',      desc: 'Collaborate with your team' },
  { icon: Shield,   label: 'Email Validation',    desc: 'MX, spam, disposable checks' },
];

export default function AuthPage() {
  const { login, signup, loginWithGoogle, resetPassword, setNewPassword } = useAuth();
  const [tab, setTab] = useState<Tab>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);

  // Forgot password
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotMsg, setForgotMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Reset password (when user clicks link with ?reset_token=xxx)
  const [resetToken] = useState(() => new URLSearchParams(window.location.search).get('reset_token') || '');
  const [newPw, setNewPw] = useState('');
  const [newPwConfirm, setNewPwConfirm] = useState('');
  const [showNewPw, setShowNewPw] = useState(false);
  const [resetMsg, setResetMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleForgot = async () => {
    setForgotMsg(null);
    if (!forgotEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(forgotEmail)) { setForgotMsg({ type: 'error', text: 'Enter a valid email address' }); return; }
    setForgotLoading(true);
    const r = await resetPassword(forgotEmail);
    setForgotLoading(false);
    setForgotMsg({ type: r.success ? 'success' : 'error', text: r.message });
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault(); setResetMsg(null);
    if (!newPw || newPw.length < 8 || !/[A-Z]/.test(newPw) || !/[0-9]/.test(newPw)) { setResetMsg({ type: 'error', text: 'Password must be 8+ chars with uppercase & number' }); return; }
    if (newPw !== newPwConfirm) { setResetMsg({ type: 'error', text: 'Passwords do not match' }); return; }
    const r = setNewPassword(resetToken, newPw);
    setResetMsg({ type: r.success ? 'success' : 'error', text: r.message });
    if (r.success) { window.history.replaceState({}, '', window.location.pathname); }
  };

  const resetForm = () => { setEmail(''); setPassword(''); setName(''); setConfirmPassword(''); setError(''); setSuccess(''); };
  const switchTab = (t: Tab) => { setTab(t); resetForm(); };
  const validEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
  const validPass = (p: string) => p.length >= 8 && /[A-Z]/.test(p) && /[0-9]/.test(p);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setSuccess('');
    if (!email || !password) { setError('Please fill in all fields'); return; }
    if (!validEmail(email)) { setError('Please enter a valid email address'); return; }
    setLoading(true);
    const r = await login(email, password);
    setLoading(false);
    r.success ? setSuccess(r.message) : setError(r.message);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setSuccess('');
    if (!name || !email || !password || !confirmPassword) { setError('Please fill in all fields'); return; }
    if (!validEmail(email)) { setError('Please enter a valid email'); return; }
    if (!validPass(password)) { setError('Password must be 8+ chars with uppercase & number'); return; }
    if (password !== confirmPassword) { setError('Passwords do not match'); return; }
    if (!acceptTerms) { setError('Please accept the Terms & Privacy Policy'); return; }
    setLoading(true);
    const r = await signup(name, email, password);
    setLoading(false);
    r.success ? setSuccess(r.message) : setError(r.message);
  };

  const handleGoogleSignIn = async () => {
    setError(''); setSuccess('');
    setGoogleLoading(true);
    const r = await loginWithGoogle();
    setGoogleLoading(false);
    if (r.success) setSuccess(r.message);
    else setError(r.message);
  };

  return (
    <div className="min-h-screen bg-gray-950 flex">
      {/* Left Panel */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-blue-950 via-indigo-950 to-violet-950 p-12 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full filter blur-3xl opacity-20 animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-violet-500 rounded-full filter blur-3xl opacity-20 animate-pulse" style={{ animationDelay: '1s' }}></div>
        </div>
        <div className="relative z-10 flex flex-col justify-between w-full">
          <div className="flex items-center gap-3">
            <img src="/masteredge-logo.png" alt="Masteredge" className="w-12 h-12 rounded-xl object-contain bg-white p-1" />
            <div>
              <div className="flex items-center gap-1"><span className="text-blue-400 font-black text-2xl">MASTER</span><span className="text-red-400 font-black text-2xl">EDGE</span></div>
              <div className="text-gray-400 text-sm -mt-1">Technology</div>
            </div>
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/30 rounded-full mb-6">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" /><span className="text-xs text-blue-300 font-semibold">AI-Powered Lead Generation Platform</span>
            </div>
            <h1 className="text-5xl font-black text-white mb-4 leading-tight">Google Maps<br /><span className="bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">Lead Scraper Pro AI</span></h1>
            <p className="text-gray-400 text-lg max-w-md mb-8 leading-relaxed">The ultimate AI-powered lead generation platform for agencies. Scrape, enrich, score, and convert leads — all in one place.</p>
            <div className="grid grid-cols-2 gap-3">
              {features.map(f => { const I = f.icon; return (
                <div key={f.label} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10">
                  <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center flex-shrink-0"><I className="w-4 h-4 text-white" /></div>
                  <div className="min-w-0"><div className="text-white text-sm font-semibold truncate">{f.label}</div><div className="text-gray-500 text-xs truncate">{f.desc}</div></div>
                </div>
              ); })}
            </div>
          </div>
          <div className="text-gray-600 text-xs">© 2025 Masteredge Technology. All rights reserved.</div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12 overflow-y-auto">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-6">
            <img src="/masteredge-logo.png" alt="Masteredge" className="w-10 h-10 rounded-xl object-contain bg-white p-1" />
            <div className="flex items-center gap-1"><span className="text-blue-400 font-black text-xl">MASTER</span><span className="text-red-400 font-black text-xl">EDGE</span></div>
          </div>

          <div className="mb-6">
            <h2 className="text-3xl font-black text-white mb-2">{tab === 'login' ? 'Welcome back' : 'Create account'}</h2>
            <p className="text-gray-500">{tab === 'login' ? 'Sign in to access your lead generation dashboard' : 'Start generating AI-powered leads today'}</p>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-gray-900 border border-gray-800 rounded-xl mb-6">
            <button onClick={() => switchTab('login')} className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === 'login' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}>Sign In</button>
            <button onClick={() => switchTab('signup')} className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === 'signup' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}>Create Account</button>
          </div>

          {/* Alerts */}
          {error && <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-2 text-sm"><AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" /><span className="text-red-400">{error}</span></div>}
          {success && <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-sm"><CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" /><span className="text-emerald-400">{success}</span></div>}

          {/* ─── Google Sign-In ─── */}
          <button
            onClick={handleGoogleSignIn}
            disabled={googleLoading}
            className="w-full flex items-center justify-center gap-3 py-3 bg-white hover:bg-gray-100 disabled:opacity-50 text-gray-800 rounded-xl font-semibold text-sm transition-all mb-4 border border-gray-200"
          >
            {googleLoading ? (
              <span className="w-5 h-5 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></span>
            ) : (
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
            )}
            {googleLoading ? 'Signing in with Google…' : 'Continue with Google'}
          </button>

          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-gray-800"></div>
            <span className="text-xs text-gray-600">or</span>
            <div className="flex-1 h-px bg-gray-800"></div>
          </div>

          {/* ─── Login Form ─── */}
          {tab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1.5 font-medium">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" autoComplete="email"
                    className="w-full pl-10 pr-4 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm text-gray-400 font-medium">Password</label>
                  <button type="button" className="text-xs text-blue-400 hover:text-blue-300" onClick={() => { setShowForgot(true); setForgotEmail(email); setForgotMsg(null); }}>Forgot password?</button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password"
                    className="w-full pl-10 pr-10 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={rememberMe} onChange={e => setRememberMe(e.target.checked)} className="w-4 h-4 accent-blue-500" />
                <span className="text-sm text-gray-400">Remember me for 30 days</span>
              </label>
              <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:opacity-50 text-white rounded-xl font-semibold transition-all shadow-lg shadow-blue-900/30">
                {loading ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> Signing in…</> : <>Sign In <ArrowRight className="w-4 h-4" /></>}
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1.5 font-medium">Full Name</label>
                <div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="John Doe" autoComplete="name"
                    className="w-full pl-10 pr-4 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" /></div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5 font-medium">Email Address</label>
                <div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" autoComplete="email"
                    className="w-full pl-10 pr-4 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" /></div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5 font-medium">Password</label>
                <div className="relative"><Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="8+ chars, uppercase & number" autoComplete="new-password"
                    className="w-full pl-10 pr-10 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">{showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                </div>
                {password && <div className="flex gap-1 mt-2">{[password.length >= 8, /[A-Z]/.test(password), /[0-9]/.test(password)].map((ok, i) => <div key={i} className={`h-1 flex-1 rounded-full ${ok ? 'bg-emerald-400' : 'bg-gray-700'}`}></div>)}</div>}
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1.5 font-medium">Confirm Password</label>
                <div className="relative"><Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Re-enter your password" autoComplete="new-password"
                    className="w-full pl-10 pr-10 py-3 bg-gray-900 border border-gray-800 rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20" />
                  {confirmPassword && <div className="absolute right-3 top-1/2 -translate-y-1/2">{password === confirmPassword ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-red-400" />}</div>}
                </div>
              </div>
              <label className="flex items-start gap-2 cursor-pointer">
                <input type="checkbox" checked={acceptTerms} onChange={e => setAcceptTerms(e.target.checked)} className="w-4 h-4 accent-blue-500 mt-0.5" />
                <span className="text-sm text-gray-400 leading-tight">I agree to the <span className="text-blue-400">Terms of Service</span> and <span className="text-blue-400">Privacy Policy</span></span>
              </label>
              <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-50 text-white rounded-xl font-semibold transition-all shadow-lg shadow-violet-900/30">
                {loading ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> Creating account…</> : <>Create Account <ArrowRight className="w-4 h-4" /></>}
              </button>
            </form>
          )}

          <div className="mt-6 text-center text-xs text-gray-600">Secured with industry-standard encryption. Your data is safe.</div>
        </div>
      </div>

      {/* ══════ FORGOT PASSWORD MODAL ══════ */}
      {showForgot && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowForgot(false)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center"><Mail className="w-5 h-5 text-blue-400" /></div>
              <div><h3 className="text-white font-bold text-lg">Reset Password</h3><p className="text-gray-500 text-xs">We'll send a reset link to your email</p></div>
            </div>

            {forgotMsg && (
              <div className={`mb-4 p-3 rounded-xl flex items-center gap-2 text-sm ${forgotMsg.type === 'success' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border border-red-500/30 text-red-400'}`}>
                {forgotMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
                {forgotMsg.text}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input type="email" value={forgotEmail} onChange={e => setForgotEmail(e.target.value)} placeholder="Enter your registered email"
                    className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" autoFocus />
                </div>
              </div>
              <button onClick={handleForgot} disabled={forgotLoading} className="w-full flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-semibold text-sm transition-colors">
                {forgotLoading ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> Sending…</> : <>Send Reset Link <ArrowRight className="w-4 h-4" /></>}
              </button>
              <button onClick={() => setShowForgot(false)} className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors">← Back to Login</button>
            </div>
          </div>
        </div>
      )}

      {/* ══════ RESET PASSWORD FORM (when ?reset_token=xxx in URL) ══════ */}
      {resetToken && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><Lock className="w-5 h-5 text-emerald-400" /></div>
              <div><h3 className="text-white font-bold text-lg">Set New Password</h3><p className="text-gray-500 text-xs">Create a new secure password</p></div>
            </div>

            {resetMsg && (
              <div className={`mb-4 p-3 rounded-xl flex items-center gap-2 text-sm ${resetMsg.type === 'success' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border border-red-500/30 text-red-400'}`}>
                {resetMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
                {resetMsg.text}
              </div>
            )}

            {resetMsg?.type !== 'success' ? (
              <form onSubmit={handleResetSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5">New Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input type={showNewPw ? 'text' : 'password'} value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="8+ chars, uppercase & number"
                      className="w-full pl-10 pr-10 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-emerald-500" />
                    <button type="button" onClick={() => setShowNewPw(!showNewPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">{showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                  </div>
                  {newPw && <div className="flex gap-1 mt-2">{[newPw.length >= 8, /[A-Z]/.test(newPw), /[0-9]/.test(newPw)].map((ok, i) => <div key={i} className={`h-1 flex-1 rounded-full ${ok ? 'bg-emerald-400' : 'bg-gray-700'}`}></div>)}</div>}
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5">Confirm New Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input type="password" value={newPwConfirm} onChange={e => setNewPwConfirm(e.target.value)} placeholder="Re-enter new password"
                      className="w-full pl-10 pr-10 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-emerald-500" />
                    {newPwConfirm && <div className="absolute right-3 top-1/2 -translate-y-1/2">{newPw === newPwConfirm ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-red-400" />}</div>}
                  </div>
                </div>
                <button type="submit" className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-sm transition-colors">Update Password</button>
              </form>
            ) : (
              <a href={window.location.pathname} className="block w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm text-center transition-colors">← Go to Login</a>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
