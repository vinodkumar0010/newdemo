import { useMemo } from 'react';
import { MapPin, Mail, Globe, Flame, Star, MessageSquare, TrendingUp, ArrowUpRight, Zap, Target, Activity } from 'lucide-react';
import { NavSection } from '../types';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import { useLeadCount } from '../context/LeadContext';
import UsageBar from './UsageBar';

const quickActions: { label: string; icon: typeof Zap; color: string; desc: string; nav: NavSection }[] = [
  { label: 'Start Scraping', icon: Zap, color: 'bg-blue-600 hover:bg-blue-500', desc: 'Google Maps', nav: 'scraper' },
  { label: 'Find Emails', icon: Mail, color: 'bg-violet-600 hover:bg-violet-500', desc: 'AI discovery', nav: 'ai-analysis' },
  { label: 'Score Leads', icon: Target, color: 'bg-red-600 hover:bg-red-500', desc: 'AI engine', nav: 'leads' },
  { label: 'Outreach', icon: MessageSquare, color: 'bg-emerald-600 hover:bg-emerald-500', desc: 'Messages', nav: 'outreach' },
];

const tooltipStyle = { backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '12px', color: '#f9fafb' };

export default function Dashboard({ onNavigate }: { onNavigate?: (s: NavSection) => void }) {
  const { leads, count } = useLeadCount();

  const stats = useMemo(() => {
    const emails = leads.filter(l => l.email).length;
    const websites = leads.filter(l => l.website).length;
    const hot = leads.filter(l => l.leadCategory === 'hot').length;
    const avgRating = leads.length > 0 ? (leads.reduce((a, l) => a + (l.rating || 0), 0) / leads.length).toFixed(1) : '0';
    const avgReviews = leads.length > 0 ? Math.round(leads.reduce((a, l) => a + (l.reviews || 0), 0) / leads.length) : 0;
    return [
      { label: 'Total Leads', value: String(count), change: `${count}`, icon: MapPin, bg: 'bg-blue-500/10', border: 'border-blue-500/20', iconColor: 'text-blue-400' },
      { label: 'Emails Found', value: String(emails), change: `${leads.length > 0 ? Math.round(emails / leads.length * 100) : 0}%`, icon: Mail, bg: 'bg-violet-500/10', border: 'border-violet-500/20', iconColor: 'text-violet-400' },
      { label: 'Websites', value: String(websites), change: `${leads.length > 0 ? Math.round(websites / leads.length * 100) : 0}%`, icon: Globe, bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', iconColor: 'text-emerald-400' },
      { label: 'Hot Leads', value: String(hot), change: `${leads.length > 0 ? Math.round(hot / leads.length * 100) : 0}%`, icon: Flame, bg: 'bg-red-500/10', border: 'border-red-500/20', iconColor: 'text-red-400' },
      { label: 'Avg Rating', value: avgRating, change: '★', icon: Star, bg: 'bg-amber-500/10', border: 'border-amber-500/20', iconColor: 'text-amber-400' },
      { label: 'Avg Reviews', value: String(avgReviews), change: 'per biz', icon: MessageSquare, bg: 'bg-pink-500/10', border: 'border-pink-500/20', iconColor: 'text-pink-400' },
    ];
  }, [leads, count]);

  const byCity = useMemo(() => {
    const m: Record<string, number> = {};
    leads.forEach(l => { const c = l.city || 'Unknown'; m[c] = (m[c] || 0) + 1; });
    return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([city, cnt]) => ({ city, leads: cnt }));
  }, [leads]);

  const qualityPie = useMemo(() => [
    { name: 'Hot', value: leads.filter(l => l.leadCategory === 'hot').length, color: '#ef4444' },
    { name: 'Warm', value: leads.filter(l => l.leadCategory === 'warm').length, color: '#f97316' },
    { name: 'Cold', value: leads.filter(l => l.leadCategory === 'cold').length, color: '#3b82f6' },
  ], [leads]);

  const hotLeads = useMemo(() => leads.filter(l => l.leadCategory === 'hot').sort((a, b) => b.leadScore - a.leadScore).slice(0, 5), [leads]);

  const recentActivity = useMemo(() => {
    return [...leads].sort((a, b) => new Date(b.scrapedAt).getTime() - new Date(a.scrapedAt).getTime()).slice(0, 5).map(l => ({
      action: l.email ? 'Email found' : l.website ? 'Website scraped' : 'Lead scraped',
      detail: `${l.businessName} — ${l.city}`,
      time: new Date(l.scrapedAt).toLocaleTimeString(),
      type: l.email ? 'email' : l.leadCategory === 'hot' ? 'lead' : 'scrape',
    }));
  }, [leads]);

  return (
    <div className="p-6 space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 border border-blue-700/50 p-6">
        <div className="relative flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-green-500/20 border border-green-500/40 rounded-full text-green-400 text-xs font-semibold"><span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>{count > 0 ? `${count} Leads` : 'Ready'}</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">Google Maps Lead Scraper Pro AI</h2>
            <p className="text-blue-200 text-sm">Scrape → Enrich → Score → Outreach → Export</p>
          </div>
          <div className="hidden lg:flex items-center gap-3">
            <div className="text-center px-4 py-3 bg-white/10 rounded-xl border border-white/20"><div className="text-2xl font-black text-white">{count}</div><div className="text-xs text-blue-300">Leads</div></div>
            <div className="text-center px-4 py-3 bg-white/10 rounded-xl border border-white/20"><div className="text-2xl font-black text-white">{leads.filter(l => l.email).length}</div><div className="text-xs text-blue-300">Emails</div></div>
            <div className="text-center px-4 py-3 bg-white/10 rounded-xl border border-white/20"><div className="text-2xl font-black text-white">{leads.filter(l => l.leadCategory === 'hot').length}</div><div className="text-xs text-blue-300">Hot</div></div>
          </div>
        </div>
      </div>

      {/* Usage Bar */}
      <UsageBar variant="full" />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map(s => { const I = s.icon; return (
          <div key={s.label} className={`relative overflow-hidden rounded-xl p-4 ${s.bg} border ${s.border} group hover:scale-105 transition-transform duration-200`}>
            <div className="flex items-start justify-between mb-3"><I className={`w-5 h-5 ${s.iconColor}`} /><span className="flex items-center gap-0.5 text-xs font-semibold text-emerald-400"><ArrowUpRight className="w-3 h-3" />{s.change}</span></div>
            <div className="text-2xl font-black text-white mb-0.5">{s.value}</div>
            <div className="text-xs text-gray-400">{s.label}</div>
          </div>
        ); })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4"><div><h3 className="text-white font-semibold">Leads by City</h3><p className="text-gray-500 text-sm">From scraped data</p></div></div>
          {byCity.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={byCity} barSize={28}><CartesianGrid strokeDasharray="3 3" stroke="#1f2937" /><XAxis dataKey="city" stroke="#4b5563" tick={{ fill: '#9ca3af', fontSize: 11 }} /><YAxis stroke="#4b5563" tick={{ fill: '#9ca3af', fontSize: 11 }} /><Tooltip contentStyle={tooltipStyle} /><Bar dataKey="leads" fill="#3b82f6" radius={[6, 6, 0, 0]} /></BarChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-12 text-gray-600">Scrape leads to see city distribution</div>}
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="mb-4"><h3 className="text-white font-semibold">Lead Quality</h3></div>
          {count > 0 ? (<>
            <ResponsiveContainer width="100%" height={140}><PieChart><Pie data={qualityPie} cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={4} dataKey="value">{qualityPie.map((e, i) => <Cell key={i} fill={e.color} />)}</Pie><Tooltip contentStyle={tooltipStyle} /></PieChart></ResponsiveContainer>
            <div className="space-y-2 mt-2">{qualityPie.map(i => <div key={i.name} className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i.color }}></span><span className="text-sm text-gray-400">{i.name}</span></div><span className="text-sm font-semibold text-white">{i.value}</span></div>)}</div>
          </>) : <div className="text-center py-12 text-gray-600">No data yet</div>}
        </div>
      </div>

      {/* Bottom */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Hot Leads */}
        <div className="xl:col-span-2 bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4"><div><h3 className="text-white font-semibold">Top Hot Leads</h3><p className="text-gray-500 text-sm">Highest scoring prospects</p></div><TrendingUp className="w-4 h-4 text-red-400" /></div>
          {hotLeads.length > 0 ? (
            <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-gray-500 text-xs uppercase tracking-wide border-b border-gray-800"><th className="pb-3 pr-4">Business</th><th className="pb-3 pr-4">City</th><th className="pb-3 pr-4">Score</th><th className="pb-3 pr-4">Rating</th><th className="pb-3 pr-4">Opportunity</th><th className="pb-3">Email</th></tr></thead>
              <tbody>{hotLeads.map(l => (
                <tr key={l.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                  <td className="py-3 pr-4"><div className="font-medium text-white">{l.businessName}</div><div className="text-xs text-gray-500">{l.category}</div></td>
                  <td className="py-3 pr-4 text-gray-400">{l.city}</td>
                  <td className="py-3 pr-4"><div className="flex items-center gap-2"><div className="w-16 h-1.5 bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-red-500 to-orange-500 rounded-full" style={{ width: `${l.leadScore}%` }}></div></div><span className="font-bold text-red-400">{l.leadScore}</span></div></td>
                  <td className="py-3 pr-4"><div className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-400 fill-amber-400" /><span className="text-gray-300">{l.rating}</span><span className="text-gray-600 text-xs">({l.reviews})</span></div></td>
                  <td className="py-3 pr-4"><div className="flex flex-wrap gap-1">{(l.opportunities || []).slice(0, 2).map(o => <span key={o} className="text-[10px] px-1.5 py-0.5 bg-blue-500/10 text-blue-400 rounded-md border border-blue-500/20">{o}</span>)}</div></td>
                  <td className="py-3">{l.email ? <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20 font-semibold">✓ {l.email}</span> : <span className="text-[10px] px-2 py-0.5 bg-gray-700 text-gray-500 rounded-full font-semibold">None</span>}</td>
                </tr>
              ))}</tbody>
            </table></div>
          ) : <div className="text-center py-8 text-gray-600">No hot leads yet — scrape to find them</div>}
        </div>

        {/* Activity + Quick Actions */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4"><h3 className="text-white font-semibold">Recent Activity</h3><Activity className="w-4 h-4 text-gray-500" /></div>
          <div className="space-y-3 mb-4">
            {recentActivity.length > 0 ? recentActivity.map((a, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${a.type === 'email' ? 'bg-violet-500' : a.type === 'lead' ? 'bg-red-500' : 'bg-blue-500'}`}></div>
                <div className="flex-1 min-w-0"><div className="text-sm font-medium text-white truncate">{a.action}</div><div className="text-xs text-gray-500 truncate">{a.detail}</div></div>
                <div className="text-xs text-gray-600 flex-shrink-0">{a.time}</div>
              </div>
            )) : <div className="text-center py-4 text-gray-600 text-sm">No activity — start scraping!</div>}
          </div>
          <div className="pt-4 border-t border-gray-800">
            <p className="text-xs text-gray-500 mb-3 font-semibold uppercase tracking-wide">Quick Actions</p>
            <div className="grid grid-cols-2 gap-2">
              {quickActions.map(a => { const I = a.icon; return (
                <button key={a.label} onClick={() => onNavigate?.(a.nav)} className={`flex flex-col items-center gap-1.5 p-2.5 rounded-xl text-white transition-colors ${a.color}`}>
                  <I className="w-4 h-4" /><span className="text-[10px] font-semibold leading-tight text-center">{a.label}</span>
                </button>
              ); })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
