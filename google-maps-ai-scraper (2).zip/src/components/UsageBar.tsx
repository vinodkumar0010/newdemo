import { useLeadCount } from '../context/LeadContext';
import { useAuth } from '../context/AuthContext';
import { getLeadLimit, PlanId } from '../lib/planGate';
import { Zap } from 'lucide-react';

interface Props {
  variant?: 'full' | 'compact' | 'mini';
}

export default function UsageBar({ variant = 'full' }: Props) {
  const { todayScrapedCount } = useLeadCount();
  const { user } = useAuth();
  const plan = (user?.plan || 'free') as PlanId;
  const limit = getLeadLimit(plan);
  const isUnlimited = limit > 99999;
  const used = todayScrapedCount;
  const pct = isUnlimited ? Math.min(used / 500 * 100, 100) : Math.min((used / limit) * 100, 100);
  const remaining = isUnlimited ? '∞' : String(Math.max(0, limit - used));
  const overLimit = !isUnlimited && used >= limit;

  const barColor = overLimit ? 'bg-red-500' : pct > 75 ? 'bg-amber-500' : 'bg-emerald-500';
  const textColor = overLimit ? 'text-red-400' : pct > 75 ? 'text-amber-400' : 'text-emerald-400';

  if (variant === 'mini') {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-gray-800/80 border border-gray-700 rounded-xl" title={`${used}/${isUnlimited ? '∞' : limit} leads scraped today`}>
        <Zap className={`w-3.5 h-3.5 ${textColor}`} />
        <span className={`text-xs font-bold ${textColor}`}>{used}</span>
        <span className="text-[10px] text-gray-600">/ {isUnlimited ? '∞' : limit}</span>
        <div className="w-10 h-1.5 bg-gray-700 rounded-full overflow-hidden">
          <div className={`h-full ${barColor} rounded-full transition-all`} style={{ width: `${pct}%` }}></div>
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className="p-3 bg-gray-800/50 border border-gray-700 rounded-xl">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-gray-400 font-medium">Today's Usage</span>
          <span className={`text-xs font-bold ${textColor}`}>{used} / {isUnlimited ? '∞' : limit}</span>
        </div>
        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
          <div className={`h-full ${barColor} rounded-full transition-all`} style={{ width: `${pct}%` }}></div>
        </div>
        {overLimit && <p className="text-[10px] text-red-400 mt-1">Daily limit reached — upgrade your plan for more</p>}
      </div>
    );
  }

  // full variant
  return (
    <div className="p-4 bg-gray-900 border border-gray-800 rounded-2xl">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Zap className={`w-5 h-5 ${textColor}`} />
          <div>
            <h3 className="text-white font-semibold text-sm">Daily Scraping Limit</h3>
            <p className="text-gray-500 text-xs capitalize">{plan} Plan — {isUnlimited ? 'Unlimited' : `${limit} leads/day`}</p>
          </div>
        </div>
        <div className="text-right">
          <div className={`text-2xl font-black ${textColor}`}>{used}</div>
          <div className="text-xs text-gray-500">of {isUnlimited ? '∞' : limit} today</div>
        </div>
      </div>
      <div className="h-3 bg-gray-800 rounded-full overflow-hidden mb-2">
        <div className={`h-full ${barColor} rounded-full transition-all`} style={{ width: `${pct}%` }}></div>
      </div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-gray-500">{remaining} remaining</span>
        {overLimit ? (
          <span className="text-red-400 font-semibold">⚠ Limit reached — upgrade to continue</span>
        ) : pct > 75 && !isUnlimited ? (
          <span className="text-amber-400">Almost at limit</span>
        ) : (
          <span className="text-gray-600">Resets at midnight</span>
        )}
      </div>
    </div>
  );
}
