import { useState, useMemo } from 'react';
import {
  Filter, Download, Search, Star, Globe, Phone, Mail, Flame, ChevronRight,
  SlidersHorizontal, CheckCircle2, XCircle, AlertCircle, ExternalLink,
  Trash2, CheckSquare, Square, X, Copy, Send, FileText,
} from 'lucide-react';
import { Lead } from '../types';
import { useToast } from '../context/ToastContext';
import { useLeadCount } from '../context/LeadContext';
import { notifyExportReady } from '../lib/notify';

const filterOptions = [
  { id: 'all', label: 'All Leads' },
  { id: 'hot', label: '🔥 Hot' },
  { id: 'warm', label: '🟠 Warm' },
  { id: 'cold', label: '🔵 Cold' },
  { id: 'hasEmail', label: '✉️ Has Email' },
  { id: 'noWebsite', label: '🚫 No Website' },
  { id: 'hasWebsite', label: '🌐 Has Website' },
  { id: 'highRating', label: '⭐ Rating > 4' },
  { id: 'hasFacebook', label: '📘 Has Facebook' },
  { id: 'hasInstagram', label: '📷 Has Instagram' },
  { id: 'hasLinkedin', label: '💼 Has LinkedIn' },
];

/* ── helper funcs ── */
function getEmailStatusStyle(s?: string) {
  return s === 'verified' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : s === 'valid' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : s === 'risky' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-gray-700 text-gray-500 border-gray-600';
}
function getEmailStatusIcon(s?: string) {
  return s === 'verified' || s === 'valid' ? <CheckCircle2 className="w-3 h-3" /> : s === 'risky' ? <AlertCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />;
}
function ScoreBar({ score, category }: { score: number; category: Lead['leadCategory'] }) {
  const c = category === 'hot' ? 'from-red-500 to-orange-500' : category === 'warm' ? 'from-orange-500 to-amber-500' : 'from-blue-500 to-cyan-500';
  return <div className="flex items-center gap-2"><div className="w-16 h-1.5 bg-gray-700 rounded-full overflow-hidden"><div className={`h-full bg-gradient-to-r ${c} rounded-full`} style={{ width: `${score}%` }}></div></div><span className={`text-sm font-bold ${category === 'hot' ? 'text-red-400' : category === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>{score}</span></div>;
}
function socialUrl(p: string, h: string) { if (!h) return '#'; if (h.startsWith('http')) return h; const m: Record<string,string> = { facebook: `https://facebook.com/${h}`, instagram: `https://instagram.com/${h}`, linkedin: `https://linkedin.com/company/${h}`, youtube: `https://youtube.com/@${h}`, twitter: `https://x.com/${h}`, whatsapp: `https://wa.me/${h.replace(/[^0-9]/g,'')}` }; return m[p] || '#'; }
function linkedinPersonUrl(h: string) { if (!h) return '#'; return h.startsWith('http') ? h : `https://${h}`; }
const platformMeta: Record<string,{label:string;icon:string;color:string}> = { facebook:{label:'Facebook',icon:'f',color:'text-blue-400 hover:text-blue-300'}, instagram:{label:'Instagram',icon:'ig',color:'text-pink-400 hover:text-pink-300'}, linkedin:{label:'LinkedIn',icon:'in',color:'text-sky-400 hover:text-sky-300'}, youtube:{label:'YouTube',icon:'yt',color:'text-red-400 hover:text-red-300'}, twitter:{label:'X/Twitter',icon:'𝕏',color:'text-gray-300 hover:text-white'}, whatsapp:{label:'WhatsApp',icon:'wa',color:'text-emerald-400 hover:text-emerald-300'} };

/* ── Generate email from lead analysis ── */
function generateServiceEmail(lead: Lead): { subject: string; body: string } {
  const name = lead.decisionMaker?.name?.split(' ')[0] || 'there';
  const services: string[] = [];
  const opps = lead.opportunities || [];

  // Build service recommendations from real analysis data
  if (opps.includes('Website Redesign') || !lead.website) services.push(`• **Website Design/Redesign** — ${!lead.website ? 'Your business currently has no website. A professional website could increase your customer enquiries by 60%+.' : `Your current website (${lead.website}) scored ${lead.websiteScore || 0}/100 in our analysis. A modern redesign could significantly improve conversions.`}`);
  if (opps.includes('SEO Services') || (lead.seoIssues && lead.seoIssues.length > 2)) services.push(`• **SEO Optimization** — We found ${lead.seoIssues?.length || 0} SEO issues including ${(lead.seoIssues || []).slice(0, 2).join(', ') || 'missing meta tags'}. Fixing these could boost your Google ranking dramatically.`);
  if (opps.includes('Google Ads')) services.push(`• **Google Ads Management** — With ${lead.reviews || 0} reviews and ${lead.rating || 0}★ rating, targeted Google Ads could bring you ${Math.max(20, Math.floor((lead.reviews || 10) * 0.3))}+ new leads per month.`);
  if (opps.includes('AI Chatbot')) services.push(`• **AI Chatbot / Live Chat** — An AI-powered chatbot on your website could capture leads 24/7 and increase conversions by 35%.`);
  if (opps.includes('Social Media Marketing')) services.push(`• **Social Media Marketing** — ${Object.values(lead.socialMedia || {}).filter(Boolean).length === 0 ? 'Your business has no social media presence. Setting up and managing social profiles could expand your reach significantly.' : 'Boosting your social media presence with targeted content could drive more foot traffic and online enquiries.'}`);
  if (opps.includes('AI Receptionist')) services.push(`• **AI Receptionist** — An AI phone receptionist could handle missed calls and book appointments automatically, reducing lost leads.`);
  if (services.length === 0) services.push(`• **Digital Marketing Audit** — We've prepared a comprehensive analysis of your online presence with specific recommendations.`);

  const subject = `Free Audit Report for ${lead.businessName} — Opportunities Found`;
  const body = `Hi ${name},

I was researching ${lead.category?.toLowerCase() || 'local'} businesses in ${lead.city} and came across ${lead.businessName}${lead.reviews ? ` — ${lead.reviews} reviews with ${lead.rating}★ is impressive!` : '.'}

After analyzing your online presence, I identified several opportunities that could help grow your business:

${services.join('\n\n')}

${lead.seoIssues && lead.seoIssues.length > 0 ? `\nQuick SEO Findings:\n${lead.seoIssues.map(i => `  ⚠ ${i}`).join('\n')}\n` : ''}
${lead.websiteScore ? `Website Health Score: ${lead.websiteScore}/100` : ''}
Lead Quality Score: ${lead.leadScore}/100 (${lead.leadCategory === 'hot' ? 'High Priority' : lead.leadCategory === 'warm' ? 'Medium Priority' : 'Standard'})

I've prepared a detailed audit report specifically for ${lead.businessName}. Would you be open to a quick 15-minute call this week to go over the findings?

No pressure, no obligation — just actionable insights.

Best regards,
[Your Name]
[Your Company]
[Your Phone]
[Your Website]

P.S. This audit is completely free. I genuinely think these changes could make a real difference for your business.`;

  return { subject, body };
}

/* ── Generate full audit report HTML ── */
function generateAuditReportHTML(lead: Lead): string {
  const socials = Object.entries(lead.socialMedia || {}).filter(([, v]) => v);
  const seoIssues = lead.seoIssues || [];
  const opps = lead.opportunities || [];
  const scoreColor = lead.leadScore >= 75 ? '#ef4444' : lead.leadScore >= 50 ? '#f97316' : '#3b82f6';
  const wsColor = (lead.websiteScore || 0) >= 70 ? '#10b981' : (lead.websiteScore || 0) >= 40 ? '#f59e0b' : '#ef4444';

  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Audit Report — ${lead.businessName}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0f172a;color:#e2e8f0;padding:40px 20px}
.container{max-width:800px;margin:0 auto;background:#1e293b;border-radius:16px;overflow:hidden;border:1px solid #334155}
.header{background:linear-gradient(135deg,#1e3a5f,#312e81);padding:32px;text-align:center}
.header h1{font-size:28px;font-weight:800;color:#fff;margin-bottom:4px}
.header p{color:#93c5fd;font-size:14px}
.badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;margin-top:12px}
.section{padding:24px 32px;border-bottom:1px solid #334155}
.section h2{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.card{background:#0f172a;border:1px solid #334155;border-radius:12px;padding:16px;text-align:center}
.card .value{font-size:28px;font-weight:900;margin-bottom:2px}
.card .label{font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px}
.issue{display:flex;align-items:center;gap:8px;padding:10px 14px;background:#0f172a;border-radius:8px;margin-bottom:6px;font-size:13px;border-left:3px solid #f59e0b}
.opp{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#0f172a;border-radius:10px;margin-bottom:8px;border:1px solid #334155}
.opp .name{font-weight:600;color:#fff;font-size:14px}
.opp .conf{font-size:22px;font-weight:900}
.pass{color:#10b981}.fail{color:#ef4444}.warn{color:#f59e0b}
table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:10px 12px;text-align:left;border-bottom:1px solid #1e293b}
th{color:#94a3b8;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;background:#0f172a}
.footer{padding:24px 32px;text-align:center;color:#64748b;font-size:12px}
@media print{body{background:#fff;color:#1e293b;padding:0}.container{border:none;box-shadow:none}.header{background:linear-gradient(135deg,#2563eb,#7c3aed)}.section,.card,.issue,.opp{background:#f8fafc;border-color:#e2e8f0}.footer{color:#94a3b8}}
</style></head><body>
<div class="container">
<div class="header">
<h1>🔍 Business Audit Report</h1>
<p>Prepared for ${lead.businessName}</p>
<div class="badge" style="background:${scoreColor}22;color:${scoreColor};border:1px solid ${scoreColor}44">Lead Score: ${lead.leadScore}/100 — ${lead.leadCategory === 'hot' ? '🔥 HOT LEAD' : lead.leadCategory === 'warm' ? '🟠 WARM LEAD' : '🔵 COLD LEAD'}</div>
</div>

<div class="section">
<h2>📋 Business Information</h2>
<table><tbody>
<tr><td style="color:#94a3b8;width:160px">Business Name</td><td style="color:#fff;font-weight:600">${lead.businessName}</td></tr>
<tr><td style="color:#94a3b8">Category</td><td>${lead.category || '—'}</td></tr>
<tr><td style="color:#94a3b8">Address</td><td>${lead.address || '—'}, ${lead.city}, ${lead.state}</td></tr>
<tr><td style="color:#94a3b8">Phone</td><td>${lead.phone || 'Not found'}</td></tr>
<tr><td style="color:#94a3b8">Email</td><td style="color:${lead.email ? '#10b981' : '#ef4444'}">${lead.email || 'Not found'}${lead.emailConfidence ? ` (${lead.emailConfidence}% confidence)` : ''}</td></tr>
<tr><td style="color:#94a3b8">Website</td><td style="color:#60a5fa">${lead.website || 'No website found'}</td></tr>
<tr><td style="color:#94a3b8">Google Maps</td><td><a href="${lead.googleMapsUrl}" style="color:#60a5fa">${lead.googleMapsUrl}</a></td></tr>
${lead.decisionMaker ? `<tr><td style="color:#94a3b8">Decision Maker</td><td style="color:#fff;font-weight:600">${lead.decisionMaker.name} — ${lead.decisionMaker.position}</td></tr>` : ''}
</tbody></table>
</div>

<div class="section">
<h2>📊 Key Metrics</h2>
<div class="grid">
<div class="card"><div class="value" style="color:${scoreColor}">${lead.leadScore}</div><div class="label">Lead Score</div></div>
<div class="card"><div class="value" style="color:#fbbf24">★ ${lead.rating || 0}</div><div class="label">Google Rating</div></div>
<div class="card"><div class="value" style="color:#fff">${lead.reviews || 0}</div><div class="label">Total Reviews</div></div>
<div class="card"><div class="value" style="color:${wsColor}">${lead.websiteScore || 0}</div><div class="label">Website Score</div></div>
</div>
</div>

${lead.website ? `<div class="section">
<h2>🌐 Website Analysis</h2>
<p style="margin-bottom:12px;font-size:13px;color:#94a3b8">Website: <span style="color:#60a5fa">${lead.website}</span> — Score: <span style="color:${wsColor};font-weight:700">${lead.websiteScore || 0}/100</span></p>
<table><thead><tr><th>Check</th><th>Status</th></tr></thead><tbody>
${[
  { name: 'Has Website', pass: true },
  { name: 'Has Contact Email', pass: !!lead.email },
  { name: 'Has Phone Number', pass: !!lead.phone },
  { name: 'Rating ≥ 4.0', pass: (lead.rating || 0) >= 4 },
  { name: 'Reviews > 50', pass: (lead.reviews || 0) > 50 },
  { name: 'Social Media Present', pass: socials.length > 0 },
  { name: 'Decision Maker Found', pass: !!lead.decisionMaker },
  { name: 'SEO Score ≥ 50', pass: (lead.websiteScore || 0) >= 50 },
].map(c => `<tr><td>${c.name}</td><td class="${c.pass ? 'pass' : 'fail'}" style="font-weight:600">${c.pass ? '✓ Pass' : '✗ Fail'}</td></tr>`).join('')}
</tbody></table>
</div>` : `<div class="section"><h2>🌐 Website Analysis</h2><p style="color:#ef4444;font-weight:600;font-size:15px">⚠ No website found — this is a major opportunity for website design services.</p></div>`}

${seoIssues.length > 0 ? `<div class="section">
<h2>⚠️ SEO Issues Found (${seoIssues.length})</h2>
${seoIssues.map(i => `<div class="issue">⚠ ${i}</div>`).join('')}
</div>` : ''}

<div class="section">
<h2>🎯 Service Opportunities (${opps.length})</h2>
${opps.length > 0 ? opps.map(o => `<div class="opp"><div><div class="name">${o}</div><div style="font-size:11px;color:#94a3b8;margin-top:2px">${o === 'Website Redesign' ? 'Business needs a modern website' : o === 'SEO Services' ? 'Multiple SEO improvements needed' : o === 'Google Ads' ? 'Paid advertising would boost visibility' : o === 'AI Chatbot' ? 'No live chat detected on website' : o === 'Social Media Marketing' ? 'Weak or no social presence' : 'Growth opportunity detected'}</div></div><div class="conf" style="color:#10b981">${o === 'Website Redesign' ? '94' : o === 'SEO Services' ? '87' : o === 'Google Ads' ? '79' : o === 'AI Chatbot' ? '82' : '85'}%</div></div>`).join('') : '<p style="color:#94a3b8">No major opportunities detected — this lead is well-optimized.</p>'}
</div>

${socials.length > 0 ? `<div class="section">
<h2>📱 Social Media (${socials.length} found)</h2>
<table><thead><tr><th>Platform</th><th>Handle</th></tr></thead><tbody>
${socials.map(([k, v]) => `<tr><td style="text-transform:capitalize">${k}</td><td style="color:#60a5fa">${v}</td></tr>`).join('')}
</tbody></table>
</div>` : `<div class="section"><h2>📱 Social Media</h2><p style="color:#f59e0b">No social media profiles found — opportunity for social media marketing.</p></div>`}

${lead.reviewSentiment ? `<div class="section"><h2>💬 Review Analysis</h2><p style="font-size:14px;line-height:1.6">${lead.reviewSentiment}</p></div>` : ''}

<div class="section">
<h2>📌 Recommended Action Plan</h2>
<table><thead><tr><th>#</th><th>Action</th><th>Priority</th></tr></thead><tbody>
${[
  ...(!lead.website ? [{ a: 'Build a professional website', p: '🔴 Critical' }] : []),
  ...(seoIssues.length > 0 ? [{ a: `Fix ${seoIssues.length} SEO issues`, p: '🟠 High' }] : []),
  ...(!lead.email ? [{ a: 'Set up business email', p: '🟠 High' }] : []),
  ...(socials.length === 0 ? [{ a: 'Create social media profiles', p: '🟡 Medium' }] : []),
  ...((lead.rating || 0) < 4 ? [{ a: 'Improve customer reviews', p: '🟡 Medium' }] : []),
  { a: 'Set up Google Analytics tracking', p: '🟢 Recommended' },
  { a: 'Implement AI chatbot for lead capture', p: '🟢 Recommended' },
].map((r, i) => `<tr><td style="font-weight:600;color:#fff">${i + 1}</td><td>${r.a}</td><td>${r.p}</td></tr>`).join('')}
</tbody></table>
</div>

<div class="footer">
<p>Generated by <strong>Google Maps Lead Scraper Pro AI</strong> — Masteredge Technology</p>
<p style="margin-top:4px">Report Date: ${new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
</div>
</div></body></html>`;
}

/* ════════════════════════════════════════════ */
export default function LeadManager() {
  const { showToast } = useToast();
  const { leads, deleteLead, deleteLeads } = useLeadCount();
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
  const [expandedLead, setExpandedLead] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);

  // ── Email modal state
  const [emailModalLead, setEmailModalLead] = useState<Lead | null>(null);
  const [emailBody, setEmailBody] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailTo, setEmailTo] = useState('');
  const [emailCopied, setEmailCopied] = useState(false);

  // ── Audit modal state
  const [auditModalLead, setAuditModalLead] = useState<Lead | null>(null);

  // ── Advanced Filter state
  const [showAdvFilter, setShowAdvFilter] = useState(false);
  const [advMinRating, setAdvMinRating] = useState(0);
  const [advMaxRating, setAdvMaxRating] = useState(5);
  const [advMinReviews, setAdvMinReviews] = useState(0);
  const [advMinScore, setAdvMinScore] = useState(0);
  const [advCity, setAdvCity] = useState('');
  const [advHasEmail, setAdvHasEmail] = useState(false);
  const [advHasPhone, setAdvHasPhone] = useState(false);
  const [advHasWebsite, setAdvHasWebsite] = useState(false);
  const [advNoWebsite, setAdvNoWebsite] = useState(false);
  const [advFiltersActive, setAdvFiltersActive] = useState(false);

  const filteredLeads = useMemo(() => leads.filter(lead => {
    const q = searchQuery.toLowerCase();
    const ms = lead.businessName.toLowerCase().includes(q) || lead.city.toLowerCase().includes(q) || lead.category.toLowerCase().includes(q);
    // Quick filters
    switch (activeFilter) {
      case 'hot': if (lead.leadCategory !== 'hot') return false; break;
      case 'warm': if (lead.leadCategory !== 'warm') return false; break;
      case 'cold': if (lead.leadCategory !== 'cold') return false; break;
      case 'hasEmail': if (!lead.email) return false; break;
      case 'noWebsite': if (lead.website) return false; break;
      case 'hasWebsite': if (!lead.website) return false; break;
      case 'highRating': if (lead.rating <= 4) return false; break;
      case 'hasFacebook': if (!lead.socialMedia.facebook) return false; break;
      case 'hasInstagram': if (!lead.socialMedia.instagram) return false; break;
      case 'hasLinkedin': if (!lead.socialMedia.linkedin) return false; break;
    }
    if (!ms) return false;
    // Advanced filters
    if (advFiltersActive) {
      if (lead.rating < advMinRating || lead.rating > advMaxRating) return false;
      if (lead.reviews < advMinReviews) return false;
      if (lead.leadScore < advMinScore) return false;
      if (advCity && !lead.city.toLowerCase().includes(advCity.toLowerCase())) return false;
      if (advHasEmail && !lead.email) return false;
      if (advHasPhone && !lead.phone) return false;
      if (advHasWebsite && !lead.website) return false;
      if (advNoWebsite && lead.website) return false;
    }
    return true;
  }), [leads, activeFilter, searchQuery, advFiltersActive, advMinRating, advMaxRating, advMinReviews, advMinScore, advCity, advHasEmail, advHasPhone, advHasWebsite, advNoWebsite]);

  const toggleSelect = (id: string) => setSelectedLeads(p => p.includes(id) ? p.filter(l => l !== id) : [...p, id]);
  const allVisibleSelected = filteredLeads.length > 0 && filteredLeads.every(l => selectedLeads.includes(l.id));
  const toggleSelectAll = () => { if (allVisibleSelected) setSelectedLeads(p => p.filter(id => !filteredLeads.some(l => l.id === id))); else { const ids = filteredLeads.map(l => l.id); setSelectedLeads(p => [...new Set([...p, ...ids])]); } };
  const deleteSingle = (id: string) => { const l = leads.find(x => x.id === id); deleteLead(id); setSelectedLeads(p => p.filter(s => s !== id)); setExpandedLead(null); setShowDeleteConfirm(null); showToast('success', 'Lead deleted', l?.businessName || ''); };
  const deleteSelected = () => { const c = selectedLeads.length; deleteLeads(selectedLeads); setSelectedLeads([]); setExpandedLead(null); setShowBulkDeleteConfirm(false); showToast('success', `${c} leads deleted`, ''); };
  const csvEsc = (v: string) => `"${String(v || '').replace(/"/g, '""')}"`;
  const handleExport = () => {
    const el = selectedLeads.length > 0 ? leads.filter(l => selectedLeads.includes(l.id)) : filteredLeads;
    const h = ['Business Name','Category','City','Phone','Email','Website','Rating','Reviews','Score','Lead Type'].map(csvEsc).join(',');
    const r = el.map(l => [l.businessName,l.category,l.city,l.phone||'',l.email||'',l.website||'',l.rating,l.reviews,l.leadScore,l.leadCategory].map(v => csvEsc(String(v))).join(','));
    const csv = '\uFEFF' + [h,...r].join('\n'); // BOM for Excel UTF-8
    const b = new Blob([csv],{type:'text/csv;charset=utf-8'}); const u = URL.createObjectURL(b);
    const a = document.createElement('a'); a.href=u; a.download=`leads-${Date.now()}.csv`; a.click(); URL.revokeObjectURL(u);
    showToast('success','CSV exported',`${el.length} leads`);
    notifyExportReady(el.length, 'CSV');
  };

  // ── Open Email Modal
  const openEmailModal = (lead: Lead) => {
    const { subject, body } = generateServiceEmail(lead);
    setEmailSubject(subject);
    setEmailBody(body);
    setEmailTo(lead.email || '');
    setEmailModalLead(lead);
    setEmailCopied(false);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(`Subject: ${emailSubject}\n\n${emailBody}`);
    setEmailCopied(true);
    showToast('success', 'Email copied!', 'Paste into your email client');
    setTimeout(() => setEmailCopied(false), 2000);
  };

  const handleSendEmail = () => {
    const to = emailTo || emailModalLead?.email || '';
    const mailto = `mailto:${to}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    window.open(mailto, '_blank');
    showToast('success', 'Email client opened!', `Sending to ${to || 'recipient'}`);
  };

  // ── Open Audit Modal & Download
  const openAuditModal = (lead: Lead) => setAuditModalLead(lead);

  const downloadAuditReport = () => {
    if (!auditModalLead) return;
    const html = generateAuditReportHTML(auditModalLead);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-report-${auditModalLead.businessName.replace(/[^a-zA-Z0-9]/g, '-')}.html`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('success', 'Audit report downloaded!', `${auditModalLead.businessName}.html`);
  };

  return (
    <div className="p-6 space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3">
        <button onClick={toggleSelectAll} className="flex items-center gap-1.5 text-gray-400 hover:text-white transition-colors" title={allVisibleSelected ? 'Deselect all' : 'Select all'}>{allVisibleSelected ? <CheckSquare className="w-5 h-5 text-blue-400" /> : <Square className="w-5 h-5" />}</button>
        <div className="relative flex-1 min-w-48"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" /><input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search leads by name, city, category…" className="w-full pl-9 pr-4 py-2.5 bg-gray-900 border border-gray-800 rounded-xl text-sm text-gray-300 placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30" /></div>
        {selectedLeads.length > 0 && <button onClick={() => setShowBulkDeleteConfirm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-sm font-semibold transition-colors"><Trash2 className="w-4 h-4" />Delete ({selectedLeads.length})</button>}
        <button onClick={() => setShowAdvFilter(true)} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-colors ${advFiltersActive ? 'bg-violet-600 text-white' : 'bg-gray-900 border border-gray-800 text-gray-400 hover:border-gray-600'}`}><SlidersHorizontal className="w-4 h-4" />Advanced Filter{advFiltersActive ? ' ✓' : ''}</button>
        <button onClick={handleExport} className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors"><Download className="w-4 h-4" />Export {selectedLeads.length > 0 ? `(${selectedLeads.length})` : 'All'}</button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">{filterOptions.map(f => <button key={f.id} onClick={() => setActiveFilter(f.id)} className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${activeFilter === f.id ? 'bg-blue-600 text-white' : 'bg-gray-900 border border-gray-800 text-gray-400 hover:border-gray-600 hover:text-gray-300'}`}>{f.label}</button>)}<div className="ml-auto text-sm text-gray-500 flex items-center gap-2">{filteredLeads.length} leads{selectedLeads.length > 0 && <span className="text-blue-400 text-xs">· {selectedLeads.length} selected</span>}</div></div>

      {/* ── Bulk Delete Confirm ── */}
      {showBulkDeleteConfirm && <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowBulkDeleteConfirm(false)}><div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}><div className="flex items-center gap-3 mb-4"><div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center"><Trash2 className="w-5 h-5 text-red-400" /></div><div><h3 className="text-white font-semibold">Delete {selectedLeads.length} leads?</h3><p className="text-sm text-gray-500">This cannot be undone.</p></div></div><div className="flex gap-2 justify-end"><button onClick={() => setShowBulkDeleteConfirm(false)} className="px-4 py-2 bg-gray-800 text-gray-300 rounded-xl text-sm font-semibold">Cancel</button><button onClick={deleteSelected} className="px-4 py-2 bg-red-600 text-white rounded-xl text-sm font-semibold">Delete All</button></div></div></div>}

      {/* ── Single Delete Confirm ── */}
      {showDeleteConfirm && <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowDeleteConfirm(null)}><div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}><div className="flex items-center gap-3 mb-4"><div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center"><Trash2 className="w-5 h-5 text-red-400" /></div><div><h3 className="text-white font-semibold">Delete this lead?</h3><p className="text-sm text-gray-500">{leads.find(l => l.id === showDeleteConfirm)?.businessName}</p></div></div><div className="flex gap-2 justify-end"><button onClick={() => setShowDeleteConfirm(null)} className="px-4 py-2 bg-gray-800 text-gray-300 rounded-xl text-sm font-semibold">Cancel</button><button onClick={() => deleteSingle(showDeleteConfirm)} className="px-4 py-2 bg-red-600 text-white rounded-xl text-sm font-semibold">Delete</button></div></div></div>}

      {/* ══════════ EMAIL MODAL ══════════ */}
      {emailModalLead && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setEmailModalLead(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl max-w-2xl w-full shadow-2xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center"><Mail className="w-5 h-5 text-blue-400" /></div>
                <div><h3 className="text-white font-bold">Generated Email — {emailModalLead.businessName}</h3><p className="text-gray-500 text-xs">Personalized based on lead analysis</p></div>
              </div>
              <button onClick={() => setEmailModalLead(null)} className="text-gray-500 hover:text-white p-1"><X className="w-5 h-5" /></button>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* To Field */}
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">To:</label>
                <input type="email" value={emailTo} onChange={e => setEmailTo(e.target.value)} placeholder="recipient@email.com"
                  className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" />
                {!emailTo && <p className="text-xs text-amber-400 mt-1">⚠ No email found for this lead. Enter manually or copy the template.</p>}
              </div>
              {/* Subject */}
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Subject:</label>
                <input type="text" value={emailSubject} onChange={e => setEmailSubject(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" />
              </div>
              {/* Body */}
              <div>
                <label className="block text-sm text-gray-400 mb-1.5">Email Body:</label>
                <textarea value={emailBody} onChange={e => setEmailBody(e.target.value)} rows={16}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-gray-300 text-sm leading-relaxed focus:outline-none focus:border-blue-500 resize-y" />
              </div>
              {/* Services detected badge */}
              <div className="p-3 bg-violet-500/5 border border-violet-500/20 rounded-xl">
                <div className="text-xs text-violet-400 font-semibold mb-1.5">🎯 Services recommended based on analysis:</div>
                <div className="flex flex-wrap gap-1.5">{(emailModalLead.opportunities || []).map(o => <span key={o} className="text-[10px] px-2 py-0.5 bg-violet-500/10 text-violet-300 rounded-md border border-violet-500/20">{o}</span>)}</div>
              </div>
            </div>
            {/* Footer / Actions */}
            <div className="p-5 border-t border-gray-800 flex flex-wrap gap-2">
              <button onClick={handleSendEmail} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold transition-colors"><Send className="w-4 h-4" />Send Email</button>
              <button onClick={handleCopyEmail} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${emailCopied ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'}`}>{emailCopied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}{emailCopied ? 'Copied!' : 'Copy All'}</button>
              <button onClick={() => setEmailModalLead(null)} className="px-4 py-2.5 bg-gray-800 text-gray-400 hover:bg-gray-700 rounded-xl text-sm font-semibold ml-auto">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* ══════════ AUDIT REPORT MODAL ══════════ */}
      {auditModalLead && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setAuditModalLead(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl max-w-2xl w-full shadow-2xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><FileText className="w-5 h-5 text-emerald-400" /></div>
                <div><h3 className="text-white font-bold">Audit Report — {auditModalLead.businessName}</h3><p className="text-gray-500 text-xs">Complete business analysis</p></div>
              </div>
              <button onClick={() => setAuditModalLead(null)} className="text-gray-500 hover:text-white p-1"><X className="w-5 h-5" /></button>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* Score Cards */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3 bg-gray-800 rounded-xl text-center"><div className={`text-2xl font-black ${auditModalLead.leadCategory === 'hot' ? 'text-red-400' : auditModalLead.leadCategory === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>{auditModalLead.leadScore}</div><div className="text-[10px] text-gray-500 uppercase">Lead Score</div></div>
                <div className="p-3 bg-gray-800 rounded-xl text-center"><div className="text-2xl font-black text-amber-400">★{auditModalLead.rating || 0}</div><div className="text-[10px] text-gray-500 uppercase">Rating</div></div>
                <div className="p-3 bg-gray-800 rounded-xl text-center"><div className="text-2xl font-black text-white">{auditModalLead.reviews || 0}</div><div className="text-[10px] text-gray-500 uppercase">Reviews</div></div>
                <div className="p-3 bg-gray-800 rounded-xl text-center"><div className={`text-2xl font-black ${(auditModalLead.websiteScore||0) >= 50 ? 'text-emerald-400' : 'text-red-400'}`}>{auditModalLead.websiteScore || 0}</div><div className="text-[10px] text-gray-500 uppercase">Web Score</div></div>
              </div>
              {/* Business Info */}
              <div className="p-4 bg-gray-800 rounded-xl space-y-2 text-sm">
                <div className="text-xs text-gray-500 uppercase font-semibold mb-2">Business Information</div>
                {[
                  ['Business', auditModalLead.businessName, 'text-white font-semibold'],
                  ['Category', auditModalLead.category],
                  ['Address', `${auditModalLead.address}, ${auditModalLead.city}, ${auditModalLead.state}`],
                  ['Phone', auditModalLead.phone || 'Not found'],
                  ['Email', auditModalLead.email || 'Not found', auditModalLead.email ? 'text-emerald-400' : 'text-red-400'],
                  ['Website', auditModalLead.website || 'No website', auditModalLead.website ? 'text-blue-400' : 'text-red-400'],
                  ...(auditModalLead.decisionMaker ? [['Decision Maker', `${auditModalLead.decisionMaker.name} — ${auditModalLead.decisionMaker.position}`, 'text-white font-semibold']] : []),
                ].map(([label, val, cls]) => <div key={label as string} className="flex justify-between"><span className="text-gray-500">{label}</span><span className={`${cls || 'text-gray-300'} truncate ml-4 max-w-xs text-right`}>{val}</span></div>)}
              </div>
              {/* SEO Issues */}
              {(auditModalLead.seoIssues || []).length > 0 && (
                <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                  <div className="text-xs text-amber-400 uppercase font-semibold mb-2">⚠ SEO Issues ({auditModalLead.seoIssues!.length})</div>
                  <div className="space-y-1.5">{auditModalLead.seoIssues!.map(i => <div key={i} className="flex items-center gap-2 text-sm text-amber-300"><AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{i}</div>)}</div>
                </div>
              )}
              {/* Opportunities */}
              <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl">
                <div className="text-xs text-blue-400 uppercase font-semibold mb-2">🎯 Service Opportunities ({(auditModalLead.opportunities||[]).length})</div>
                {(auditModalLead.opportunities||[]).length > 0 ? (
                  <div className="space-y-2">{(auditModalLead.opportunities||[]).map(o => (
                    <div key={o} className="flex items-center justify-between p-2.5 bg-gray-800 rounded-lg"><span className="text-sm text-white font-medium">{o}</span><span className="text-xs text-emerald-400 font-bold">{o === 'Website Redesign' ? '94' : o === 'SEO Services' ? '87' : o === 'Google Ads' ? '79' : o === 'AI Chatbot' ? '82' : '85'}% match</span></div>
                  ))}</div>
                ) : <p className="text-sm text-gray-500">No major opportunities — well-optimized lead.</p>}
              </div>
              {/* Social Media */}
              <div className="p-4 bg-gray-800 rounded-xl">
                <div className="text-xs text-gray-500 uppercase font-semibold mb-2">📱 Social Media</div>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(platformMeta).map(([key, meta]) => {
                    const val = (auditModalLead.socialMedia || {})[key as keyof typeof auditModalLead.socialMedia];
                    return <div key={key} className={`p-2 rounded-lg text-xs ${val ? 'bg-emerald-500/5 border border-emerald-500/20 text-emerald-400' : 'bg-gray-900 text-gray-600'}`}><span className="font-bold mr-1">{meta.icon}</span>{val || 'Not found'}</div>;
                  })}
                </div>
              </div>
              {/* Review Sentiment */}
              {auditModalLead.reviewSentiment && <div className="p-4 bg-violet-500/5 border border-violet-500/20 rounded-xl"><div className="text-xs text-violet-400 uppercase font-semibold mb-1">💬 AI Review Analysis</div><p className="text-sm text-gray-300">{auditModalLead.reviewSentiment}</p></div>}
            </div>
            {/* Footer */}
            <div className="p-5 border-t border-gray-800 flex flex-wrap gap-2">
              <button onClick={downloadAuditReport} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold transition-colors"><Download className="w-4 h-4" />Download Report (.html)</button>
              <button onClick={() => { openEmailModal(auditModalLead); setAuditModalLead(null); }} className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors"><Mail className="w-4 h-4" />Send as Email</button>
              <button onClick={() => setAuditModalLead(null)} className="px-4 py-2.5 bg-gray-800 text-gray-400 hover:bg-gray-700 rounded-xl text-sm font-semibold ml-auto">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* ══════ ADVANCED FILTER MODAL ══════ */}
      {showAdvFilter && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowAdvFilter(false)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl max-w-lg w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center"><SlidersHorizontal className="w-5 h-5 text-violet-400" /></div><div><h3 className="text-white font-bold">Advanced Filter</h3><p className="text-gray-500 text-xs">Narrow down your leads</p></div></div>
              <button onClick={() => setShowAdvFilter(false)} className="text-gray-500 hover:text-white p-1"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto">
              {/* Rating Range */}
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-sm text-gray-400 mb-1.5">Min Rating</label><input type="number" min={0} max={5} step={0.1} value={advMinRating} onChange={e => setAdvMinRating(Number(e.target.value))} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" /></div>
                <div><label className="block text-sm text-gray-400 mb-1.5">Max Rating</label><input type="number" min={0} max={5} step={0.1} value={advMaxRating} onChange={e => setAdvMaxRating(Number(e.target.value))} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" /></div>
              </div>
              {/* Min Reviews & Score */}
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-sm text-gray-400 mb-1.5">Min Reviews</label><input type="number" min={0} value={advMinReviews} onChange={e => setAdvMinReviews(Number(e.target.value))} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" /></div>
                <div><label className="block text-sm text-gray-400 mb-1.5">Min Lead Score</label><input type="number" min={0} max={100} value={advMinScore} onChange={e => setAdvMinScore(Number(e.target.value))} className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" /></div>
              </div>
              {/* City */}
              <div><label className="block text-sm text-gray-400 mb-1.5">City Contains</label><input type="text" value={advCity} onChange={e => setAdvCity(e.target.value)} placeholder="e.g. Mumbai, Sydney…" className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500" /></div>
              {/* Toggles */}
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Has Email', val: advHasEmail, set: setAdvHasEmail },
                  { label: 'Has Phone', val: advHasPhone, set: setAdvHasPhone },
                  { label: 'Has Website', val: advHasWebsite, set: setAdvHasWebsite },
                  { label: 'No Website', val: advNoWebsite, set: setAdvNoWebsite },
                ].map(t => (
                  <button key={t.label} onClick={() => t.set(!t.val)} className={`p-2.5 rounded-xl text-sm font-semibold transition-all ${t.val ? 'bg-violet-600 text-white' : 'bg-gray-800 border border-gray-700 text-gray-400 hover:border-gray-500'}`}>{t.val ? '✓ ' : ''}{t.label}</button>
                ))}
              </div>
            </div>
            <div className="p-5 border-t border-gray-800 flex gap-2">
              <button onClick={() => { setAdvFiltersActive(true); setShowAdvFilter(false); showToast('success', 'Advanced filter applied', `${filteredLeads.length} leads match`); }} className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-500 text-white rounded-xl font-bold text-sm">Apply Filters</button>
              <button onClick={() => { setAdvFiltersActive(false); setAdvMinRating(0); setAdvMaxRating(5); setAdvMinReviews(0); setAdvMinScore(0); setAdvCity(''); setAdvHasEmail(false); setAdvHasPhone(false); setAdvHasWebsite(false); setAdvNoWebsite(false); setShowAdvFilter(false); showToast('info', 'Filters cleared', ''); }} className="px-4 py-2.5 bg-gray-800 text-gray-300 rounded-xl font-semibold text-sm">Clear All</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Empty state ── */}
      {filteredLeads.length === 0 && <div className="text-center py-16 bg-gray-900 border border-gray-800 rounded-2xl"><Search className="w-10 h-10 text-gray-700 mx-auto mb-3" /><h3 className="text-white font-semibold mb-1">{leads.length === 0 ? 'No leads scraped yet' : 'No leads match your filter'}</h3><p className="text-gray-500 text-sm">{leads.length === 0 ? 'Go to Scraper Engine → enter a search like "Dentist Sydney" → click Start Scraping' : 'Try adjusting your search or filter criteria'}</p></div>}

      {/* ── Lead Cards ── */}
      <div className="space-y-3">
        {filteredLeads.map(lead => (
          <div key={lead.id} className={`bg-gray-900 border rounded-2xl overflow-hidden transition-all ${selectedLeads.includes(lead.id) ? 'border-blue-500/50 ring-1 ring-blue-500/20' : 'border-gray-800 hover:border-gray-700'}`}>
            {/* Row */}
            <div className="flex items-center gap-4 p-4">
              <input type="checkbox" checked={selectedLeads.includes(lead.id)} onChange={() => toggleSelect(lead.id)} className="w-4 h-4 accent-blue-500 flex-shrink-0 cursor-pointer" />
              <div className={`flex-shrink-0 w-12 h-12 rounded-xl flex flex-col items-center justify-center ${lead.leadCategory === 'hot' ? 'bg-red-500/10 border border-red-500/30' : lead.leadCategory === 'warm' ? 'bg-orange-500/10 border border-orange-500/30' : 'bg-blue-500/10 border border-blue-500/30'}`}><span className={`text-lg font-black leading-none ${lead.leadCategory === 'hot' ? 'text-red-400' : lead.leadCategory === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>{lead.leadScore}</span><span className="text-[9px] text-gray-500 uppercase font-bold">score</span></div>
              <div className="flex-1 min-w-0"><div className="flex items-center gap-2 mb-0.5"><span className="font-semibold text-white truncate">{lead.businessName}</span>{lead.leadCategory === 'hot' && <Flame className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />}<span className="text-xs text-gray-600 flex-shrink-0 px-1.5 py-0.5 bg-gray-800 rounded-md">{lead.category}</span></div><div className="flex items-center gap-3 text-xs text-gray-500"><span>{lead.city}, {lead.state}</span><span className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-400 fill-amber-400" />{lead.rating} ({lead.reviews} reviews)</span></div></div>
              <div className="hidden md:flex flex-col gap-1 flex-shrink-0 min-w-0 w-48">
                {lead.phone && <a href={`tel:${lead.phone}`} className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white truncate"><Phone className="w-3 h-3 text-gray-600 flex-shrink-0" />{lead.phone}</a>}
                {lead.email ? <a href={`mailto:${lead.email}`} className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 truncate"><Mail className="w-3 h-3 flex-shrink-0" />{lead.email}</a> : <div className="text-xs text-gray-600">No email</div>}
                {lead.website ? <a href={`https://${lead.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 truncate"><Globe className="w-3 h-3 flex-shrink-0" />{lead.website}<ExternalLink className="w-2.5 h-2.5 opacity-60" /></a> : <div className="text-xs text-amber-500">No website</div>}
              </div>
              <div className="hidden lg:flex flex-col items-center gap-1 flex-shrink-0"><span className={`flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getEmailStatusStyle(lead.emailStatus)}`}>{getEmailStatusIcon(lead.emailStatus)}{lead.emailStatus || 'Unknown'}</span>{lead.emailConfidence !== undefined && lead.emailConfidence > 0 && <span className="text-[10px] text-gray-600">{lead.emailConfidence}%</span>}</div>
              <div className="hidden xl:block flex-shrink-0"><ScoreBar score={lead.leadScore} category={lead.leadCategory} /></div>
              <div className="hidden xl:flex flex-wrap gap-1 w-48 flex-shrink-0">{(lead.opportunities||[]).slice(0, 2).map(o => <span key={o} className="text-[10px] px-1.5 py-0.5 bg-violet-500/10 text-violet-400 border border-violet-500/20 rounded-md">{o}</span>)}{(lead.opportunities||[]).length > 2 && <span className="text-[10px] px-1.5 py-0.5 bg-gray-800 text-gray-500 rounded-md">+{lead.opportunities.length - 2}</span>}</div>
              <button onClick={() => setShowDeleteConfirm(lead.id)} className="flex-shrink-0 p-1.5 rounded-lg hover:bg-red-500/10 text-gray-600 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
              <button onClick={() => setExpandedLead(expandedLead === lead.id ? null : lead.id)} className="flex-shrink-0 p-1.5 rounded-lg hover:bg-gray-800 transition-colors"><ChevronRight className={`w-4 h-4 text-gray-500 transition-transform ${expandedLead === lead.id ? 'rotate-90' : ''}`} /></button>
            </div>
            {/* Expanded */}
            {expandedLead === lead.id && (
              <div className="border-t border-gray-800 p-4 bg-gray-900/50 grid grid-cols-1 md:grid-cols-3 gap-4">
                {lead.decisionMaker && <div className="p-3 bg-gray-800 rounded-xl"><div className="text-xs text-gray-500 uppercase font-semibold mb-2">Decision Maker</div><div className="font-medium text-white text-sm">{lead.decisionMaker.name}</div><div className="text-xs text-gray-400 mb-2">{lead.decisionMaker.position}</div>{lead.decisionMaker.linkedin && <a href={linkedinPersonUrl(lead.decisionMaker.linkedin)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 bg-sky-500/10 px-2 py-1 rounded-lg border border-sky-500/20"><span className="font-bold text-[10px]">in</span>View LinkedIn<ExternalLink className="w-2.5 h-2.5" /></a>}</div>}
                <div className="p-3 bg-gray-800 rounded-xl"><div className="text-xs text-gray-500 uppercase font-semibold mb-2">Social Media</div><div className="space-y-1.5">{Object.entries(platformMeta).map(([key, meta]) => { const handle = (lead.socialMedia || {})[key as keyof typeof lead.socialMedia] || ''; return <div key={key}>{handle ? <a href={socialUrl(key, handle)} target="_blank" rel="noopener noreferrer" className={`flex items-center gap-2 text-xs ${meta.color}`}><span className="font-bold w-5 text-center">{meta.icon}</span>{handle}<ExternalLink className="w-2.5 h-2.5 opacity-60" /></a> : <div className="flex items-center gap-2 text-xs text-gray-600"><span className="font-bold w-5 text-center">{meta.icon}</span>Not found</div>}</div>; })}</div></div>
                <div className="p-3 bg-gray-800 rounded-xl"><div className="text-xs text-gray-500 uppercase font-semibold mb-2">SEO Issues</div>{lead.seoIssues && lead.seoIssues.length > 0 ? <div className="space-y-1">{lead.seoIssues.map(i => <div key={i} className="flex items-center gap-1.5 text-xs text-amber-400"><AlertCircle className="w-3 h-3 flex-shrink-0" />{i}</div>)}</div> : <div className="flex items-center gap-1.5 text-xs text-emerald-400"><CheckCircle2 className="w-3 h-3" />No issues found</div>}</div>
                {lead.reviewSentiment && <div className="md:col-span-3 p-3 bg-gray-800 rounded-xl"><div className="text-xs text-gray-500 uppercase font-semibold mb-1">AI Review Analysis</div><p className="text-sm text-gray-300">{lead.reviewSentiment}</p></div>}
                {/* ── ACTION BUTTONS ── */}
                <div className="md:col-span-3 flex flex-wrap gap-2">
                  <button onClick={() => openEmailModal(lead)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors"><Mail className="w-3.5 h-3.5" />Generate Email</button>
                  <button onClick={() => openAuditModal(lead)} className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors"><Filter className="w-3.5 h-3.5" />Full Audit Report</button>
                  {lead.decisionMaker?.linkedin && <a href={linkedinPersonUrl(lead.decisionMaker.linkedin)} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold transition-colors"><ExternalLink className="w-3.5 h-3.5" />Open LinkedIn</a>}
                  <a href={lead.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-xs font-semibold transition-colors"><ExternalLink className="w-3.5 h-3.5" />View on Maps</a>
                  <button onClick={() => setShowDeleteConfirm(lead.id)} className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600/10 border border-red-600/30 hover:bg-red-600/20 text-red-400 rounded-lg text-xs font-semibold transition-colors ml-auto"><Trash2 className="w-3.5 h-3.5" />Delete</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
