import { useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, Radar,
} from 'recharts';
import { TrendingUp, MapPin, Tag, BarChart3 } from 'lucide-react';
import { useLeadCount } from '../context/LeadContext';

export default function Analytics() {
  const { leads } = useLeadCount();

  const stats = useMemo(() => {
    const withEmail = leads.filter(l => l.email);
    const withWebsite = leads.filter(l => l.website);
    const hot = leads.filter(l => l.leadCategory === 'hot');
    const avgScore = leads.length > 0 ? (leads.reduce((a, l) => a + l.leadScore, 0) / leads.length).toFixed(1) : '0';
    const emailRate = leads.length > 0 ? Math.round((withEmail.length / leads.length) * 100) : 0;
    const hotRate = leads.length > 0 ? ((hot.length / leads.length) * 100).toFixed(1) : '0';
    return { total: leads.length, emails: withEmail.length, websites: withWebsite.length, hot: hot.length, avgScore, emailRate, hotRate };
  }, [leads]);

  const byCity = useMemo(() => {
    const map: Record<string, number> = {};
    leads.forEach(l => { const c = l.city || 'Unknown'; map[c] = (map[c] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([city, count]) => ({ city, leads: count }));
  }, [leads]);

  const byCategory = useMemo(() => {
    const map: Record<string, { count: number; totalScore: number }> = {};
    leads.forEach(l => { const c = l.category || 'Other'; if (!map[c]) map[c] = { count: 0, totalScore: 0 }; map[c].count++; map[c].totalScore += l.leadScore; });
    return Object.entries(map).sort((a, b) => b[1].count - a[1].count).slice(0, 8).map(([industry, { count, totalScore }]) => ({ industry, leads: count, score: Math.round(totalScore / count) }));
  }, [leads]);

  const qualityPie = useMemo(() => {
    const hot = leads.filter(l => l.leadCategory === 'hot').length;
    const warm = leads.filter(l => l.leadCategory === 'warm').length;
    const cold = leads.filter(l => l.leadCategory === 'cold').length;
    return [
      { name: 'Hot', value: hot, color: '#ef4444' },
      { name: 'Warm', value: warm, color: '#f97316' },
      { name: 'Cold', value: cold, color: '#3b82f6' },
    ];
  }, [leads]);

  const radar = useMemo(() => {
    if (leads.length === 0) return [];
    const withEmail = leads.filter(l => l.email).length;
    const withWebsite = leads.filter(l => l.website).length;
    const withSocials = leads.filter(l => Object.values(l.socialMedia || {}).filter(Boolean).length > 0).length;
    const avgRating = leads.reduce((a, l) => a + (l.rating || 0), 0) / leads.length;
    return [
      { subject: 'Volume', A: Math.min(100, leads.length * 5) },
      { subject: 'Emails', A: Math.round((withEmail / leads.length) * 100) },
      { subject: 'Websites', A: Math.round((withWebsite / leads.length) * 100) },
      { subject: 'Socials', A: Math.round((withSocials / leads.length) * 100) },
      { subject: 'Avg Rating', A: Math.round(avgRating * 20) },
      { subject: 'Avg Score', A: Math.round(leads.reduce((a, l) => a + l.leadScore, 0) / leads.length) },
    ];
  }, [leads]);

  const tooltipStyle = { backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '12px', color: '#f9fafb' };

  if (leads.length === 0) return (
    <div className="p-6"><div className="text-center py-20 bg-gray-900 border border-gray-800 rounded-2xl">
      <BarChart3 className="w-12 h-12 text-gray-700 mx-auto mb-3" />
      <h3 className="text-white font-semibold mb-1">No analytics data yet</h3>
      <p className="text-gray-500 text-sm">Scrape leads to see real-time analytics, charts, and insights</p>
    </div></div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Scraped', value: String(stats.total), sub: 'leads in database', color: 'text-blue-400' },
          { label: 'Email Hit Rate', value: `${stats.emailRate}%`, sub: `${stats.emails} emails found`, color: 'text-violet-400' },
          { label: 'Avg Lead Score', value: stats.avgScore, sub: 'out of 100', color: 'text-amber-400' },
          { label: 'Hot Lead Rate', value: `${stats.hotRate}%`, sub: `${stats.hot} hot leads`, color: 'text-red-400' },
        ].map(s => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-2xl p-4">
            <div className={`text-3xl font-black mb-1 ${s.color}`}>{s.value}</div>
            <div className="text-sm text-white font-semibold">{s.label}</div>
            <div className="text-xs text-gray-500">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* By City */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><MapPin className="w-4 h-4 text-emerald-400" /><h3 className="text-white font-semibold">Leads by City</h3></div>
          {byCity.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={byCity} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
                <XAxis dataKey="city" stroke="#4b5563" tick={{ fill: '#9ca3af', fontSize: 11 }} />
                <YAxis stroke="#4b5563" tick={{ fill: '#9ca3af', fontSize: 11 }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="leads" radius={[6, 6, 0, 0]}>{byCity.map((_, i) => <Cell key={i} fill={`hsl(${210 + i * 20}, 80%, 60%)`} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-8 text-gray-600">No city data</div>}
        </div>

        {/* Quality Pie */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><Tag className="w-4 h-4 text-violet-400" /><h3 className="text-white font-semibold">Lead Quality Breakdown</h3></div>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width="50%" height={200}>
              <PieChart><Pie data={qualityPie} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">{qualityPie.map((e, i) => <Cell key={i} fill={e.color} />)}</Pie><Tooltip contentStyle={tooltipStyle} /></PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-3">
              {qualityPie.map(item => (
                <div key={item.name}><div className="flex items-center justify-between mb-1"><div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></span><span className="text-sm text-gray-400">{item.name}</span></div><span className="text-sm font-bold text-white">{item.value}</span></div>
                  <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden"><div className="h-full rounded-full" style={{ backgroundColor: item.color, width: `${leads.length > 0 ? (item.value / leads.length) * 100 : 0}%` }}></div></div>
                </div>
              ))}
              <div className="pt-2 border-t border-gray-800"><div className="text-xs text-gray-500">Total: <span className="text-white font-bold">{leads.length} leads</span></div></div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Industry Table */}
        <div className="xl:col-span-2 bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><TrendingUp className="w-4 h-4 text-blue-400" /><h3 className="text-white font-semibold">Performance by Category</h3></div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-gray-500 text-xs uppercase tracking-wide border-b border-gray-800"><th className="text-left pb-3 pr-4">Category</th><th className="text-left pb-3 pr-4">Leads</th><th className="text-left pb-3 pr-4">Avg Score</th><th className="text-left pb-3">Quality</th></tr></thead>
              <tbody>
                {byCategory.map(r => (
                  <tr key={r.industry} className="border-b border-gray-800/50">
                    <td className="py-3 pr-4 text-white font-medium">{r.industry}</td>
                    <td className="py-3 pr-4 text-gray-400">{r.leads}</td>
                    <td className="py-3 pr-4"><span className={`font-bold ${r.score >= 75 ? 'text-red-400' : r.score >= 50 ? 'text-amber-400' : 'text-blue-400'}`}>{r.score}</span></td>
                    <td className="py-3"><div className="flex items-center gap-2"><div className="w-24 h-2 bg-gray-800 rounded-full overflow-hidden"><div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500" style={{ width: `${r.score}%` }}></div></div><span className="text-xs text-gray-500">{r.score}%</span></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Radar */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-4">Data Quality Radar</h3>
          {radar.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radar}><PolarGrid stroke="#1f2937" /><PolarAngleAxis dataKey="subject" tick={{ fill: '#9ca3af', fontSize: 11 }} /><Radar dataKey="A" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} strokeWidth={2} /><Tooltip contentStyle={tooltipStyle} /></RadarChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-8 text-gray-600">No data</div>}
        </div>
      </div>
    </div>
  );
}
