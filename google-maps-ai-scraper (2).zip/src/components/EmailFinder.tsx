import { useState } from 'react';
import {
  Mail,
  Search,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Shield,
  Zap,
  RefreshCw,
  Copy,
  ExternalLink,
} from 'lucide-react';

interface DiscoveredEmail {
  email: string;
  type: string;
  confidence: number;
  source: string;
  status: 'verified' | 'valid' | 'risky' | 'invalid';
}

const mockEmails: DiscoveredEmail[] = [
  { email: 'info@sydneysmile.com.au', type: 'General', confidence: 98, source: 'Homepage', status: 'verified' },
  { email: 'sales@sydneysmile.com.au', type: 'Sales', confidence: 94, source: 'Contact Page', status: 'verified' },
  { email: 'admin@sydneysmile.com.au', type: 'Admin', confidence: 87, source: 'Footer', status: 'valid' },
  { email: 'dr.chen@sydneysmile.com.au', type: 'Founder', confidence: 72, source: 'Team Page', status: 'valid' },
  { email: 'support@sydneysmile.com.au', type: 'Support', confidence: 65, source: 'Contact Page', status: 'risky' },
];

const scanPages = [
  { name: 'Homepage', icon: '🏠', status: 'scanned', found: 2 },
  { name: 'Contact Page', icon: '📞', status: 'scanned', found: 2 },
  { name: 'About Page', icon: 'ℹ️', status: 'scanned', found: 0 },
  { name: 'Team Page', icon: '👥', status: 'scanned', found: 1 },
  { name: 'Footer', icon: '📄', status: 'scanned', found: 1 },
  { name: 'Header', icon: '🔝', status: 'scanning', found: 0 },
  { name: 'Privacy Policy', icon: '🔒', status: 'pending', found: 0 },
  { name: 'Terms Page', icon: '📋', status: 'pending', found: 0 },
];

const validationChecks = [
  { name: 'MX Records', status: 'pass', detail: 'Valid mail server found' },
  { name: 'Catch-all Domain', status: 'pass', detail: 'Not catch-all' },
  { name: 'Disposable Email', status: 'pass', detail: 'Not disposable' },
  { name: 'Spam Risk', status: 'pass', detail: 'Low risk score: 2/100' },
  { name: 'Domain Age', status: 'pass', detail: '8 years old — trusted' },
];

function getStatusIcon(status: string) {
  switch (status) {
    case 'verified': return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />;
    case 'valid': return <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />;
    case 'risky': return <AlertCircle className="w-3.5 h-3.5 text-amber-400" />;
    default: return <XCircle className="w-3.5 h-3.5 text-red-400" />;
  }
}

function getStatusStyle(status: string) {
  switch (status) {
    case 'verified': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'valid': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    case 'risky': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    default: return 'bg-red-500/10 text-red-400 border-red-500/20';
  }
}

export default function EmailFinder() {
  const [websiteUrl, setWebsiteUrl] = useState('sydneysmile.com.au');
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(true);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);

  const handleScan = () => {
    setScanning(true);
    setScanned(false);
    setTimeout(() => {
      setScanning(false);
      setScanned(true);
    }, 2500);
  };

  const handleCopy = (email: string) => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(email);
    setTimeout(() => setCopiedEmail(null), 1500);
  };

  return (
    <div className="p-5 space-y-5">
      {/* URL Input */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Mail className="w-5 h-5 text-violet-400" />
          <h3 className="text-white font-semibold">AI Email Finder</h3>
          <span className="text-[10px] px-1.5 py-0.5 bg-violet-500/10 text-violet-400 rounded-full border border-violet-500/20">AI Powered</span>
        </div>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={websiteUrl}
              onChange={e => setWebsiteUrl(e.target.value)}
              className="w-full pl-9 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500/20"
              placeholder="Enter website URL..."
            />
          </div>
          <button
            onClick={handleScan}
            disabled={scanning}
            className="flex items-center gap-2 px-5 py-3 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white rounded-xl font-semibold text-sm transition-colors"
          >
            {scanning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            {scanning ? 'Scanning...' : 'Find Emails'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Scan Progress */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-4 text-sm">Pages Scanned</h3>
          <div className="space-y-2">
            {scanPages.map(page => (
              <div key={page.name} className={`flex items-center justify-between p-2.5 rounded-xl ${
                page.status === 'scanned' ? 'bg-gray-800' :
                page.status === 'scanning' ? 'bg-blue-500/5 border border-blue-500/20' :
                'bg-gray-800/50 opacity-50'
              }`}>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{page.icon}</span>
                  <span className="text-xs text-gray-300">{page.name}</span>
                </div>
                {page.status === 'scanned' && (
                  <span className={`text-[10px] font-semibold ${page.found > 0 ? 'text-emerald-400' : 'text-gray-600'}`}>
                    {page.found > 0 ? `+${page.found} found` : 'No emails'}
                  </span>
                )}
                {page.status === 'scanning' && (
                  <RefreshCw className="w-3 h-3 text-blue-400 animate-spin" />
                )}
                {page.status === 'pending' && (
                  <span className="text-[10px] text-gray-600">Pending</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Discovered Emails */}
        <div className="xl:col-span-2 space-y-4">
          {scanned && (
            <>
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-semibold text-sm">Discovered Emails ({mockEmails.length})</h3>
                  <div className="text-xs text-gray-500">
                    Scanning: <span className="text-white font-medium">{websiteUrl}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  {mockEmails.map(item => (
                    <div key={item.email} className="flex items-center gap-3 p-3 bg-gray-800 rounded-xl">
                      <div className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                        item.type === 'General' ? 'bg-blue-500/20 text-blue-400' :
                        item.type === 'Sales' ? 'bg-emerald-500/20 text-emerald-400' :
                        item.type === 'Founder' ? 'bg-amber-500/20 text-amber-400' :
                        item.type === 'Support' ? 'bg-violet-500/20 text-violet-400' :
                        'bg-gray-700 text-gray-400'
                      }`}>
                        {item.type[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-white font-medium truncate">{item.email}</div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-gray-500">{item.type}</span>
                          <span className="text-[10px] text-gray-600">·</span>
                          <span className="text-[10px] text-gray-500">Found in {item.source}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {/* Confidence */}
                        <div className="text-right">
                          <div className="text-xs font-bold text-white">{item.confidence}%</div>
                          <div className="text-[9px] text-gray-600">confidence</div>
                        </div>
                        {/* Status */}
                        <span className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-semibold ${getStatusStyle(item.status)}`}>
                          {getStatusIcon(item.status)}
                          {item.status}
                        </span>
                        {/* Copy */}
                        <button
                          onClick={() => handleCopy(item.email)}
                          className="p-1.5 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
                        >
                          {copiedEmail === item.email
                            ? <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            : <Copy className="w-3 h-3 text-gray-400" />
                          }
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Email Validation */}
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="w-5 h-5 text-blue-400" />
                  <h3 className="text-white font-semibold text-sm">Email Validation — info@sydneysmile.com.au</h3>
                </div>
                <div className="space-y-2">
                  {validationChecks.map(check => (
                    <div key={check.name} className="flex items-center justify-between p-2.5 bg-gray-800 rounded-xl">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm text-gray-300">{check.name}</span>
                      </div>
                      <span className="text-xs text-gray-500">{check.detail}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl text-center">
                  <div className="text-emerald-400 font-bold text-sm">✓ Verified Email</div>
                  <div className="text-gray-500 text-xs">98% confidence · Safe to send</div>
                </div>
              </div>

              {/* Social Discovery */}
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <ExternalLink className="w-4 h-4 text-pink-400" />
                  <h3 className="text-white font-semibold text-sm">Social Contact Discovery</h3>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { platform: 'LinkedIn', handle: 'sydneysmile', found: true, color: 'bg-blue-600/20 text-blue-400' },
                    { platform: 'Facebook', handle: 'sydneysmile', found: true, color: 'bg-blue-700/20 text-blue-400' },
                    { platform: 'Instagram', handle: 'sydneysmile_dental', found: true, color: 'bg-pink-600/20 text-pink-400' },
                    { platform: 'YouTube', handle: '—', found: false, color: 'bg-gray-800 text-gray-600' },
                    { platform: 'Twitter/X', handle: '—', found: false, color: 'bg-gray-800 text-gray-600' },
                    { platform: 'WhatsApp', handle: '+61 2 9123 4567', found: true, color: 'bg-emerald-600/20 text-emerald-400' },
                  ].map(social => (
                    <div key={social.platform} className={`p-2.5 rounded-xl ${social.color}`}>
                      <div className="text-xs font-semibold mb-0.5">{social.platform}</div>
                      <div className="text-[10px] truncate opacity-80">{social.handle}</div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
