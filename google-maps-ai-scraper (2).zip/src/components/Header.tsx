import { Bell, Search, Crown, ChevronDown, LogOut, User as UserIcon, Menu } from 'lucide-react';
import { User as UserType } from '../context/AuthContext';
import UsageBar from './UsageBar';

interface HeaderProps {
  title: string;
  subtitle: string;
  user?: UserType;
  onLogout?: () => void;
  onMenuToggle?: () => void;
}

const planBadge: Record<string, { label: string; gradient: string }> = {
  free:       { label: 'Free',       gradient: 'from-gray-500/20 to-gray-600/20 border-gray-500/30' },
  pro:        { label: 'Pro',        gradient: 'from-blue-500/20 to-cyan-500/20 border-blue-500/30' },
  agency:     { label: 'Agency',     gradient: 'from-amber-500/20 to-orange-500/20 border-amber-500/30' },
  enterprise: { label: 'Enterprise', gradient: 'from-violet-500/20 to-purple-500/20 border-violet-500/30' },
};
const planText: Record<string, string> = { free: 'text-gray-400', pro: 'text-blue-400', agency: 'text-amber-400', enterprise: 'text-violet-400' };

export default function Header({ title, subtitle, user, onLogout, onMenuToggle }: HeaderProps) {
  const badge = planBadge[user?.plan || 'free'];
  const bText = planText[user?.plan || 'free'];

  return (
    <header className="flex items-center justify-between px-4 lg:px-6 py-3 lg:py-4 bg-gray-900 border-b border-gray-800 gap-3">
      {/* Mobile hamburger */}
      <button onClick={onMenuToggle} className="lg:hidden p-2 rounded-xl bg-gray-800 border border-gray-700 hover:border-gray-600 text-gray-400 flex-shrink-0">
        <Menu className="w-5 h-5" />
      </button>

      <div className="min-w-0 flex-1">
        <h1 className="text-base lg:text-xl font-bold text-white truncate">{title}</h1>
        <p className="text-xs lg:text-sm text-gray-400 truncate hidden sm:block">{subtitle}</p>
      </div>

      <div className="flex items-center gap-2 lg:gap-3 flex-shrink-0">
        {/* Search — desktop only */}
        <div className="relative hidden xl:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input type="text" placeholder="Search leads…" className="pl-9 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-300 placeholder-gray-500 focus:outline-none focus:border-blue-500 w-48 transition-all" />
        </div>

        {/* Plan badge */}
        <div className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-gradient-to-r ${badge.gradient} border rounded-xl`}>
          <Crown className={`w-3.5 h-3.5 ${bText}`} />
          <span className={`text-xs font-bold ${bText}`}>{badge.label}</span>
        </div>

        {/* Usage bar mini */}
        <div className="hidden md:block">
          <UsageBar variant="mini" />
        </div>

        {/* Notifications */}
        <button className="relative p-2 rounded-xl bg-gray-800 border border-gray-700 hover:border-gray-600">
          <Bell className="w-4 h-4 text-gray-400" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full"></span>
        </button>

        {/* Avatar */}
        {user ? (
          <div className="group relative">
            <button className="flex items-center gap-2 px-2 lg:px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-xl hover:border-gray-600">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center">
                <span className="text-white text-xs font-bold">{user.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}</span>
              </div>
              <div className="hidden md:block text-left">
                <div className="text-sm text-gray-300 leading-tight truncate max-w-[100px]">{user.name}</div>
                <div className="text-[10px] text-gray-500 leading-tight capitalize">{user.role} · {user.plan}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-gray-500 hidden md:block" />
            </button>
            <div className="absolute right-0 top-full mt-2 w-56 bg-gray-900 border border-gray-700 rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <div className="p-3 border-b border-gray-800">
                <div className="flex items-center gap-2"><UserIcon className="w-4 h-4 text-gray-500" /><div className="min-w-0"><div className="text-sm text-white font-semibold truncate">{user.name}</div><div className="text-xs text-gray-500 truncate">{user.email}</div></div></div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20 font-semibold capitalize">{user.plan}</span>
                  <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20 font-semibold capitalize">{user.role}</span>
                </div>
              </div>
              <div className="p-1.5">
                {onLogout && <button onClick={onLogout} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-lg"><LogOut className="w-4 h-4" />Sign Out</button>}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </header>
  );
}
