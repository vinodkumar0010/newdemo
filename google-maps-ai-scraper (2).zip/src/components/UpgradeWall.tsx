import { Lock, Crown, ArrowRight } from 'lucide-react';
import { NavSection } from '../types';
import { getRequiredPlan, PlanId } from '../lib/planGate';

const planNames: Record<PlanId, string> = { free: 'Free', pro: 'Pro', agency: 'Agency', enterprise: 'Enterprise' };
const planColors: Record<PlanId, string> = { free: 'from-gray-500 to-gray-600', pro: 'from-blue-500 to-cyan-500', agency: 'from-violet-500 to-purple-500', enterprise: 'from-amber-500 to-orange-500' };
const sectionLabels: Partial<Record<NavSection, { title: string; desc: string; features: string[] }>> = {
  'ai-analysis': { title: 'AI Analysis', desc: 'Website scoring, AI opportunity detection, lead scoring, review intelligence, email finder', features: ['Website Analysis (0-100 score)', 'AI Opportunity Detection', 'AI Lead Scoring Engine', 'Review Intelligence', 'Competitor Discovery'] },
  outreach: { title: 'AI Outreach Generator', desc: 'Personalized cold emails, LinkedIn messages, WhatsApp, AI voice call scripts', features: ['Cold Email Generator', 'LinkedIn Message Templates', 'WhatsApp Outreach', 'AI Voice Call Scripts', 'Bulk Outreach for All Leads'] },
  team: { title: 'Team Workspace', desc: 'Add team members, assign roles, share leads, track activity', features: ['Add Unlimited Team Members', 'Role-Based Access Control', 'Activity Log & Audit Trail', 'Shared Notes on Leads', 'Real-Time Collaboration'] },
  crm: { title: 'Google Sheets & Export', desc: 'Real-time Google Sheets sync, CSV/Excel export, voice agent export', features: ['Google Sheets Real-Time Sync', 'CSV + Excel + JSON Export', 'Voice Agent Export (Vapi, Bland AI)', 'Column Selector', 'Bulk Data Download'] },
};

export default function UpgradeWall({ section, onNavigate }: { section: NavSection; onNavigate: (s: NavSection) => void }) {
  const requiredPlan = getRequiredPlan(section);
  const info = sectionLabels[section];
  const color = planColors[requiredPlan];

  return (
    <div className="p-6 flex items-center justify-center min-h-[70vh]">
      <div className="max-w-lg w-full text-center">
        {/* Lock icon */}
        <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${color} flex items-center justify-center mx-auto mb-6 shadow-2xl opacity-90`}>
          <Lock className="w-9 h-9 text-white" />
        </div>

        {/* Title */}
        <h2 className="text-2xl font-black text-white mb-2">{info?.title || 'Premium Feature'}</h2>
        <p className="text-gray-400 text-sm mb-6 max-w-md mx-auto">{info?.desc || 'This feature requires an upgraded plan.'}</p>

        {/* Required plan badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-900 border border-gray-700 rounded-xl mb-6">
          <Crown className={`w-4 h-4 bg-gradient-to-r ${color} bg-clip-text`} style={{ color: requiredPlan === 'pro' ? '#3b82f6' : requiredPlan === 'agency' ? '#8b5cf6' : '#f59e0b' }} />
          <span className="text-sm text-gray-300">Requires <strong className="text-white">{planNames[requiredPlan]} Plan</strong> or higher</span>
        </div>

        {/* Features list */}
        {info?.features && (
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 mb-6 text-left">
            <div className="text-xs text-gray-500 uppercase font-semibold mb-3">What you'll unlock:</div>
            <div className="space-y-2">
              {info.features.map(f => (
                <div key={f} className="flex items-center gap-2.5 text-sm">
                  <div className={`w-5 h-5 rounded-lg bg-gradient-to-br ${color} flex items-center justify-center flex-shrink-0 opacity-80`}>
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <span className="text-gray-300">{f}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* CTA */}
        <button
          onClick={() => onNavigate('pricing')}
          className={`inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r ${color} text-white font-bold rounded-xl text-sm shadow-lg transition-transform hover:scale-105`}
        >
          Upgrade to {planNames[requiredPlan]} <ArrowRight className="w-4 h-4" />
        </button>
        <p className="text-xs text-gray-600 mt-3">Cancel anytime · No long-term commitment</p>
      </div>
    </div>
  );
}
