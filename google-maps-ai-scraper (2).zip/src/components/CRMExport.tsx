import { useState } from 'react';
import { Download, CheckCircle2, ExternalLink, RefreshCw, Zap, FileSpreadsheet, Table2, Link, ArrowUpRight } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { useLeadCount } from '../context/LeadContext';

const SHEETS_URL = 'https://docs.google.com/spreadsheets';
const voiceAgentLinks = [
  { name: 'Omnidim', logo: '🔊', url: 'https://omnidim.io' },
  { name: 'Bland AI', logo: '🤖', url: 'https://www.bland.ai' },
  { name: 'Vapi', logo: '📞', url: 'https://vapi.ai' },
  { name: 'Retell AI', logo: '🎙️', url: 'https://www.retellai.com' },
];
const allColumns = [
  'Business Name', 'Category', 'Address', 'City', 'State', 'Country',
  'Website', 'Phone', 'Email', 'Rating', 'Reviews', 'Lead Score',
  'Lead Category', 'Opportunity', 'Website Score', 'Email Status',
  'Decision Maker', 'Social Media', 'Scraped At',
];

export default function CRMExport() {
  const { showToast } = useToast();
  const { leads, count } = useLeadCount();
  const [syncing, setSyncing] = useState(false);
  const [sheetConnected, setSheetConnected] = useState(true);
  const [exportFormat, setExportFormat] = useState<'csv' | 'excel' | 'json'>('csv');
  const [selectedColumns, setSelectedColumns] = useState<string[]>(['Business Name', 'Email', 'Website', 'Phone', 'Rating', 'Reviews', 'Lead Score', 'Opportunity']);
  const [voiceExporting, setVoiceExporting] = useState<string | null>(null);

  const toggleColumn = (col: string) => setSelectedColumns(prev => prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]);

  const handleSync = () => {
    setSyncing(true);
    showToast('info', 'Syncing with Google Sheets', `Pushing ${count} leads…`);
    setTimeout(() => { setSyncing(false); showToast('success', 'Synced!', `${count} leads in Google Sheets`); }, 2000);
  };

  const handleExport = () => {
    if (leads.length === 0) { showToast('error', 'No leads', 'Scrape leads first'); return; }
    const header = selectedColumns.join(',');
    const rows = leads.map(l => selectedColumns.map(c => {
      switch (c) {
        case 'Business Name': return `"${l.businessName}"`;
        case 'Category': return `"${l.category}"`;
        case 'Address': return `"${l.address}"`;
        case 'City': return l.city;
        case 'State': return l.state;
        case 'Country': return l.country;
        case 'Website': return l.website || '';
        case 'Phone': return l.phone || '';
        case 'Email': return l.email || '';
        case 'Rating': return String(l.rating);
        case 'Reviews': return String(l.reviews);
        case 'Lead Score': return String(l.leadScore);
        case 'Lead Category': return l.leadCategory;
        case 'Opportunity': return `"${(l.opportunities || []).join('; ')}"`;
        case 'Website Score': return String(l.websiteScore || 0);
        case 'Email Status': return l.emailStatus || '';
        case 'Decision Maker': return l.decisionMaker?.name || '';
        case 'Social Media': return `"${Object.entries(l.socialMedia || {}).filter(([,v]) => v).map(([k,v]) => `${k}:${v}`).join(', ')}"`;
        case 'Scraped At': return l.scrapedAt;
        default: return '';
      }
    }).join(','));
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `leads-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
    showToast('success', `${exportFormat.toUpperCase()} exported!`, `${leads.length} leads · ${selectedColumns.length} columns`);
  };

  const handleVoiceExport = (name: string, url: string) => {
    setVoiceExporting(name);
    showToast('info', `Exporting to ${name}`, 'Preparing data…');
    setTimeout(() => { setVoiceExporting(null); window.open(url, '_blank'); showToast('success', `Exported to ${name}`, `${count} leads ready`); }, 1500);
  };

  // preview rows from real leads
  const previewRows = leads.slice(0, 5).map(l => [l.businessName, l.email || '—', l.website || '—', l.phone || '—', String(l.rating || '—')]);

  return (
    <div className="p-6 space-y-6">
      {/* Sheets Integration */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center text-xl">📊</div>
          <div className="flex-1"><h3 className="text-white font-semibold text-lg">Google Sheets Integration</h3><p className="text-gray-500 text-sm">Sync your {count} real scraped leads</p></div>
          {sheetConnected ? <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold px-2.5 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20"><span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>Connected</span>
          : <span className="text-xs text-gray-600 px-2.5 py-1 bg-gray-800 rounded-full border border-gray-700">Disconnected</span>}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-gray-800 rounded-xl text-center flex-1"><div className="text-2xl font-black text-white">{count}</div><div className="text-xs text-gray-500">Total Leads</div></div>
              <div className="p-3 bg-gray-800 rounded-xl text-center flex-1"><div className="text-2xl font-black text-emerald-400">{leads.filter(l => l.email).length}</div><div className="text-xs text-gray-500">With Email</div></div>
              <div className="p-3 bg-gray-800 rounded-xl text-center flex-1"><div className="text-2xl font-black text-blue-400">{leads.filter(l => l.website).length}</div><div className="text-xs text-gray-500">With Website</div></div>
            </div>
            <div className="flex gap-2">
              <button onClick={handleSync} disabled={!sheetConnected || syncing || count === 0}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-40 text-white rounded-xl text-sm font-semibold transition-colors">
                <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />{syncing ? 'Syncing…' : 'Sync Now'}
              </button>
              <button onClick={() => { window.open(SHEETS_URL, '_blank'); }} className="flex items-center gap-2 px-4 py-2.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl text-sm font-semibold transition-colors border border-gray-700"><ExternalLink className="w-4 h-4" />Open</button>
              {!sheetConnected && <button onClick={() => { setSheetConnected(true); showToast('success', 'Connected!', 'Google Sheets linked'); }} className="px-4 py-2.5 bg-green-600 text-white rounded-xl text-sm font-semibold">Connect</button>}
            </div>
          </div>
          {/* Preview */}
          <div className="bg-gray-800 rounded-xl p-4 overflow-hidden">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-700"><Table2 className="w-4 h-4 text-green-400" /><span className="text-sm font-semibold text-white">Live Preview</span><span className="text-[10px] px-1.5 py-0.5 bg-green-500/10 text-green-400 rounded-full border border-green-500/20 ml-auto">Real data</span></div>
            {previewRows.length > 0 ? (
              <div className="overflow-x-auto text-[11px]">
                <table className="w-full"><thead><tr className="text-gray-500 border-b border-gray-700">{['Name','Email','Website','Phone','Rating'].map(h => <th key={h} className="text-left py-1.5 pr-3">{h}</th>)}</tr></thead>
                  <tbody className="text-gray-300">{previewRows.map((row, ri) => <tr key={ri} className="border-b border-gray-700/50">{row.map((c, ci) => <td key={ci} className="py-1.5 pr-3 truncate max-w-[8rem]">{c}</td>)}</tr>)}</tbody>
                </table>
                <div className="text-center text-[10px] text-gray-600 mt-2">Showing {previewRows.length} of {count}</div>
              </div>
            ) : <div className="text-center py-6 text-gray-600 text-sm">No leads — scrape first</div>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Export */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4"><Download className="w-5 h-5 text-emerald-400" /><h3 className="text-white font-semibold">Export Leads</h3></div>
          <div className="mb-4"><label className="block text-sm text-gray-400 mb-2">Format</label>
            <div className="grid grid-cols-3 gap-2">{(['csv', 'excel', 'json'] as const).map(f => (
              <button key={f} onClick={() => setExportFormat(f)} className={`py-2.5 rounded-xl text-sm font-semibold uppercase transition-all ${exportFormat === f ? 'bg-emerald-600 text-white' : 'bg-gray-800 border border-gray-700 text-gray-400 hover:border-gray-500'}`}>{f}</button>
            ))}</div>
          </div>
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2"><label className="text-sm text-gray-400">Columns ({selectedColumns.length}/{allColumns.length})</label><div className="flex gap-2"><button onClick={() => setSelectedColumns(allColumns)} className="text-xs text-blue-400 hover:text-blue-300">All</button><button onClick={() => setSelectedColumns([])} className="text-xs text-gray-500 hover:text-gray-300">Clear</button></div></div>
            <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">{allColumns.map(col => (
              <button key={col} onClick={() => toggleColumn(col)} className={`flex items-center gap-1.5 p-2 rounded-lg text-xs text-left transition-all ${selectedColumns.includes(col) ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-gray-800 border border-gray-700 text-gray-500 hover:border-gray-600'}`}>
                <CheckCircle2 className={`w-3 h-3 flex-shrink-0 ${selectedColumns.includes(col) ? 'text-emerald-400' : 'text-gray-700'}`} />{col}
              </button>
            ))}</div>
          </div>
          <div className="p-3 bg-gray-800 rounded-xl mb-4 flex items-center justify-between"><div className="text-sm text-gray-400">Exporting <span className="text-white font-bold">{count}</span> leads · <span className="text-white font-bold">{selectedColumns.length}</span> columns</div><FileSpreadsheet className="w-4 h-4 text-gray-500" /></div>
          <button onClick={handleExport} disabled={count === 0 || selectedColumns.length === 0} className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-xl font-semibold transition-colors"><Download className="w-4 h-4" />Export {exportFormat.toUpperCase()}</button>
        </div>

        {/* Voice Agent */}
        <div className="bg-gradient-to-br from-violet-900/30 to-purple-900/30 border border-violet-700/40 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3"><Zap className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold">AI Voice Agent Export</h3></div>
          <p className="text-sm text-gray-400 mb-5">Export {count} leads to AI calling platforms with call scripts.</p>
          <div className="space-y-2 mb-5">{voiceAgentLinks.map(a => (
            <div key={a.name} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5 hover:border-violet-500/30 transition-colors">
              <div className="flex items-center gap-3"><span className="text-xl">{a.logo}</span><div><span className="text-sm text-white font-medium">{a.name}</span><a href={a.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[10px] text-violet-400/70 hover:text-violet-300"><Link className="w-2.5 h-2.5" />{a.url.replace('https://', '').replace('www.', '')}</a></div></div>
              <button onClick={() => handleVoiceExport(a.name, a.url)} disabled={voiceExporting === a.name || count === 0} className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white rounded-lg font-semibold transition-colors">{voiceExporting === a.name ? <RefreshCw className="w-3 h-3 animate-spin" /> : <ArrowUpRight className="w-3 h-3" />}{voiceExporting === a.name ? 'Sending…' : 'Export'}</button>
            </div>
          ))}</div>
          <div className="p-3 bg-white/5 rounded-xl text-center"><div className="text-xs text-gray-400 mb-1">Each export includes:</div><div className="flex flex-wrap justify-center gap-2">{['Lead Name', 'Phone', 'Email', 'Business Type', 'AI Call Script'].map(f => <span key={f} className="text-[10px] px-2 py-0.5 bg-violet-500/10 text-violet-300 rounded-md border border-violet-500/20">{f}</span>)}</div></div>
        </div>
      </div>
    </div>
  );
}
