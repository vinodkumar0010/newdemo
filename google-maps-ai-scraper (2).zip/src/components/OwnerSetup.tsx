import { useState } from 'react';
import { Zap, Lock, Mail, User, Eye, EyeOff, CheckCircle2, Shield, ArrowRight } from 'lucide-react';

interface Props {
  onComplete: (name: string, email: string, password: string) => void;
}

export default function OwnerSetup({ onComplete }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name.trim() || !email.trim() || !password) { setError('All fields are required'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError('Enter a valid email address'); return; }
    if (password.length < 8) { setError('Password must be at least 8 characters'); return; }
    if (!/[A-Z]/.test(password) || !/[0-9]/.test(password)) { setError('Password needs uppercase letter & number'); return; }
    if (password !== confirm) { setError('Passwords do not match'); return; }
    onComplete(name.trim(), email.trim(), password);
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center mx-auto mb-4 shadow-2xl">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <div className="flex items-center gap-1 justify-center mb-1">
            <span className="text-blue-400 font-black text-2xl">MASTER</span>
            <span className="text-red-400 font-black text-2xl">EDGE</span>
          </div>
          <p className="text-gray-500 text-sm">Google Maps Lead Scraper Pro AI</p>
        </div>

        {/* Card */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Shield className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">Owner Account Setup</h2>
              <p className="text-gray-500 text-xs">First-time setup — create your admin login</p>
            </div>
          </div>

          <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl mb-5">
            <p className="text-xs text-blue-300">🔐 This is a <strong>one-time setup</strong>. You are creating the owner account with full admin access. Save your credentials securely — you'll use them to login every time.</p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-sm text-red-400">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1.5 font-medium">Your Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Masteredge Admin"
                  className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500" />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1.5 font-medium">Login Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="owner@yourdomain.com"
                  className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500" />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1.5 font-medium">Password (8+ chars, uppercase & number)</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type={show ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Create a strong password"
                  className="w-full pl-10 pr-10 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500" />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
                  {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {password && (
                <div className="flex gap-1 mt-2">
                  {[password.length >= 8, /[A-Z]/.test(password), /[0-9]/.test(password)].map((ok, i) => (
                    <div key={i} className={`h-1 flex-1 rounded-full ${ok ? 'bg-emerald-400' : 'bg-gray-700'}`}></div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1.5 font-medium">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Re-enter your password"
                  className="w-full pl-10 pr-10 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500" />
                {confirm && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {password === confirm ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <div className="w-4 h-4 rounded-full border-2 border-red-400"></div>}
                  </div>
                )}
              </div>
            </div>

            <button type="submit" className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-bold rounded-xl text-sm transition-all shadow-lg">
              Create Owner Account <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="text-xs text-gray-600 text-center mt-4">This creates the administrator account with full access to all features, settings, and team management.</p>
        </div>
      </div>
    </div>
  );
}
