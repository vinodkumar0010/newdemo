import { useState, useRef } from 'react';
import {
  Play, Square, MapPin, RefreshCw, Settings, ChevronDown,
  Globe, Layers, Cpu, CheckCircle2, Clock, Zap, Trash2, AlertCircle, Key,
} from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { useLeadCount } from '../context/LeadContext';
import { Lead } from '../types';
import UsageBar from './UsageBar';

const searchTemplates = [
  'Dentist Sydney', 'Dentist Melbourne', 'Plumber Sydney', 'Lawyer Melbourne',
  'Restaurant Brisbane', 'Gym Perth', 'Cafe Adelaide', 'Real Estate Gold Coast',
  'Electrician Canberra', 'Mechanic Hobart', 'Accountant Newcastle', 'Physiotherapist Darwin',
];

const scrapedFields = [
  'Business Name', 'Category', 'Address', 'Website', 'Phone',
  'Reviews', 'Rating', 'Hours', 'Google Maps URL', 'Latitude',
  'Longitude', 'City', 'State', 'Country',
];

export default function ScraperEngine() {
  const { showToast } = useToast();
  const { scrapeGoogle, isScraping, stopScraping, count: totalLeads, apiKey, setApiKey, clearLeads } = useLeadCount();
  const [query, setQuery] = useState('Dentist Sydney');
  const [locations, setLocations] = useState<string[]>([]);
  const [locationInput, setLocationInput] = useState('');
  const [autoScroll, setAutoScroll] = useState(true);
  const [autoPagination, setAutoPagination] = useState(true);
  const [backgroundMode, setBackgroundMode] = useState(false);
  const [status, setStatus] = useState<'idle' | 'running' | 'paused' | 'done'>('idle');
  const [progress, setProgress] = useState(0);
  const [currentResults, setCurrentResults] = useState<Lead[]>([]);
  const [activeTab, setActiveTab] = useState<'config' | 'fields' | 'results'>('config');
  const [localApiKey, setLocalApiKey] = useState(apiKey);
  const [statusMessage, setStatusMessage] = useState('');
  const pauseRef = useRef(false);

  const addLocation = () => {
    const v = locationInput.trim();
    if (v && !locations.includes(v)) { setLocations(prev => [...prev, v]); setLocationInput(''); }
  };

  const removeLocation = (loc: string) => setLocations(prev => prev.filter(l => l !== loc));

  const buildQueries = (): string[] => {
    const base = query.trim();
    if (!base) return [];
    if (locations.length === 0) return [base];
    // check if base already has a location
    const baseWords = base.split(/\s+/);
    if (baseWords.length >= 2) return [base, ...locations.map(l => `${baseWords[0]} ${l}`)];
    return locations.map(l => `${base} ${l}`);
  };

  const handleStart = async () => {
    if (!apiKey) { showToast('error', 'Google API Key Required', 'Go to Settings → enter your Google Places API key to scrape real data'); return; }
    const queries = buildQueries();
    if (queries.length === 0) { showToast('error', 'Missing query', 'Enter a search term'); return; }

    setStatus('running');
    setProgress(0);
    setCurrentResults([]);
    pauseRef.current = false;

    let allFound: Lead[] = [];

    for (let qi = 0; qi < queries.length; qi++) {
      if (pauseRef.current) { setStatus('paused'); return; }
      const q = queries[qi];
      showToast('info', `Scraping: ${q}`, `Query ${qi + 1} of ${queries.length}`);

      const results = await scrapeGoogle(q, (partial, pct, msg) => {
        setCurrentResults([...allFound, ...partial]);
        const overall = Math.round(((qi + pct / 100) / queries.length) * 100);
        setProgress(overall);
        if (msg) setStatusMessage(msg);
      });

      allFound = [...allFound, ...results];
    }

    setProgress(100);
    setStatus('done');
    setCurrentResults(allFound);
    showToast('success', 'Scraping complete!', `${allFound.length} leads found for ${queries.length} ${queries.length === 1 ? 'query' : 'queries'}`);
  };

  const handleStop = () => {
    pauseRef.current = true;
    stopScraping();
    setStatus('idle');
    showToast('warning', 'Scraping stopped', 'Partial results have been saved');
  };

  const handleSaveKey = () => {
    setApiKey(localApiKey);
    showToast('success', 'API key saved!', localApiKey ? 'Google Places API is active' : 'Running in demo mode');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Status Bar */}
      <div className="flex items-center gap-4 p-4 bg-gray-900 border border-gray-800 rounded-2xl">
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-semibold ${
          status === 'running' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
          status === 'paused' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
          status === 'done' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
          'bg-gray-800 text-gray-400 border border-gray-700'
        }`}>
          {status === 'running' && <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>}
          {status === 'running' ? 'Scraping…' : status === 'paused' ? 'Paused' : status === 'done' ? 'Complete' : 'Ready'}
        </div>

        {(status === 'running' || status === 'done') && (
          <>
            <div className="flex-1 bg-gray-800 rounded-full h-2 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
            </div>
            <span className="text-sm text-white font-semibold">{progress}%</span>
            <div className="flex items-center gap-1.5 text-blue-400 text-sm">
              <MapPin className="w-4 h-4" />
              <span className="font-bold">{currentResults.length}</span>
              <span className="text-gray-500">found</span>
            </div>
            {statusMessage && status === 'running' && (
              <div className="hidden lg:block text-xs text-gray-500 max-w-xs truncate">{statusMessage}</div>
            )}
          </>
        )}

        <div className="flex items-center gap-2 ml-auto text-xs text-gray-500">
          <span>Total in DB: <span className="text-white font-bold">{totalLeads}</span></span>
        </div>

        <div className="flex items-center gap-2">
          {status === 'idle' || status === 'done' ? (
            <button onClick={handleStart} disabled={isScraping}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-xl text-sm font-semibold transition-colors">
              <Play className="w-4 h-4" /> Start Scraping
            </button>
          ) : (
            <button onClick={handleStop}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-sm font-semibold transition-colors">
              <Square className="w-4 h-4" /> Stop
            </button>
          )}
        </div>
      </div>

      {/* Usage limit bar */}
      <UsageBar variant="compact" />

      {/* Live enrichment status */}
      {status === 'running' && statusMessage && (
        <div className="flex items-center gap-2 px-4 py-2.5 bg-blue-500/5 border border-blue-500/20 rounded-xl">
          <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse flex-shrink-0"></span>
          <span className="text-sm text-blue-300 truncate">{statusMessage}</span>
        </div>
      )}

      {/* API Key Banner */}
      {!apiKey && (
        <div className="p-4 bg-red-500/5 border border-red-500/30 rounded-2xl flex flex-wrap items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-red-300">⚠ Google API Key Required</div>
            <div className="text-xs text-red-400/70">You must add a Google Places API key to scrape real business data. Go to Settings or enter it below. Without a key, scraping is disabled.</div>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <input type="password" value={localApiKey} onChange={e => setLocalApiKey(e.target.value)}
              placeholder="Enter Google API Key…" className="flex-1 sm:w-56 px-3 py-2 bg-gray-900 border border-gray-700 rounded-xl text-sm text-white focus:outline-none focus:border-amber-500" />
            <button onClick={handleSaveKey} className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-black rounded-xl text-sm font-bold transition-colors">
              <Key className="w-3.5 h-3.5" /> Save
            </button>
          </div>
        </div>
      )}

      {apiKey && (
        <div className="p-3 bg-emerald-500/5 border border-emerald-500/30 rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-sm text-emerald-400 font-semibold">Google Places API Active</span>
          <span className="text-xs text-gray-500">— Real data mode</span>
          <button onClick={() => { setApiKey(''); setLocalApiKey(''); }} className="ml-auto text-xs text-gray-500 hover:text-red-400 transition-colors">Remove key</button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-900 border border-gray-800 rounded-xl w-fit">
        {(['config', 'fields', 'results'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${activeTab === tab ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}>
            {tab === 'config' ? 'Configuration' : tab === 'fields' ? 'Extract Fields' : `Results (${currentResults.length})`}
          </button>
        ))}
      </div>

      {activeTab === 'config' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Search Setup */}
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 space-y-5">
            <div className="flex items-center gap-2"><MapPin className="w-5 h-5 text-blue-400" /><h3 className="text-white font-semibold">Search Configuration</h3></div>
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Search Query</label>
              <input type="text" value={query} onChange={e => setQuery(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                placeholder="e.g. Dentist Sydney, Plumber Melbourne…" />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Quick Templates</label>
              <div className="flex flex-wrap gap-2">
                {searchTemplates.map(t => (
                  <button key={t} onClick={() => setQuery(t)}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${query === t ? 'bg-blue-600 text-white' : 'bg-gray-800 border border-gray-700 text-gray-300 hover:border-blue-500 hover:text-blue-400'}`}>{t}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Additional Locations (Multi-Location)</label>
              <div className="flex gap-2 mb-2">
                <input type="text" value={locationInput} onChange={e => setLocationInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addLocation()}
                  className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500" placeholder="Add city…" />
                <button onClick={addLocation} className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors">Add</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {locations.map(loc => (
                  <span key={loc} className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs rounded-lg">
                    {loc} <button onClick={() => removeLocation(loc)} className="hover:text-red-400 transition-colors">×</button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Options */}
          <div className="space-y-4">
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2"><Settings className="w-5 h-5 text-blue-400" /><h3 className="text-white font-semibold">Scraping Options</h3></div>
              {[
                { val: autoScroll, set: setAutoScroll, label: 'Auto Scroll', desc: 'Automatically scroll through results', icon: RefreshCw },
                { val: autoPagination, set: setAutoPagination, label: 'Auto Pagination', desc: 'Navigate through all pages', icon: ChevronDown },
                { val: backgroundMode, set: setBackgroundMode, label: 'Background Mode', desc: 'Scrape without active tab focus', icon: Cpu },
              ].map(({ val, set, label, desc, icon: Icon }) => (
                <div key={label} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 text-gray-400" />
                    <div><div className="text-sm font-medium text-white">{label}</div><div className="text-xs text-gray-500">{desc}</div></div>
                  </div>
                  <button onClick={() => set(!val)} className={`relative w-11 h-6 rounded-full transition-colors ${val ? 'bg-blue-500' : 'bg-gray-700'}`}>
                    <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${val ? 'translate-x-5' : 'translate-x-0.5'}`}></span>
                  </button>
                </div>
              ))}
            </div>

            {/* Queue */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3"><Layers className="w-5 h-5 text-violet-400" /><h3 className="text-white font-semibold">Bulk Search Queue</h3></div>
              <div className="space-y-2">
                {buildQueries().map((q, i) => (
                  <div key={q} className="flex items-center gap-3 p-2.5 bg-gray-800 rounded-xl">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${status === 'running' && i === 0 ? 'bg-green-500 text-white' : 'bg-gray-700 text-gray-400'}`}>{status === 'running' && i === 0 ? '▶' : i + 1}</div>
                    <span className="text-sm text-white flex-1">{q}</span>
                    {status === 'running' && i === 0 ? <div className="flex items-center gap-1 text-green-400 text-xs"><span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>Running</div> : <Clock className="w-3.5 h-3.5 text-gray-600" />}
                  </div>
                ))}
                {buildQueries().length === 0 && <div className="text-sm text-gray-600 text-center py-3">Enter a search query above</div>}
              </div>
            </div>

            {/* Features */}
            <div className="bg-gradient-to-br from-blue-900/30 to-indigo-900/30 border border-blue-700/40 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3"><Zap className="w-4 h-4 text-blue-400" /><span className="text-white font-semibold text-sm">Engine Features</span></div>
              <div className="grid grid-cols-2 gap-1.5">
                {['Dynamic Loading Detection', 'Google Places API', 'Multi-Location Scraping', 'GPS Coordinates', 'Business Hours', 'Real-Time Results'].map(f => (
                  <div key={f} className="flex items-center gap-1.5 text-xs text-gray-400"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />{f}</div>
                ))}
              </div>
            </div>

            {/* Clear */}
            <button onClick={() => { clearLeads(); setCurrentResults([]); showToast('success', 'All leads cleared', 'Lead database reset'); }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 rounded-xl text-sm font-semibold transition-colors">
              <Trash2 className="w-4 h-4" /> Clear All Leads ({totalLeads})
            </button>
          </div>
        </div>
      )}

      {activeTab === 'fields' && (
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="w-5 h-5 text-blue-400" /><h3 className="text-white font-semibold">Extracted Data Fields</h3>
            <span className="text-xs px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20">{scrapedFields.length} fields</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {scrapedFields.map(field => (
              <div key={field} className="flex items-center gap-2 p-3 bg-gray-800 rounded-xl border border-gray-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" /><span className="text-sm text-gray-300">{field}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'results' && (
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Scraped Results ({currentResults.length})</h3>
            {currentResults.length > 0 && <span className="text-xs text-gray-500">Showing latest scrape session</span>}
          </div>
          {currentResults.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <MapPin className="w-10 h-10 mx-auto mb-3 text-gray-700" />
              <div className="text-sm">No results yet — run a scrape to see live data here</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-500 text-xs uppercase border-b border-gray-800">
                    <th className="pb-2 pr-3">#</th>
                    <th className="pb-2 pr-3">Business</th>
                    <th className="pb-2 pr-3">Phone</th>
                    <th className="pb-2 pr-3">Email</th>
                    <th className="pb-2 pr-3">Rating</th>
                    <th className="pb-2 pr-3">Reviews</th>
                    <th className="pb-2 pr-3">Website</th>
                    <th className="pb-2 pr-3">Socials</th>
                    <th className="pb-2">Score</th>
                  </tr>
                </thead>
                <tbody>
                  {currentResults.map((lead, i) => {
                    const socialCount = Object.values(lead.socialMedia || {}).filter(Boolean).length;
                    return (
                      <tr key={lead.id} className="border-b border-gray-800/50 hover:bg-gray-800/30">
                        <td className="py-2 pr-3 text-gray-600 text-xs">{i + 1}</td>
                        <td className="py-2 pr-3 max-w-[180px]">
                          <div className="text-white font-medium truncate text-xs">{lead.businessName}</div>
                          <div className="text-[10px] text-gray-600">{lead.city}</div>
                        </td>
                        <td className="py-2 pr-3 text-gray-400 text-xs max-w-[110px] truncate">{lead.phone || <span className="text-gray-700">—</span>}</td>
                        <td className="py-2 pr-3 max-w-[140px] truncate">
                          {lead.email ? (
                            <span className="text-emerald-400 text-xs">{lead.email}</span>
                          ) : (
                            <span className="text-gray-700 text-xs">—</span>
                          )}
                        </td>
                        <td className="py-2 pr-3 text-amber-400 text-xs">★ {lead.rating || '—'}</td>
                        <td className="py-2 pr-3 text-gray-400 text-xs">{lead.reviews || '—'}</td>
                        <td className="py-2 pr-3 text-blue-400 text-xs max-w-[120px] truncate">{lead.website || <span className="text-red-400">None</span>}</td>
                        <td className="py-2 pr-3">
                          {socialCount > 0 ? (
                            <span className="text-xs text-violet-400 font-semibold">{socialCount} found</span>
                          ) : (
                            <span className="text-xs text-gray-700">0</span>
                          )}
                        </td>
                        <td className="py-2">
                          <span className={`text-xs font-bold ${lead.leadCategory === 'hot' ? 'text-red-400' : lead.leadCategory === 'warm' ? 'text-orange-400' : 'text-blue-400'}`}>
                            {lead.leadScore}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
