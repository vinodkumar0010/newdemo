import { Component, ReactNode } from 'react';

interface Props { children: ReactNode; }
interface State { hasError: boolean; error: Error | null; }

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) { super(props); this.state = { hasError: false, error: null }; }
  static getDerivedStateFromError(error: Error) { return { hasError: true, error }; }
  componentDidCatch(error: Error, info: any) { console.error('ErrorBoundary caught:', error, info); }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-950 flex items-center justify-center p-8">
          <div className="max-w-md w-full text-center">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto mb-6">
              <span className="text-3xl">⚠️</span>
            </div>
            <h1 className="text-2xl font-black text-white mb-2">Something went wrong</h1>
            <p className="text-gray-400 text-sm mb-6">An unexpected error occurred. Please try refreshing the page.</p>
            <div className="p-3 bg-gray-900 border border-gray-800 rounded-xl mb-6 text-left">
              <p className="text-xs text-red-400 font-mono break-all">{this.state.error?.message || 'Unknown error'}</p>
            </div>
            <div className="flex gap-3 justify-center">
              <button onClick={() => window.location.reload()} className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors">
                Refresh Page
              </button>
              <button onClick={() => this.setState({ hasError: false, error: null })} className="px-6 py-2.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl text-sm font-semibold transition-colors">
                Try Again
              </button>
            </div>
            <p className="text-xs text-gray-600 mt-6">Masteredge Technology — Maps Scraper Pro AI</p>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
