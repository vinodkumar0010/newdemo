export interface Lead {
  id: string;
  businessName: string;
  category: string;
  address: string;
  city: string;
  state: string;
  country: string;
  website?: string;
  phone?: string;
  email?: string;
  salesEmail?: string;
  rating: number;
  reviews: number;
  hours?: string;
  googleMapsUrl: string;
  lat?: number;
  lng?: number;
  leadScore: number;
  leadCategory: 'hot' | 'warm' | 'cold';
  websiteScore?: number;
  opportunities: string[];
  socialMedia: {
    linkedin?: string;
    facebook?: string;
    instagram?: string;
    youtube?: string;
    twitter?: string;
    whatsapp?: string;
  };
  decisionMaker?: {
    name: string;
    position: string;
    linkedin?: string;
  };
  emailConfidence?: number;
  emailStatus?: 'verified' | 'valid' | 'risky' | 'invalid';
  seoIssues?: string[];
  reviewSentiment?: string;
  scrapedAt: string;
}

export type NavSection =
  | 'dashboard'
  | 'scraper'
  | 'leads'
  | 'ai-analysis'
  | 'outreach'
  | 'crm'
  | 'analytics'
  | 'team'
  | 'settings'
  | 'pricing'
  | 'help';
